<!DOCTYPE html>
<html lang="en">

<?php $this->load->view('Admin/includes/n-header') ?>
<style>
    .btn-group, .btn-group-vertical {
        width: 100% !important;
    }
</style>
<body>
    <!-- BEGIN LOADER -->
    <div id="load_screen">
        <div class="loader">
            <div class="loader-content">
                <div class="spinner-grow align-self-center"></div>
            </div>
        </div>
    </div>
    <!--  END LOADER -->

    <!--  BEGIN NAVBAR  -->
    <?php $this->load->view('Admin/includes/n-web-sidebar') ?>
    <!--  END NAVBAR  -->

    <!--  BEGIN MAIN CONTAINER  -->
    <div class="main-container" id="container">

        <div class="overlay"></div>
        <div class="search-overlay"></div>

        <!--  BEGIN Mobile SIDEBAR  -->
        <?php $this->load->view('Admin/includes/n-mobile-sidebar') ?>
        <!--  END Mobile SIDEBAR  -->

        <!--  BEGIN CONTENT AREA  -->
        <div id="content" class="main-content">
            <div class="layout-px-spacing">
                <div class="row">
                    <?php $this->load->view('Admin/includes/n-panel') ?>
                </div>
                <div class="row mt-3">
                    <div class="col-xl-4 col-lg-6 col-md-6 col-sm-12 col-12 layout-spacing">

                        <div class="widget widget-account-invoice-three">

                            <div class="widget-heading light-green">
                                <h6>Department/Designation List</h6>
                            </div>
                            <div class="widget-amount">

                                <div class="w-a-info funds-received">
                                    <span>Add
                                        <a href="#" data-toggle="modal" data-target="#addDepDesg"><img class="user" src="<?= base_url() ?>assets/assets/img/aditon.png"></a>
                                    </span>
                                </div>

                                <div class="w-a-info funds-spent">
                                    <span>View
                                        <a href="<?= base_url() ?>admin/Master/department_designation"><img class="user" src="<?= base_url() ?>assets/assets/img/vision.png"></a>
                                    </span>
                                </div>
                            </div>
                            <div class="widget-content">
                                <p></p>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-6 col-md-6 col-sm-12 col-12 layout-spacing">

                        <div class="widget widget-account-invoice-three">

                            <div class="widget-heading light-blue">
                                <h6>Manager view</h6>
                            </div>
                            <div class="widget-amount">

                                <div class="w-a-info funds-received">
                                    <span>Add
                                        <a href="#" data-toggle="modal" data-target="#user_modal"><img class="user" src="<?= base_url() ?>assets/assets/img/aditon.png"></a>
                                    </span>

                                </div>

                                <div class="w-a-info funds-spent">
                                    <span>View
                                        <a href="<?= base_url() ?>admin/Users"><img class="user" src="<?= base_url() ?>assets/assets/img/vision.png"></a>
                                    </span>
                                </div>
                            </div>
                            <div class="widget-content">
                                <p></p>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-4 col-lg-6 col-md-6 col-sm-12 col-12 layout-spacing">

                        <div class="widget widget-account-invoice-three">

                            <div class="widget-heading light-red">
                                <h6>Role Permission</h6>
                            </div>
                            <div class="widget-amount">

                                <div class="w-a-info funds-received">
                                    <span>Add
                                        <a href="#" data-toggle="modal" data-target="#RolePermissionModel"><img class="user" src="<?= base_url() ?>assets/assets/img/aditon.png"></a>
                                    </span>

                                </div>

                                <div class="w-a-info funds-spent">
                                    <span>View
                                        <a href="<?= base_url() ?>admin/UserPermission/PermissionRole"><img class="user" src="<?= base_url() ?>assets/assets/img/vision.png"></a>
                                    </span>
                                </div>
                            </div>
                            <div class="widget-content">
                                <p></p>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-6 col-md-6 col-sm-12 col-12 layout-spacing">

                        <div class="widget widget-account-invoice-three">

                            <div class="widget-heading light-blue">
                                <h6>Assign Role</h6>
                            </div>
                            <div class="widget-amount">

                                <div class="w-a-info funds-spent">
                                    <span>View
                                        <a href="<?= base_url() ?>admin/UserPermission/ClonePermission"><img class="user" src="<?= base_url() ?>assets/assets/img/vision.png"></a>
                                    </span>
                                </div>
                            </div>
                            <div class="widget-content">
                                <p></p>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-4 col-lg-6 col-md-6 col-sm-12 col-12 layout-spacing">

                        <div class="widget widget-account-invoice-three">

                            <div class="widget-heading light-red">
                                <h6>User Permission</h6>
                            </div>
                            <div class="widget-amount">

                                <div class="w-a-info funds-received">
                                    <span>Add
                                        <a href="#" data-toggle="modal" data-target="#UserPermissionModel"><img class="user" src="<?= base_url() ?>assets/assets/img/aditon.png"></a>
                                    </span>

                                </div>

                                <div class="w-a-info funds-spent">
                                    <span>View
                                        <a href="<?= base_url() ?>admin/UserPermission"><img class="user" src="<?= base_url() ?>assets/assets/img/vision.png"></a>
                                    </span>
                                </div>
                            </div>
                            <div class="widget-content">
                                <p></p>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-4 col-lg-6 col-md-6 col-sm-12 col-12 layout-spacing">

                        <div class="widget widget-account-invoice-three">

                            <div class="widget-heading dark-green">
                                <h6>Shift</h6>
                            </div>
                            <div class="widget-amount">

                                <div class="w-a-info funds-received">
                                    <span>Add
                                        <a href="#" data-toggle="modal" data-target="#ShiftModel"><img class="user" src="<?= base_url() ?>assets/assets/img/aditon.png"></a>
                                    </span>

                                </div>

                                <div class="w-a-info funds-spent">
                                    <span>View
                                        <a href="<?= base_url() ?>admin/Tracking/MasterShift"><img class="user" src="<?= base_url() ?>assets/assets/img/vision.png"></a>
                                    </span>
                                </div>
                            </div>
                            <div class="widget-content">
                                <p></p>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-4 col-lg-6 col-md-6 col-sm-12 col-12 layout-spacing">

                        <div class="widget widget-account-invoice-three">

                            <div class="widget-heading dark-green">
                                <h6>Assign Shift</h6>
                            </div>
                            <div class="widget-amount">

                                <div class="w-a-info funds-received">
                                    <span>Add
                                        <a href="#" data-toggle="modal"	data-target="#AssignShiftMode"><img class="user" src="<?= base_url() ?>assets/assets/img/aditon.png"></a>
                                    </span>
                                </div>
                                <div class="w-a-info funds-spent">
                                    <span>View
                                        <a href="<?= base_url() ?>admin/Tracking/shift"><img class="user" src="<?= base_url() ?>assets/assets/img/vision.png"></a>
                                    </span>
                                </div>
                            </div>
                            <div class="widget-content">
                                <p></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- All Pop-Up Start -->
        <div id="addDepDesg" class="modal fade" data-backdrop="static" tabindex="-1" role="dialog">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header bg-info" style="background-color:#009FDF;">
                        <h6 class="modal-title text-white float-left"> Add Department / Designation</h6>
                        <button type="button" class="close text-white" data-dismiss="modal">&times;</button>
                    </div>

                    <div class="modal-body">
                        <form class="form-horizontal" id="TypeForm">
                            <div class="form-group row">
                                <label class="control-label lable-center col-sm-3 lable-center" for="email">Department <span style="color: red;">*</span></label>
                                <div class="col-sm-9">
                                    <input type="text" class="form-control" id="department" name="department" placeholder="Enter department name" maxlength="50" autocomplete="off">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="control-label lable-center col-sm-3 lable-center" for="email">Designation <span style="color: red;">*</span></label>
                                <div class="col-sm-8">
                                    <input type="text" class="form-control" id="designation" name="designation[]" placeholder="Enter designation name" maxlength="50">
                                </div>
                                <div class="col-sm-1 mt-2 pl-0">
                                    <button type="button" class="btn btn-success addButton" id="attachSupport"><i class="icon-add"></i></button>
                                </div>
                            </div>
                            <div id="moreSupportUpload"></div>
                            <div class="col-sm-12 p-0 mt-4">
                                <button type="submit" class="btn btn-primary  pull-right">Submit&nbsp;<i class="icon-arrow-right14 position-right"></i><span id="preview"></span></button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <div id="user_modal" class="modal fade" data-backdrop="static" tabindex="-1" role="dialog">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header" style="background-color: #2196f3;color: white;padding: 13px; height: 55px;">

                        <h5 class="modal-title text-white" style="margin-top: -4px">
                            <i class="icon-user-plus" style="zoom:1.1; "></i>
                            &nbsp;Add User
                        </h5>
                        <button type="button" style="color: white;top: 25%;font-weight:600;" class="close" data-dismiss="modal">&times;</button>
                    </div>
                    <div class="modal-body">
                        <form id="ManageUserForm" enctype="multipart/form-data" method="post">
                            <div class="panel panel-flat">
                                <div class="panel-body">
                                    <fieldset>
                                        <div class="row">
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <label>Name: <span style="color: red;">*</span></label>
                                                    <input type="text" class="form-control" id="name" name="name" placeholder="Enter Name" maxlength="35">
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <label>Email: <span style="color: red;">*</span></label>
                                                    <input type="text" class="form-control" id="email" name="email" placeholder="Enter Email" maxlength="35" onkeyup="checkmail()">
                                                    <span id="mail_error" style="color:red;" maxlength="40"> </span>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <label>Password: <span style="color: red;">*</span></label>
                                                    <div class="shbtn" id="show_hide_password_user" style="display: flex;">
                                                        <input type="password" class="form-control" name="password" placeholder="Enter Password" autocomplete="off" style="border-top-right-radius: 0px; border-bottom-right-radius: 0px;" value="<?= $value->Password ?>">
                                                        <div class="input-group-addon">
                                                            <a><i class="icon-eye-blocked" aria-hidden="true" style="margin-top:2px"></i></a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </fieldset>

                                    <fieldset>
                                        <div class="row">
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <label>Mobile No.: <span style="color: red;">*</span></label>
                                                    <input type="text" class="form-control" id="mobile_no" name="mobile_no" placeholder="Enter Mobile no" onkeypress='return event.charCode >= 48 && event.charCode <= 57 || event.charCode == 43 || event.charCode == 45' maxlength="15" onkeyup="checkmobile()">
                                                    <span id="mobile_error" style="color:red;" maxlength="10"> </span>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <label>Emp Id: </label>
                                                    <input type="text" class="form-control" id="emp_id" name="emp_id" placeholder="Enter Emp Id" onblur="chk_emp_code()">
                                                    <span id="error_emp_code" style="color: red;font-size: 11px"></span>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <label>Joining Date: </label>
                                                    <input type="text" class="form-control" id="joining_date" name="joining_date" placeholder="Enter Joining Date">
                                                </div>
                                            </div>
                                        </div>
                                    </fieldset>
                                    <fieldset>
                                        <div class="row">
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <label>Department:</label>
                                                    <div class="media no-margin-top" style="margin-left: -8px;">
                                                        <select name="department" id="department_users" class="form-control" ">
                                                                <option value="">Select Department</option>
                                                                <?php foreach ($department as $value) { ?>
                                                                    <option value=" <?= $value->dep_id; ?>"><?= $value->department_name; ?></option>
                                                        <?php } ?>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <label>Designation:</label>
                                                    <div class="media no-margin-top">
                                                        <select name="designation" id="designation_users" class="form-control">
                                                            <option value="">Select Designation</option>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <label>Profile:</label>
                                                    <div class="media no-margin-top">
                                                        <div class="media-left">
                                                            <a href="#">
                                                                <img src="<?= base_url() ?>assets/admin/assets/images/placeholder.jpg" style="width: 58px; height: 58px;" class="img-rounded" alt="" id="blah">
                                                            </a>
                                                        </div>

                                                        <div class="media-body ml-3">
                                                            <input type="file" class="form-control file-styled" id="imgInp" name="file">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </fieldset>
                                    <fieldset>
                                        <div class="row">
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <label>User Type:</label>
                                                    <div class="media no-margin-top">
                                                        <select name="user_type_io" id="user_type_io" class="form-control">
                                                            <option value="Inside">Inside</option>
                                                            <option value="Outside">Outside</option>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>

                                        </div>
                                    </fieldset>
                                    <br />
                                    <div class="text-right">
                                        <button type="submit" class="btn btn-primary">Submit<i class="icon-arrow-right14 position-right"></i></button>
                                        <span id="preview"></span>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <div id="RolePermissionModel" class="modal fade" data-backdrop="static" tabindex="-1" role="dialog">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header" style="background-color: #009FDF;color: white;padding: 13px; height: 55px;">
                        <h5 class="modal-title text-white" style="margin-top: -4px">
                            <i class="icon-calendar" style="zoom:1.1; "></i>
                            &nbsp;Add Role Permission
                        </h5>
                        <button type="button" style="color: white;top: 25%;font-weight:600;" class="close" data-dismiss="modal">&times;</button>
                    </div>
                    <div class="modal-body" style="padding: 0px;">
                        <form method="post" id="roelPermissionForm" action="<?php echo site_url('admin/UserPermission/SetRolePermission'); ?>">
                            <fieldset style="margin-top: 2%;">
                                <div class="row pl-3 pr-3">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Role : <sup style="color: red">*</sup></label>
                                            <div class="">
                                                <input type="text" name="role" id="role" class="form-control" placeholder="Role">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Role Description : <sup style="color: red">*</sup></label>
                                            <div class="">
                                                <textarea name="role_description" id="role_description" class="form-control" rows="1" maxlength="150" placeholder="Role Description"></textarea>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </fieldset>
                            <fieldset>
                                <table class="table">
                                    <tbody>
                                        <?php
                                        $i = 1;
                                        foreach ($feature_list as $row) {
                                            $collapse = "demo" . $i;
                                            $privilege = $row['privilege'];
                                            $component_id = $row['component_id'];
                                            if ($i % 2 == 0) {
                                                $bgColor = 'width: 25%;background-color: #f3f3f3;border-right: 2px solid #ded4d4 !important;';
                                            } else {
                                                $bgColor = '';
                                            }
                                        ?>
                                            <tr>
                                                <td style="width: 25%;background-color: #f3f3f3;border-right: 2px solid #ded4d4 !important;">
                                                    <b><?= $row['component_title']; ?></b>
                                                </td>
                                                <td style="width: 75%;<?= $bgColor ?>">
                                                    <div class="form-group">
                                                        <div class="row">
                                                            <?php
                                                            $checkbox = 1;

                                                            foreach ($privilege as  $row) {
                                                                $custom_id = $component_id . '/' . $row->privilege_id;
                                                            ?>
                                                                <div class="col-md-3">
                                                                    <div class="checkbox">
                                                                        <label>
                                                                            <input type="checkbox" name="feature_ids[]" class="styled" value="<?= $custom_id; ?>">
                                                                            <?= $row->privilege;  ?>
                                                                        </label>
                                                                    </div>
                                                                </div>
                                                            <?php
                                                                $checkbox++;
                                                            }
                                                            ?>
                                                        </div>
                                                    </div>


                                                </td>
                                            </tr>
                                        <?php
                                            $i++;
                                        } ?>

                                    </tbody>
                                </table>
                            </fieldset>
                            <fieldset>
                                <div class="col-md-12 text-right">
                                    <div class="form-group" style="margin-top:2%;">
                                        <button type="submit" class="btn btn-primary" id="submitBtn">Submit
                                            <i class="icon-arrow-right14 position-right"></i>
                                        </button>
                                        <span id="roelPermissionPreview"></span>
                                    </div>
                                </div>
                            </fieldset>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <div id="UserPermissionModel" class="modal fade" data-backdrop="static" tabindex="-1" role="dialog">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header" style="background-color: #009FDF;color: white;padding: 13px; height: 55px;">

                        <h5 class="modal-title text-white" style="margin-top: -4px">
                            <i class="icon-copy4" style="zoom:1.1; "></i>
                            &nbsp;Copy Permission
                        </h5>
                        <button type="button" style="color: white;top: 25%;font-weight:600;" class="close" data-dismiss="modal">&times;</button>
                    </div>
                    <div class="modal-body" style="padding: 0px;">
                        <form method="post" id="CopyPermission" action="<?php echo site_url('admin/UserPermission/CopyPermission'); ?>">
                            <fieldset style="margin-top: 2%;">
                                <div class="row pl-3 pr-3">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Role : <sup style="color: red">*</sup></label>
                                            <div class="">
                                                <select name="role_id" id="role_id" class="form-control">
                                                    <option value="">Select Role</option>
                                                    <?php foreach ($role_list as $value) { ?>
                                                        <option value="<?= $value['role_id']; ?>"><?= $value['role_name']; ?>
                                                        </option>
                                                    <?php } ?>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Role Description : <sup style="color: red">*</sup></label>
                                            <div class="">
                                                <select class="form-control" name="employee_id" id="employee_id">
                                                    <option value="">Select Employee</option>
                                                    <?php foreach ($array_users->result() as $row3) { ?>
                                                        <option value="<?= $row3->id; ?>"><?= $row3->name; ?></option>
                                                    <?php } ?>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </fieldset>
                            <fieldset>
                                <div class="col-md-12 text-right">
                                    <div class="form-group">
                                        <button type="submit" class="btn btn-primary" id="submitBtn">Copy Permission
                                            <i class="icon-copy3 position-right"></i>
                                        </button>
                                        <span id="CopyPermissionPreview"></span>
                                    </div>
                                </div>
                            </fieldset>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <div id="ShiftModel" class="modal fade" data-backdrop="static" tabindex="-1" role="dialog">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header" style="background-color: #2196f3;color: white;padding: 13px; height: 55px;">
                        <h5 class="modal-title text-white" style="margin-top: -4px">
                            <i class="icon-calendar" style="zoom:1.1; "></i>
                            &nbsp;Add Master Shift
                        </h5>
                        <button type="button" style="color: white;top: 25%;font-weight:600;" class="close" data-dismiss="modal">&times;</button>
                    </div>
                    <div class="modal-body">
                        <form id="addform" method="post">
                            <div class="panel panel-flat">
                                <div class="panel-body">
                                    <fieldset>
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label>Shift Name : <sup style="color: red">*</sup></label>
                                                    <input type="text" class="form-control" name="shift_title">
                                                </div>
                                            </div>
                                        </div>
                                    </fieldset>
                                    <fieldset>
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="form-group clockpicker" data-autoclose="true">
                                                    <label>From Time : <sup style="color: red">*</sup></label>
                                                    <input type="text" class="form-control" name="from_timing" id="from_timing" autocomplete="off">
                                                </div>
                                            </div>
                                        </div>
                                    </fieldset>
                                    <fieldset>
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="form-group clockpicker" data-autoclose="true">
                                                    <label>To Time : <sup style="color: red">*</sup></label>
                                                    <input type="text" class="form-control" name="to_timing" id="to_timing" autocomplete="off">
                                                </div>
                                            </div>
                                        </div>
                                    </fieldset>
                                    <br />
                                    <div class="text-right">
                                        <button type="submit" class="btn btn-primary">Submit<i class="icon-arrow-right14 position-right"></i></button>
                                        <span id="preview"></span>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <div id="AssignShiftMode" class="modal fade" data-backdrop="static" tabindex="-1" role="dialog">
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-header"
						style="background-color: #2196f3;color: white;padding: 13px; height: 55px;">
						<h5 class="modal-title" style="margin-top: -4px">
							<i class="icon-briefcase3" style="zoom:1.1; "></i>
							&nbsp; &nbsp;Assign Shift
						</h5>
                        <button type="button" style="color: white;top: 25%;font-weight:600;" class="close"
							data-dismiss="modal">&times;</button>
					</div>
					<div class="modal-body">
						<form id="addform2" method="post">
							<div class="panel panel-flat">
								<div class="panel-body">
									<fieldset>
										<div class="row">
											<div class="col-md-12">
												<div class="form-group">
													<label>Select Employee :</label>
													<div class="multi-select-full">
														<select class="multiselect-select-all" multiple="multiple"
															name="emp_id[]">
															<?php foreach ($employee_list as $value1) { ?>
															    <option value="<?= $value1->id ?>"><?= $value1->name;?></option>
															<?php } ?>
														</select>
													</div>
												</div>
											</div>
										</div>
									</fieldset>
									<fieldset>
										<div class="row">
											<div class="col-md-12">
												<div class="form-group">
													<label>Select Shift :</label>
													<select class="select-search form-control" name="shift_timing">
														<span class="caret"></span>
														<option value="">Select Shift</option>
														<?php foreach ($shift_list as $res) { ?>
                                                            <option value="<?= $res->id ?>">
                                                                <?= $res->shift_title.' -  '.$res->from_timing.' : '.$res->to_timing ?>
                                                            </option>
														<?php } ?>
													</select>
												</div>
											</div>
										</div>
									</fieldset>
									<br/>
									<div class="text-right">
										<button type="submit" class="btn btn-primary">Submit <i class="icon-arrow-right14 position-right"></i></button>
										<span id="AssignShiftPreview"></span>
									</div>
								</div>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
        <!-- All Pop-Up End -->

        <!-- END MAIN CONTAINER -->

        <!-- BEGIN FOOTER -->
        <?php $this->load->view('Admin/includes/n-footer') ?>
        <!-- END FOOTER -->

        <script>
            $('#role_id').select2();
            $('#employee_id').select2();

            var cheque_number = 1;
            $('#attachSupport').click(function() {
                //add more file
                var moreUploadTag = '';
                moreUploadTag +=
                    '<div class="form-group row"><label class="control-label lable-center col-sm-3 lable-center" for="email">Designation <span style="color: red;">*</span></label><div class="col-sm-8"><input type="text" class="form-control" id="designation' +
                    cheque_number +
                    '" name="designation[]" placeholder="Enter designation name" maxlength="50"></div><div class="col-sm-1 mt-2 pl-0" ><button type="button" class="btn btn-danger removeButton" onclick="del_file(' +
                    cheque_number + ')"><i class=" icon-trash"></i></button></div></div>';
                $('<dl id="delete_file' + cheque_number + '">' + moreUploadTag + '</dl>').appendTo('#moreSupportUpload');
                cheque_number++;
            });

            function del_file(eleId) {
                var ele = document.getElementById("delete_file" + eleId);
                ele.parentNode.removeChild(ele);
            }
            $(document).ready(function() {
                $('#TypeForm').bootstrapValidator({
                    message: 'This value is not valid',
                    fields: {
                        department: {
                            validators: {
                                notEmpty: {
                                    message: 'Please Enter Department'
                                }
                            }
                        },
                    }
                });
            });


            $(document).ready(function(e) {
                $("#TypeForm").on('submit', (function(e) {
                    //e.preventDefault();
                    if (e.isDefaultPrevented()) {
                        //alert('invalid');
                    } else {

                        $.ajax({
                            url: "<?= base_url(); ?>admin/Master/add_department_designation",
                            type: "POST",
                            data: new FormData(this),
                            contentType: false,
                            cache: false,
                            processData: false,
                            success: function(data) {

                                $(function() {
                                    new PNotify({
                                        title: 'Department / Designation',
                                        text: 'Added  Successfully',
                                        type: 'success'
                                    });
                                });

                                setTimeout(function() {
                                    window.location =
                                        "<?php echo site_url('admin/Master/department_designation'); ?>";
                                }, 1000);


                            },
                            error: function() {
                                alert('fail');
                            }
                        });
                    }
                    return false;

                }));
            });
            /* Start Manage User */

            $(document).ready(function() {
                $("#show_hide_password_user a").on('click', function(event) {
                    event.preventDefault();
                    if ($('#show_hide_password_user input').attr("type") == "text") {
                        $('#show_hide_password_user input').attr('type', 'password');
                        $('#show_hide_password_user i').addClass("icon-eye-blocked");
                        $('#show_hide_password_user i').removeClass("icon-eye");
                    } else if ($('#show_hide_password_user input').attr("type") == "password") {
                        $('#show_hide_password_user input').attr('type', 'text');
                        $('#show_hide_password_user i').removeClass("icon-eye-blocked");
                        $('#show_hide_password_user i').addClass("icon-eye");
                    }
                });
            });

            $(function() {
                $('#joining_date').datetimepicker({
                    format: 'DD MMMM, YYYY',
                    maxDate: 'now',
                    useCurrent: true
                });
            });
            $('#department_users').change(function() {
                getDepartment();
            });

            function getDepartment() {
                var department = $("#department_users").val();

                $.ajax({
                    url: "<?php echo site_url('admin/Users/getDepartmentId'); ?>",
                    dataType: "html",
                    type: "POST",
                    data: {
                        department: department
                    },
                    success: function(data) {
                        $('#designation_users').html(data);
                    }
                });
            }

            function readURL(input) {
                if (input.files && input.files[0]) {
                    var reader = new FileReader();
                    reader.onload = function(e) {
                        $('#blah').attr('src', e.target.result);
                    }
                    reader.readAsDataURL(input.files[0]);
                }
            }
            $("#imgInp").change(function() {
                readURL(this);
            });

            var a = 0;
            //binds to onchange event of your input field
            $('#imgInp').bind('change', function() {
                var ext = $('#imgInp').val().split('.').pop().toLowerCase();
                if ($.inArray(ext, ['gif', 'png', 'jpg', 'jpeg']) == -1) {
                    $('#error1').slideDown("slow");
                    $('#error2').slideUp("slow");
                    a = 0;
                } else {
                    var picsize = (this.files[0].size);
                    if (picsize > 1000000) {
                        $('#error2').slideDown("slow");
                        a = 0;
                    } else {
                        a = 1;
                        $('#error2').slideUp("slow");
                    }
                    $('#error1').slideUp("slow");

                }
            });

            $(document).ready(function() {
                $('#ManageUserForm')
                    .find('[name="gender"]')
                    .multiselect()
                    .end()
                    .find('[name="module_ids"]')
                    .multiselect({
                        // Re-validate the multiselect field when it is changed
                        onChange: function(element, checked) {
                            $('#ManageUserForm').bootstrapValidator('revalidateField', 'module_ids');
                        }
                    })
                    .end()
                    .bootstrapValidator({
                        // Exclude only disabled fields
                        // The invisible fields set by Bootstrap Multiselect must be validated
                        excluded: ':disabled',
                        fields: {
                            gender: {
                                validators: {
                                    notEmpty: {
                                        message: 'The gender is required'
                                    }
                                }
                            },
                            'module_ids2[]': {
                                validators: {
                                    notEmpty: {
                                        message: 'Please Select Modules'
                                    }
                                }
                            },
                            name: {
                                validators: {
                                    notEmpty: {
                                        message: 'Please Enter Full Name'
                                    }
                                }
                            },
                            password: {
                                validators: {
                                    notEmpty: {
                                        message: 'Please Enter Password'
                                    }
                                }
                            },
                            email: {
                                validators: {
                                    notEmpty: {
                                        message: 'Please Enter Email Id'
                                    },
                                    regexp: {
                                        regexp: '^[^@\\s]+@([^@\\s]+\\.)+[^@\\s]+$',
                                        message: 'Please Enter Valid Email Id'
                                    }
                                }
                            },
                            mobile_no: {
                                validators: {
                                    notEmpty: {
                                        message: 'Please Enter Mobile Number'
                                    }
                                }
                            },
                        }
                    });
            });

            $(document).ready(function(e) {
                $("#ManageUserForm").on('submit', (function(e) {
                    if (e.isDefaultPrevented()) {} else {
                        $.ajax({
                            url: "<?php echo site_url('admin/Users/Add_user'); ?>",
                            type: "POST",
                            data: new FormData(this),
                            contentType: false,
                            cache: false,
                            processData: false,
                            success: function(data) {
                                // alert(data);

                                $(function() {
                                    new PNotify({
                                        title: 'Add User',
                                        text: 'Added  Successfully',
                                        type: 'success'
                                    });
                                });

                                setTimeout(function() {
                                    window.location =
                                        "<?php echo site_url('admin/Users'); ?>";
                                }, 1000);

                            },
                            error: function() {
                                alert('error occured');
                            }
                        });
                    }
                    return false;

                }));
            });

            function checkmail() {
                // var mobileno=$("#mobileno").val();
                var x = $("#email").val();

                var datastring = 'email_id=' + x;
                //alert(datastring);
                $.ajax({
                    type: "post",
                    url: "<?php echo site_url('admin/Users/check_existmail'); ?>",
                    cache: false,
                    data: datastring,
                    success: function(data) {
                        // console.log(data);
                        // alert(data);
                        if (data == 1) {
                            $('#sign-in-button').prop('disabled', true);
                            $("#mail_error").html('Email is already exist');
                        } else {
                            $('#sign-in-button').prop('disabled', false);
                            $("#mail_error").html('');
                        }
                    }
                });
            }
            /* End Manage User */

            /* Start Manage User */
            $('#roelPermissionForm').bootstrapValidator({
                message: 'This value is not valid',
                fields: {
                    role: {
                        validators: {
                            notEmpty: {
                                message: 'Role is Required'
                            }
                        }
                    },
                    role_description: {
                        validators: {
                            notEmpty: {
                                message: 'Role Description is Required'
                            }
                        }
                    },
                }
            });
            $(document).ready(function(e) {
                $("#roelPermissionForm").on('submit', (function(e) {
                    //e.preventDefault();
                    if (e.isDefaultPrevented()) {
                        //alert('invalid');
                    } else {
                        $("#roelPermissionPreview").show();
                        $("#roelPermissionPreview").html(
                            '<img src="<?= base_url() ?>assets/images/default.gif" style="height:30px;width:30px;" />'
                        );
                        $('#submitBtn').prop('disabled', true);
                        $.ajax({
                            url: "<?php echo site_url('admin/UserPermission/SetRolePermission'); ?>",
                            type: "POST",
                            data: new FormData(this),
                            contentType: false,
                            cache: false,
                            processData: false,
                            success: function(data) {
                                $("#roelPermissionPreview").hide();
                                $('#submitBtn').removeAttr('disabled');
                                $(function() {
                                    new PNotify({
                                        title: 'Assign Module Permission',
                                        text: 'Permission Set Successfully',
                                        type: 'success'
                                    });
                                });

                                setTimeout(function() {
                                    window.location =
                                        "<?php echo site_url('admin/UserPermission/PermissionRole'); ?>";
                                }, 2000);
                            },
                            error: function() {
                                alert('fail');
                            }
                        });

                    }
                    return false;
                }));
            });
            /* End Manage User */

            /* Start Copy Permission */
            $('#CopyPermission').bootstrapValidator({
                message: 'This value is not valid',
                fields: {
                    role_id: {
                        validators: {
                            notEmpty: {
                                message: 'Plese Select Role'
                            }
                        }
                    },
                    employee_id: {
                        validators: {
                            notEmpty: {
                                message: 'Plese Select Employee'
                            }
                        }
                    },
                }
            });
            $(document).ready(function(e) {
                $("#CopyPermission").on('submit', (function(e) {
                    //e.preventDefault();
                    if (e.isDefaultPrevented()) {
                        //alert('invalid');
                    } else {
                        $("#CopyPermissionPreview").show();
                        $("#CopyPermissionPreview").html('<img src="<?= base_url() ?>assets/images/default.gif" style="height:30px;width:30px;" />');
                        $.ajax({
                            url: "<?php echo site_url('admin/UserPermission/CopyPermission'); ?>",
                            type: "POST",
                            data: new FormData(this),
                            contentType: false,
                            cache: false,
                            processData: false,
                            success: function(data) {
                                $("#CopyPermissionPreview").hide();
                                $(function() {
                                    new PNotify({
                                        title: 'Copy Permission',
                                        text: 'Copy Permission Set Successfully',
                                        type: 'success'
                                    });
                                });

                                setTimeout(function() {
                                    window.location =
                                        "<?php echo site_url('admin/UserPermission'); ?>";
                                }, 2000);
                            },
                            error: function() {
                                alert('fail');
                            }
                        });

                    }
                    return false;
                }));
            });
            /* End Copy Permission */
            $(function() {
                $('#from_timing').datetimepicker({
                    format: 'LT'
                });
                $('#to_timing').datetimepicker({
                    format: 'LT'
                });
            });
            $("#from_timing").blur(function() {
                $('#addform').bootstrapValidator('revalidateField', 'from_timing');
            });
            $("#to_timing").blur(function() {
                $('#addform').bootstrapValidator('revalidateField', 'to_timing');
            });
            $(document).ready(function() {
                $('#addform').bootstrapValidator({
                    message: 'This value is not valid',
                    fields: {
                        shift_title: {
                            validators: {
                                notEmpty: {
                                    message: 'Shift Name Required'
                                }
                            }
                        },
                        from_timing: {
                            validators: {
                                notEmpty: {
                                    message: 'From Timing Required'
                                }
                            }
                        },
                        to_timing: {
                            validators: {
                                notEmpty: {
                                    message: 'To Timing Required'
                                }
                            }
                        },

                    }
                });
            });
            $(document).ready(function (e) {
				$("#addform").on('submit', (function (e) {
					//e.preventDefault();
					if (e.isDefaultPrevented()) {
						//alert('invalid');
					} else {
						$.ajax({
							url: "<?php echo site_url('admin/Tracking/add_master_shift'); ?>",
							type: "POST",
							data: new FormData(this),
							contentType: false,
							cache: false,
							processData: false,
							success: function (data) {
								// alert(data);
								$(function () {
									new PNotify({
										title: 'Shift Form',
										text: 'Shift Added Successfully',
										type: 'success'
									});
								});

								setTimeout(function () {
									window.location =
										"<?php echo site_url('admin/Tracking/MasterShift'); ?>";
								}, 1000);
							},
							error: function () {
								alert('fail');
							}
						});
					}
					return false;
				}));
			});

            $(document).ready(function () {
				FromLocationValidator = {
					row: '.col-md-12',
					validators: {
						notEmpty: {
							message: 'From Location is required'
						}
					}
				};

				$('#addform2').bootstrapValidator({
					message: 'This value is not valid',
					fields: {
						'emp_id[]': FromLocationValidator,
						shift_timing: {
							validators: {
								notEmpty: {
									message: 'Please Select Shift'
								}
							}
						}
					}
				});
			});

			$(document).ready(function (e) {
				$("#addform2").on('submit', (function (e) {
					//e.preventDefault();
					if (e.isDefaultPrevented()) {
						//alert('invalid');
					} else {
						var formresult = new FormData(this);
						$.ajax({
							url: "<?php echo site_url('admin/Tracking/add_shift'); ?>",
							type: "POST",
							data: new FormData(this),
							contentType: false,
							cache: false,
							processData: false,
							success: function (data) {
								// alert(data);
								$(function () {
									new PNotify({
										title: 'Assign Shift',
										text: 'Shift Assigned Successfully',
										type: 'success'
									});
								});
								setTimeout(function () {
									window.location =
										"<?php echo site_url('admin/Tracking/shift');?>";
								}, 1000);

							},
							error: function () {
								alert('fail');
							}
						});
					}
					return false;
				}));
			});
        </script>

</body>

</html>