   <script type="text/javascript" src="<?= base_url() ?>assets/admin/assets/js/pages/form_multiselect.js"></script>

   <script type="text/javascript" src="<?= base_url() ?>assets/admin/assets/js/pages/form_layouts.js"></script>
   <script type="text/javascript" src="<?= base_url() ?>assets/admin/assets/js/plugins/forms/styling/uniform.min.js"></script>

    <style>
        .input-group-addon {
            padding: 7px 17px;
            font-size: 13px;
            font-weight: normal;
            line-height: 1;
            color: #333333;
            text-align: center;
            background-color: #fcfcfc;
            border: 1px solid #ddd;
            border-radius: 3px;
        }
        
    </style>

   <?php
    foreach ($edit_user->result() as $value) {
        $ids = array();
        $selected = $value->module_ids;

        $selectedregion = trim($selected, ',');
        $explode = explode(",", $selectedregion);
        for ($i = 0; $i < count($explode); $i++) {
            $re_array_id = $explode[$i];
            array_push($ids, $re_array_id);
        }

    ?>
       <form id="EditUserForm1" enctype="multipart/form-data" method="post">
           <input type="hidden" value="<?= $value->id ?>" id="user_id" name="user_id">
           <div class="panel panel-flat">
               <div class="panel-body">
                   <fieldset>
                       <div class="row">
                           <div class="col-md-4">
                               <div class="form-group">
                                   <label>Name: <span style="color: red;">*</span></label>
                                   <input type="text" class="form-control" value="<?= $value->name ?>" id="name" name="name" placeholder="Enter Name" maxlength="35">
                               </div>
                           </div>
                           <div class="col-md-4">
                               <div class="form-group">
                                   <label>Email: <span style="color: red;">*</span></label>
                                   <input type="text" class="form-control" value="<?= $value->email ?>" id="email1" name="email" placeholder="Enter Email" maxlength="35" onkeyup="checkmail1()" onkeypress="checkmail1()">
                                   <span id="mail_error1" style="color:red;" maxlength="40"> </span>
                               </div>
                           </div>
                           <div class="col-md-4">
                               <div class="form-group">
                                   <label>Password: <span style="color: red;">*</span></label>
                                   
                                   <div class="shbtn" id="show_hide_password" style="display: flex;">
                                        <input type="password" class="form-control" name="password" placeholder="Enter Password" autocomplete="off" style="border-right: 0px;" value="<?= $value->Password ?>">
                                        <div class="input-group-addon">
                                            <a style="margin-left: -6px;"><i class="icon-eye" aria-hidden="true" style="margin-top:2px"></i></a>
                                        </div>
                                    </div>
                               </div>
                           </div>
                       </div>
                   </fieldset>

                   <fieldset>
                       <div class="row">
                           <div class="col-md-4">
                               <div class="form-group">
                                   <label>Mobile No.: <span style="color: red;">*</span></label>
                                   <input type="text" class="form-control" value="<?= $value->mobile_no ?>" id="mobile_no1" name="mobile_no" placeholder="Enter Mobile no" onkeypress='return event.charCode >= 48 && event.charCode <= 57 || event.charCode == 43 || event.charCode == 45' maxlength="15" onkeyup="checkmobile1()">
                                   <span id="mobile_error1" style="color:red;" maxlength="40"> </span>
                               </div>
                           </div>
                           <div class="col-md-4">
                                <div class="form-group">
                                    <label>Emp Id: </label>
                                    <!-- <input type="hidden" name="custom_id" id="custom_id" value="<?= $value->custom_id; ?>"> -->
                                    <input type="text" class="form-control" id="emp_id_edit" name="emp_id" placeholder="Enter Emp Id" value="<?= $value->emp_id; ?>" onblur="chk_emp_code_edit()" >
                                    <span id="error_emp_code_edit" style="color: red;font-size: 12px"></span>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label>Joining Date: </label>
                                    <input type="text" class="form-control" id="joining_date_edit" name="joining_date" placeholder="Enter Joining Date" value="<?= date('d M Y',strtotime($value->joining_date)); ?>">
                                </div>
                            </div>
                       </div>
                   </fieldset>
                   <fieldset>
                       <div class="row">
                        <div class="col-md-4">
                                <div class="form-group">
                                    <label>department_id:</label>
                                    <div class="media no-margin-top">
                                        <select name="department_id" id="department_id" class="form-control">
                                            <option value="">Select Department</option>
                                            <?php foreach ($department as $dp) { ?>
                                                <option value="<?= $dp->dep_id; ?>" <?php echo $dep = ( $value->department == $dp->dep_id) ? 'selected' : '' ;?> ><?php echo $dp->department_name; ?></option>
                                            <?php } ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label>Designation:</label>
                                    <div class="media no-margin-top">
                                        <select name="designation_id" id="designation_id" class="form-control">
                                            <option value="">Select Designation</option>
                                            <?php foreach ($designation as $dp) { ?>
                                                <option value="<?= $dp->deg_id; ?>" <?php echo $dep = ( $value->designation == $dp->deg_id) ? 'selected' : '' ;?> ><?php echo $dp->designation_name; ?></option>
                                            <?php } ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                           <div class="col-md-4">
                               <div class="form-group">
                                   <label>Profile:</label>
                                   <div class="media no-margin-top">
                                       <?php if (!empty($value->profile_img)) { ?>
                                           <div class="media-left">
                                               <a href="#"><img src="<?= base_url() ?>assets/admin/assets/images/users/<?= $value->profile_img ?>" style="width: 58px; height: 58px;" class="img-rounded" alt="" id="u_image"></a>
                                           </div>
                                       <?php } else { ?>

                                           <div class="media-left">
                                               <a href="#"><img src="<?= base_url() ?>assets/admin/assets/images/testimonial/dummy.png" style="width: 58px; height: 58px;" class="img-rounded" alt=""></a>
                                           </div>
                                       <?php } ?>
                                       <div class="media-body">
                                           <input type="file" class="file-styled" id="imgtemp123" name="fileup">
                                           <span><?= $value->profile_img ?></span>
                                       </div>
                                   </div>
                               </div>
                           </div>
                       </div>
                   </fieldset>
                   <br />
                   <div class="text-right">
                       <button type="submit" class="btn btn-primary">Update <i class="icon-arrow-right14 position-right"></i></button>
                       <span id="preview2"></span>
                   </div>
               </div>
           </div>
       </form>

   <?php } ?>
   <script>
		$(document).ready(function() {
			$("#show_hide_password a").on('click', function(event) {
				event.preventDefault();
				if($('#show_hide_password input').attr("type") == "text"){
					$('#show_hide_password input').attr('type', 'password');
					$('#show_hide_password i').addClass( "icon-eye-blocked" );
					$('#show_hide_password i').removeClass( "icon-eye" );
				}else if($('#show_hide_password input').attr("type") == "password"){
					$('#show_hide_password input').attr('type', 'text');
					$('#show_hide_password i').removeClass( "icon-eye-blocked" );
					$('#show_hide_password i').addClass( "icon-eye" );
				}
			});
		});
        function chk_emp_code_edit() {
            emp_code = $('#emp_id_edit').val();
            if (emp_code == '') {
                $('#error_emp_code_edit').empty();
                $('#error_emp_code_edit').html('Employee Id is required');
                $('#emp_id_edit').focus();
            }else{
                $.ajax({
                    url: "<?php echo site_url('admin/Users/chk_emp_code'); ?>",
                    dataType: "html",
                    type: "POST",
                    data: {
                        emp_code: emp_code
                    },
                    success: function(data) {
                        // alert(data);
                        if (data == 1) {
                            $('#error_emp_code_edit').empty();
                            $('#error_emp_code_edit').html('Please add another employee code this code assign to a user.');
                            $('#emp_id_edit').focus();
                        }else{
                            $('#error_emp_code_edit').hide();
                        }
                    }
                });
            }
        }
	</script>
   <script>
       $(function() {
            $('#joining_date_edit').datetimepicker({
                format: 'DD MMMM, YYYY',
                maxDate: 'now',
                useCurrent: true
            });
        });
        $('#department_id').change(function() {
            getDepartment();
        });

        function getDepartment() {
            var department_id = $("#department_id").val();
            $.ajax({
                url: "<?php echo site_url('admin/Users/getDepartmentId'); ?>",
                dataType: "html",
                type: "POST",
                data: {
                    department: department_id
                },
                success: function(data) {
                    $('#designation_id').html(data);
                }
            });
        }
    </script>
   <script type="text/javascript">
       function readURL(input) {
           if (input.files && input.files[0]) {
               var reader = new FileReader();

               reader.onload = function(e) {
                   $('#u_image').attr('src', e.target.result);
               }

               reader.readAsDataURL(input.files[0]);
           }
       }

       $("#imgtemp123").change(function() {
           // alert();
           readURL(this);
       });
   </script>



   <script type="text/javascript">
       var a = 0;
       //binds to onchange event of your input field
       $('#imgtemp123').bind('change', function() {

           var ext = $('#imgtemp123').val().split('.').pop().toLowerCase();
           if ($.inArray(ext, ['gif', 'png', 'jpg', 'jpeg']) == -1) {
               $('#error14').slideDown("slow");
               $('#error24').slideUp("slow");
               a = 0;
           } else {
               var picsize = (this.files[0].size);
               if (picsize > 1000000) {
                   $('#error24').slideDown("slow");
                   a = 0;
               } else {
                   a = 1;
                   $('#error24').slideUp("slow");
               }
               $('#error14').slideUp("slow");

           }
       });
   </script>



   <script type="text/javascript">
       $(document).ready(function() {
           $('#EditUserForm1').bootstrapValidator({
               message: 'This value is not valid',
               fields: {
                   name: {
                       validators: {
                           notEmpty: {
                               message: 'Please Enter Full Name'
                           }
                       }
                   },
                   password: {
                       validators: {
                           notEmpty: {
                               message: 'Please Enter Password'
                           }
                       }
                   },

                   mobile_no: {
                       validators: {
                           notEmpty: {
                               message: 'Please Enter Mobile Number'
                           }
                       }
                   },

                   file: {
                       validators: {
                           file: {
                               extension: 'jpg,png,jpeg',
                               maxSize: 2097152, //2 mb  maxsize
                               message: 'Image Max File size should be upto 2 MB. Supported Format (jpg,png,jpeg)'
                           }
                       }
                   },

                   email: {
                       validators: {
                           notEmpty: {
                               message: 'Email is required.'
                           },
                           regexp: {
                               regexp: '^[^@\\s]+@([^@\\s]+\\.)+[^@\\s]+$',
                               message: 'The value is not a valid email address'
                           }
                       }
                   }
               }
           });
       });
   </script>
   <script type="text/javascript">
       $(document).ready(function(e) {

           $("#EditUserForm1").on('submit', (function(e) {
               //e.preventDefault();
               if (e.isDefaultPrevented()) {
                   //alert('invalid');
                   return false;
               } else {

                   $.ajax({
                       url: "<?php echo site_url('admin/Users/Edit_Add_user'); ?>",
                       type: "POST",
                       data: new FormData(this),
                       contentType: false,
                       cache: false,
                       processData: false,
                       success: function(data) {
                           // alert(data);
                           PNotify.removeAll()
                           new PNotify({
                               title: 'Update User Form',
                               text: 'Updated  Successfully !',
                               type: 'success'
                           });
                           setTimeout(function() {
                               window.location = "<?php echo site_url('admin/Users'); ?>";
                           }, 1000);

                           return false;

                       },
                       error: function() {
                           alert('fail');
                       }
                   });
               }
               return false;

           }));
       });
   </script>

   <script type="text/javascript">
       function checkmail1() {
           // alert();
           // var mobileno=$("#mobileno").val();
           var x = $("#email1").val();

           var datastring = 'email_id=' + x;
           //alert(datastring);
           $.ajax({
               type: "post",
               url: "<?php echo site_url('admin/Users/check_existmail'); ?>",
               cache: false,
               data: datastring,
               success: function(data) {
                   // console.log(data);
                   // alert(data);
                   if (data == 1) {
                       $('#sign-in-button1').prop('disabled', true);
                       $("#mail_error1").html('Email is already exist');
                   } else {
                       $('#sign-in-button1').prop('disabled', false);
                       $("#mail_error1").html('');
                   }
               }
           });
       }
   </script>

   <script type="text/javascript">
       function checkmobile1() {
           // var mobileno=$("#mobileno").val();
           var x = $("#mobile_no1").val();

           var datastring = 'mobile_no=' + x;
           //alert(datastring);
           $.ajax({
               type: "post",
               url: "<?php echo site_url('admin/Users/check_mobile'); ?>",
               cache: false,
               data: datastring,
               success: function(data) {
                   // console.log(data);
                   // alert(data);
                   if (data == 1) {
                       $('#sign-in-button1').prop('disabled', true);
                       $("#mobile_error1").html('Mobile number is already exist');
                   } else {
                       $('#sign-in-button1').prop('disabled', false);
                       $("#mobile_error1").html('');
                   }
               }
           });
       }
   </script>
   <!--===================================== Email/Mobile number validation(already exist or not) =====================================-->