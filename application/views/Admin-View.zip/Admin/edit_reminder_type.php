<script type="text/javascript" src="<?= base_url() ?>assets/admin/assets/js/pages/form_layouts.js"></script>
<script type="text/javascript" src="<?= base_url() ?>assets/admin/assets/js/plugins/forms/styling/uniform.min.js"></script>

<?php if ($editschedule['user_name'] == 'Na') {   ?>
        <div class="panel-body" style="background: #c6f1d9; color: #000; font-size: 15px; margin-bottom: 4%; border-radius: 5px;">  
            <div class="form-group" style="margin-bottom: -1%;display: flex;">
                <label class="control-label col-sm-6" for="email" style="margin-left: 3%;font-weight: 600;"> Module Type: </label>
                <div class="col-sm-6">
                    <strong style="font-weight: 600;">
                        <?= $editschedule['module_name'] ?>
                    </strong>
                </div>
            </div>
        </div>
    <?php   }else { ?>
        <div class="panel-body" style="background: #c6f1d9; color: #000; font-size: 15px; margin-bottom: 4%; border-radius: 5px;">  
            <div class="form-group" style="margin-bottom: -1%;display: flex;">
                <label class="control-label col-sm-7" for="email" style="margin-left: 3%;font-weight: 600;"> Module Type: (<?= $editschedule['module_name'] ?>)</label>
                <div class="col-sm-12">
                    <strong style="font-weight: 600;">
                        <?= $editschedule['user_name'] ?>
                    </strong>
                </div>
            </div>
        </div>  
    <?php      }    ?>
    
    <form class="form-horizontal" id="EditReminder">
        <input type="hidden" class="form-control" id="reminder_id" name="reminder_id" value="<?= $editschedule['reminder_id'] ?>">
        <input type="hidden" class="form-control" id="module_name" name="module_name" value="<?= $editschedule['module_name'] ?>">
        <div class="row">
            <div class="form-group">
                <label class="control-label col-sm-4" for="email">Reminder Title <span style="color: red;">*</span></label>
                <div class="col-sm-8">
                    <input type="text" class="form-control" id="reminder_title" name="reminder_title" placeholder="Enter Reminder Title" maxlength="50" value="<?= $editschedule['reminder_title'] ?>">
                </div>
            </div>

            <div class="form-group">
                <label class="control-label col-sm-4" for="email">Reminder Date<span style="color: red;">*</span></label>
                <div class="col-sm-8">
                    <div class="input-group date">
                        <span class="input-group-addon"><i class="icon-calendar"></i></span>
                        <input type="text" class="form-control schedule_date_select" id="edit_reminder_date" name="reminder_date" value="<?= date('d M Y', strtotime($editschedule['reminder_date'])); ?>" placeholder="Enter Reminder Date" autocomplete="off">
                    </div>
                </div>
            </div>
            <div class="form-group">
                <label class="control-label col-sm-4" for="email">Reminder Time <span style="color: red;">*</span></label>
                <div class="col-sm-8 clockpicker" data-placement="left" data-align="top" data-autoclose="true">
                    <div class="input-group date">
                        <span class="input-group-addon"><i class="icon-watch2"></i></span>
                        <input type="text" class="form-control" id="reminder_time" name="reminder_time" placeholder="Please select Reminder Time" autocomplete="off" value="<?= date('H:i', strtotime($editschedule['reminder_time'])); ?>">
                    </div>
                </div>
            </div>

            <div class="form-group">
                <label class="control-label col-sm-4" for="email">User </label>
                <div class="col-sm-8">
                    <select class="form-control" name="user_id[]" id="edit_rmd_user_id" multiple>
                        <option value="">Select Company</option>
                        <?php
                        $ids = explode(',', $editschedule['user_id']);
                        foreach ($getUserSysyemList as $value1) {
                            $user_id = $value1->id;
                            if (in_array($user_id, $ids)) {
                        ?>
                            <option value="<?= $user_id ?>" selected><?= $value1->name ?></option>
                        <?php   } else { ?>
                            <option value="<?= $user_id ?>"><?= $value1->name ?></option>
                        <?php   }   }    ?>
                    </select>
                </div>
            </div>
            <div class="form-group">
                <label class="control-label col-sm-4" for="email">Reminder Before Time <span style="color: red;">*</span></label>
                <div class="col-sm-8">
                    <select class="form-control" name="reminder_before_time" id="reminder_before_time">
                        <option value="">Select Before Time</option>
                        <?php foreach ($getTimeSlot as $RBT) { ?>
                            <option value="<?= $RBT->time_slot ?>" <?= $rbt = ($editschedule['reminder_before_time'] == $RBT->time_slot.':00') ? 'selected' : '' ?> ><?= $RBT->time_slot ?></option>
                        <?php  } ?>
                    </select>
                </div>
            </div>

            <div class="form-group">
                <label class="control-label col-sm-4" for="email">Notes <span style="color: red;">*</span></label>
                <div class="col-sm-8">
                    <textarea class="form-control" rows="2" id="reminder_note" name="reminder_note" placeholder="Enter Comments" maxlength="500"><?= $editschedule['reminder_note'] ?></textarea>
                </div>
            </div>
                            
            <div class="form-group">
                <label class="control-label col-sm-4" for="email">Recurring <span style="color: red;">*</span></label>
                <div class="col-sm-8">
                    <select class="form-control" name="edit_recurring_set" id="edit_recurring_set" onchange="showEditDataRecurring()">
                        <option value="">Select Recurring</option>
                        <option value="0" <?= $rbt = ($editschedule['recurring_set'] == 0) ? 'selected' : '' ?> >No</option>
                        <option value="1" <?= $rbt = ($editschedule['recurring_set'] == 1) ? 'selected' : '' ?> >Yes</option>
                    </select>
                </div>
            </div>
            <?php
                if ($editschedule['recurring_set'] == 1) {
                    $style = 'display: block';
                }else {
                    $style = 'display: none';
                }
            ?>
            <div id="edit_recuuring_data" style="<?= $style ?>;clear:both">
                <div class="form-group">
                    <label class="control-label col-sm-4" for="email">Recurring Interval </label>
                    <div class="col-sm-8">
                        <select class="form-control" name="interval_type" id="interval_type">
                            <option value="">Select Recurring Interval</option>
                            <option value="day" <?= $rbt = ($editschedule['interval_type'] == 'day') ? 'selected' : '' ?> >Day</option>
                            <option value="week" <?= $rbt = ($editschedule['interval_type'] == 'week') ? 'selected' : '' ?> >Week</option>
                            <option value="fortnightly" <?= $rbt = ($editschedule['interval_type'] == 'fortnightly') ? 'selected' : '' ?> >Fortnightly</option>
                            <option value="monthly" <?= $rbt = ($editschedule['interval_type'] == 'monthly') ? 'selected' : '' ?> >Monthly</option>
                            <option value="quaterly" <?= $rbt = ($editschedule['interval_type'] == 'quaterly') ? 'selected' : '' ?> >Quaterly</option>
                            <option value="half-quarterly" <?= $rbt = ($editschedule['interval_type'] == 'half-quarterly') ? 'selected' : '' ?> >Half Quarterly</option>
                            <option value="year" <?= $rbt = ($editschedule['interval_type'] == 'year') ? 'selected' : '' ?>>Year</option>
                        </select>                       
                    </div>
                </div>
                <div class="form-group">
                    <label class="control-label col-sm-4" for="email">Recurring EOD</label>
                    <div class="col-sm-8">
                        <input type="text" class="form-control" id="edit_recurring_eod" name="edit_recurring_eod" placeholder="Enter Recurring EOD" autocomplete="off" value="<?= date('d M Y', strtotime($editschedule['recurring_eod'])); ?>">
                    </div>
                </div>
            </div>

            <div class="form-group">
                <div class="col-md-offset-2 col-md-10">
                    <button type="submit" class="btn btn-primary  pull-right">Submit&nbsp;<i class="icon-arrow-right14 position-right"></i> </button>
                    <span id="preview"></span>
                </div>
            </div>
        </div>
    </form>

<script type="text/javascript">
    $(document).ready(function(){
        $('#edit_recurring_eod').datetimepicker({
            format: 'DD MMMM, YYYY',
            useCurrent: true,
        });
    });
    function showEditDataRecurring(){
        if($('#edit_recurring_set').val() == 1){
            $('#edit_recuuring_data').show();
        }else{
            $('#edit_recuuring_data').hide();
        }
    }
    $(document).ready(function() {
        $("#edit_rmd_user_id").select2({
            dropdownParent: $("#modal_default1")
        });
    });

    $('#edit_reminder_date').change(function() {
        $('#EditReminder').bootstrapValidator('revalidateField', 'edit_reminder_date');
    });

    $('#reminder_time').change(function() {
        $('#EditReminder').bootstrapValidator('revalidateField', 'reminder_time');
    });

    $(document).ready(function() {
        $('#edit_reminder_date').datetimepicker({
            format: 'DD MMMM, YYYY',
            useCurrent: true,
        });
        $('.clockpicker').clockpicker({
            placement: 'left',
            align: 'left',
            donetext: 'Done',
            minTime: '12:00'
        });
    });

    $(document).ready(function() {
        $('#EditReminder').bootstrapValidator({
            message: 'This value is not valid',
            fields: {
                reminder_date: {
                    validators: {
                        notEmpty: {
                            message: 'Please Enter Reminder Date'
                        }
                    }
                },
                reminder_time: {
                    validators: {
                        notEmpty: {
                            message: 'Please Enter Reminder Time'
                        }
                    }
                },
                reminder_title: {
                    validators: {
                        notEmpty: {
                            message: 'Please Enter Reminder Title'
                        }
                    }
                },
                reminder_before_time:{
                    validators: {
                        notEmpty: {
                            message: 'Please Select Reminder Before Time.'
                        }
                    }
                },
                reminder_note:{
                    validators: {
                        notEmpty: {
                            message: 'Please Select Reminder Before Time.'
                        }
                    }
                }
            }
        });
    });
</script>

<script type="text/javascript">
    $(document).ready(function(e) {
        $("#EditReminder").on('submit', (function(e) {
            //e.preventDefault();
            if (e.isDefaultPrevented()) {
                //alert('invalid');
            } else {
                $("#preview").show();
                $("#preview").html('<img src="<?= base_url() ?>assets/images/default.gif" style="height:30px;width:30px;" />');

                $.ajax({
                    url: "<?php echo site_url('admin/Reminder/update_reminder'); ?>",
                    type: "POST",
                    data: new FormData(this),
                    contentType: false,
                    cache: false,
                    processData: false,
                    success: function(data) {
                        $("#preview").hide();

                        $(function() {
                            new PNotify({
                                title: 'Reminder Form',
                                text: 'Updated  Successfully',
                                type: 'success'
                            });
                        });

                        setTimeout(function() {
                            window.location = "<?php echo site_url('admin/Reminder'); ?>";
                        }, 1000);


                    },
                    error: function() {
                        alert('fail');
                    }
                });
            }
            return false;

        }));
    });
</script>