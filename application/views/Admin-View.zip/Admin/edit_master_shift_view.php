

  <?php 

  foreach ($edit_shift as $shift) 
  {

  ?>
        <form  id="editform" method="post">
          <input type="hidden" name="id" value="<?= $shift->id;?>">
          <div class="panel panel-flat">
            <div class="panel-body">
              <fieldset>
                <div class="row">
                    <div class="col-md-12"> 
                      <div class="form-group">
                         <label>Shift Name : <sup style="color: red">*</sup></label>
                          <input type="text" class="form-control" name="shift_title" value="<?= $shift->shift_title; ?>" >
                      </div>
                    </div>          
                </div>
              </fieldset>
              <fieldset>
               <div class="row">
                 <div class="col-md-12"> 
                    <div class="form-group clockpicker"  data-autoclose="true">
                      <label>From Time :  <sup style="color: red">*</sup></label>
                       <input type="text" class="form-control" name="from_timing" id="from_timing" autocomplete="off"   value="<?= $shift->from_timing; ?>" >
                    </div>
                  </div>
                </div>
              </fieldset>
              <fieldset>
               <div class="row">
                 <div class="col-md-12"> 
                    <div class="form-group clockpicker"  data-autoclose="true">
                      <label>To Time :  <sup style="color: red">*</sup></label>
                       <input type="text" class="form-control" name="to_timing" id="to_timing" autocomplete="off"   value="<?= $shift->to_timing; ?>" >
                     </div>
                  </div>
                </div>
              </fieldset>                                                
             <br/>
            <div class="text-right">
            <button type="submit" class="btn btn-primary">Update<i class="icon-arrow-right14 position-right"></i></button>
            <span id="preview2"></span>
          </div>  
        </div>
      </div>
    </form>

<?php } ?>



<script type="text/javascript">
$('.clockpicker').clockpicker({
    placement: 'bottom',
    align: 'left',
    donetext: 'Done'
});
</script>

<script type="text/javascript">
$(document).ready(function() {
    $('#editform').bootstrapValidator({
        message: 'This value is not valid',
        fields: {
                   shift_title: {
                          validators: {
                              notEmpty: {
                                  message: 'Shift Name Required'
                              }
                      }
                  },
                   from_timing: {
                          validators: {
                              notEmpty: {
                                  message: 'From Timing Required'
                              }
                      }
                  },
                   to_timing: {
                          validators: {
                              notEmpty: {
                                  message: 'To Timing Required'
                              }
                      }
                  },
        }
    });
});
</script>



<script type="text/javascript">
  $(document).ready(function (e)
     {

       $("#editform").on('submit',(function(e)
           {  
             //e.preventDefault();
             if (e.isDefaultPrevented())
              {
                //alert('invalid');
              }
              else
              {
                  $.ajax({
                    url: "<?php echo site_url('admin/Tracking/update_master_shift'); ?>",
                    type: "POST",
                    data:  new FormData(this),
                    contentType: false,
                    cache: false,
                    processData:false,
                    success: function(data)
                      {
                        // alert(data);
                             if (data==1) 
                             {
                                     $(function(){
                                       new PNotify({
                                                    title: 'Update Shift',
                                                    text: 'Updated Successfully',
                                                    type: 'success'
                                                   });
                                      });

                                       setTimeout(function()
                                         {
                                             window.location="<?php echo site_url('admin/Tracking/MasterShift');?>";
                                         }, 1000);
                             }
                             else
                             {
                                  $(function(){
                                       new PNotify({
                                                    title: 'Shift Form',
                                                    text: 'Shift is already added on this date',
                                                    type: 'warning'
                                                   });
                                      });
                             }
                      },
                      error: function() 
                      {
                        alert('fail');
                        }           
                   });
              }
              return false;
          
          }));
      });
</script>


