
<hr/>

  <table id="example2" class="display" cellspacing="0">
    <thead>
      <tr>
        <th style="text-align: center;">#</th>
        <th style="text-align: center;">Company Name</th>
        <th style="text-align: center;">Location</th>
        <th style="text-align: center;">From</th>
        <th style="text-align: center;">To</th>
        <th style="text-align: center;">Interval</th>
      </tr>
    </thead>
    <tbody>
         <?php
              $i=1;
              foreach ($ClientReport as $res)  { ?>
              <tr class="gradeA">
                    <td style="text-align: center;"><?=  $i; ?></td>
                    <td style="text-align: center;"><?=  $res['company_name']; ?></td>
                    <td style="text-align: center;"><?=   $res['address']; ?></td>
                    <td style="text-align: center;"><?=  $res['from']; ?></td>
                    <td style="text-align: center;"><?=   $res['to']; ?></td>
                    <td style="text-align: center;"><?=   $res['interval']; ?></td>
              </tr>
        <?php $i++; } ?>
    </tbody>
  </table>