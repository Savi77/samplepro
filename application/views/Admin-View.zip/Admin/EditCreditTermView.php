

  <?php 

  foreach ($edit_data as $shift) 
  {

  ?>
        <form  id="editform" method="post">
          <input type="hidden" name="credit_id" value="<?= $shift->credit_id;?>">
          <div class="panel panel-flat">
            <div class="panel-body">
              <fieldset>
                <div class="row">
                    <div class="col-md-12"> 
                      <div class="form-group">
                         <label>Credit Name : <sup style="color: red">*</sup></label>
                          <input type="text" class="form-control" name="credit_name" value="<?= $shift->credit_name; ?>" >
                      </div>
                    </div>          
                </div>
              </fieldset>
              <fieldset>
               <div class="row">
                 <div class="col-md-12"> 
                    <div class="form-group clockpicker"  data-autoclose="true">
                      <label>Credit Days :  <sup style="color: red">*</sup></label>
                       <input type="text" class="form-control" name="credit_days" autocomplete="off"   value="<?= $shift->credit_days; ?>"  onkeypress='return event.charCode >= 48 && event.charCode <= 57 || event.charCode == 43 || event.charCode == 45' maxlength="15" >
                    </div>
                  </div>
                </div>
              </fieldset>
                                              
             <br/>
            <div class="text-right">
            <button type="submit" class="btn btn-primary">Update<i class="icon-arrow-right14 position-right"></i></button>
            <span id="preview_edit"></span>
          </div>  
        </div>
      </div>
    </form>

<?php } ?>



<script type="text/javascript">
$(document).ready(function() {
    $('#editform').bootstrapValidator({
        message: 'This value is not valid',
        fields: {
               credit_name: {
                      validators: {
                          notEmpty: {
                              message: 'Credit Name Required'
                          }
                  }
              },
               credit_days: {
                      validators: {
                          notEmpty: {
                              message: 'Credit Days Required'
                          }
                  }
              }
        }
    });
});
</script>



<script type="text/javascript">
  $(document).ready(function (e)
     {

       $("#editform").on('submit',(function(e)
           {  
             //e.preventDefault();
             if (e.isDefaultPrevented())
              {
                //alert('invalid');
              }
              else
              {
                $("#preview_upload").html('<img src="<?= base_url() ?>assets/images/default.gif" style="height:30px;width:30px;" alt="sending data...."/>');
                $("#preview_upload").show();      

                  $.ajax({
                    url: "<?php echo site_url('admin/CreditTerm/UpdateCreditTerm'); ?>",
                    type: "POST",
                    data:  new FormData(this),
                    contentType: false,
                    cache: false,
                    processData:false,
                    success: function(data)
                      {
                        $("#preview_upload").hide();      

                         $(function(){
                           new PNotify({
                                        title: 'Update Term',
                                        text: 'Updated Successfully !!',
                                        type: 'success'
                                       });
                          });

                           setTimeout(function()
                             {
                                 window.location="<?php echo site_url('admin/CreditTerm');?>";
                             }, 1000);
                      },
                      error: function() 
                      {
                        alert('fail');
                        }           
                   });
              }
              return false;
          
          }));
      });
</script>


