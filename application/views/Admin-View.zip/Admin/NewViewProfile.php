<?php
$new = array();
foreach ($allreports['report_preference'] as $row) {
    array_push($new, explode(',', $row));
}
?>
<!DOCTYPE html>
<html lang="en">

<?php $this->load->view('Admin/includes/n-header') ?>

<style>
    .widget-two {
        min-height: 200px !important;
    }

    th.Company-name {
        padding: 40px 40px !important;
    }

    /* Report Sharing */
    .container-boxes {
        padding-bottom: 90px;
        position: relative;
        display: flex;
        justify-content: center;
        flex-wrap: wrap;
        align-items: stretch;
        background-color: white;
        padding-top: 3rem;
    }

    .mbr-white {
        color: #ffffff;
    }

    .box-item {
        position: relative;
        box-shadow: #d2d2d2 0px 0px 15px;
        border-radius: 3px;
        margin-right: 1.5rem;
        width: 29%;
        padding: 0rem;
    }

    .icon-block-top span {
        background-color: #188ef4;
        padding: 1.5rem;
        position: absolute;
        border-radius: 80%;
        margin-top: -2.6rem;
        top: 0;
        left: 31px;
    }

    .display-2 {
        font-family: 'Montserrat', sans-serif;
        font-size: 1.8rem;
    }
</style>

<body>
    <!-- BEGIN LOADER -->
    <div id="load_screen">
        <div class="loader">
            <div class="loader-content">
                <div class="spinner-grow align-self-center"></div>
            </div>
        </div>
    </div>
    <!--  END LOADER -->

    <!--  BEGIN NAVBAR  -->
    <?php $this->load->view('Admin/includes/n-web-sidebar') ?>
    <!--  END NAVBAR  -->

    <!--  BEGIN MAIN CONTAINER  -->
    <div class="main-container" id="container">

        <div class="overlay"></div>
        <div class="search-overlay"></div>

        <!--  BEGIN Mobile SIDEBAR  -->
        <?php $this->load->view('Admin/includes/n-mobile-sidebar') ?>
        <!--  END Mobile SIDEBAR  -->

        <!--  BEGIN CONTENT AREA  -->
        <div id="content" class="main-content">
            <div class="layout-px-spacing">
                <div class="row">
                    <?php $this->load->view('Admin/includes/n-panel') ?>
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 layout-spacing about-container">
                        <div class="widget-content widget-content-area justify-pill profile-page-widget">

                            <ul class="nav nav-pills mb-3 mt-3 nav-fill" id="justify-pills-tab" role="tablist">
                                <li class="nav-item">
                                    <a class="nav-link active company-setting-tab-background" id="justify-pills-home-tab data" data-toggle="pill" href="#justify-pills-home" role="tab" aria-controls="justify-pills-home" aria-selected="true">Company profile <img class="graph-img tabimg" src="<?= base_url() ?>assets/assets/img/company_profile.png"></a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link company-setting-tab-background" id="justify-pills-profile-tab data" data-toggle="pill" href="#justify-pills-profile" role="tab" aria-controls="justify-pills-profile" aria-selected="false">Timeline Setting <img class="graph-img tabimg" src="<?= base_url() ?>assets/assets/img/timeline_setting.png"></a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link company-setting-tab-background" id="justify-pills-profile-tab data" data-toggle="pill" href="#justify-pills-settings" role="tab" aria-controls="justify-pills-settings" aria-selected="false">Basic Settings <img class="graph-img tabimg" src="<?= base_url() ?>assets/assets/img/basic_setting.png"></a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link company-setting-tab-background" id="justify-pills-profile-tab data" data-toggle="pill" href="#justify-pills-contact" role="tab" aria-controls="justify-pills-contact" aria-selected="false">Pricing Configuration<img class="graph-img tabimg" src="<?= base_url() ?>assets/assets/img/printing_configuration.png"></a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link company-setting-tab-background" id="justify-pills-profile-tab data" data-toggle="pill" href="#justify-pills-sharing" role="tab" aria-controls="justify-pills-sharing" aria-selected="false">Report sharing <img class="graph-img tabimg" src="<?= base_url() ?>assets/assets/img/report_setting.png"></a>
                                </li>
                            </ul>
                            <!-- <div id="company profile" class="tabcontent"> -->
                            <div class="tab-content" id="justify-pills-tabContent">
                                <div class="tab-pane fade show active" id="justify-pills-home" role="tabpanel" aria-labelledby="justify-pills-home-tab">
                                    <form id="gstform" method="post">
                                        <div class="widget-two">
                                            <div class="widget-content blue">
                                                <div class="w-numeric-value">
                                                    <div class="w-content contact blue">
                                                        <span class="w-value about-heading">About Company</span>
                                                    </div>
                                                </div>
                                            </div>
                                            <table class="company-setting-table">
                                                <tr class="company-setting-first-row">
                                                    <td>
                                                    <th class="Company-name">Company Name
                                                        <input type="text" class="form-control" name="org_cname" placeholder="Enter Company Name" value="<?= $organsation_array->org_cname; ?>">
                                                    </th>
                                                    </td>
                                                    <td>
                                                    <th class="Company-name">Company Domain
                                                        <input type="text" class="form-control" name="org_cdomain" placeholder="Enter domain" maxlength="50" value="<?= $organsation_array->org_cdomain; ?>">
                                                    </th>
                                                    </td>
                                                </tr>
                                            </table>
                                        </div>

                                        <div class="row empty-row">
                                            <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 layout-spacing">
                                                <div class="widget-two user-info">
                                                    <div class="widget-content red">
                                                        <div class="w-numeric-value cs1">
                                                            <div class="w-content contact red">
                                                                <span class="w-value cs2">User info</span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="avtara">
                                                        <img src="<?= base_url() ?>assets/assets/img/avtara.png">
                                                        <h5> Sameer Deokar</h5>
                                                        <!-- <table>
                                                            <tr>
                                                                <td class="td">
                                                                </td>
                                                                <td class="td">
                                                                    <label for="fname">Name</label>
                                                                    <input type="text" placeholder="Enter First Name" name="org_fname" id="org_fname" autocomplete="off" value="<?= $organsation_array->org_fname; ?>">
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td class="td">
                                                                    <label for="fname">Last Name</label>
                                                                    <input type="text" placeholder="Enter Last Name" name="org_lname" id="org_lname" autocomplete="off" value="<?= $organsation_array->org_lname; ?>">
                                                                </td>
                                                            </tr>

                                                            <tr>
                                                                <td class="td">
                                                                    <label for="Email">Email/Username</label>
                                                                    <input type="email" placeholder="Enter Email" name="org_email" id="org_email" autocomplete="off" value="<?= $organsation_array->org_email; ?>">
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td class="td">
                                                                    <label for="contact No">Contact No</label>
                                                                    <input type="text" placeholder="Contact No." name="org_contact" id="org_contact" maxlength="10" autocomplete="off" value="<?= $organsation_array->org_contact; ?>">
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td class="td">
                                                                    <label for="Landline No">Landline No</label>
                                                                    <input type="text" placeholder="Landline" name="org_landline" id="org_landline" autocomplete="off" value="<?= $organsation_array->org_landline; ?>">
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td class="td">
                                                                    <label for="address">Address</label>
                                                                    <input type="text" id="name" name="fname">
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td class="td">
                                                                    <label for="address">Website</label>
                                                                    <input type="text" id="name" name="fname">
                                                                </td>
                                                            </tr>
                                                        </table> -->
                                                        <div class="row" style="padding: 0px 10px;">
                                                            <div class="col-md-6">
                                                                <div class="form-group text-left">
                                                                    <label class="label-control" for="userinput1">First Name
                                                                    </label>
                                                                    <input type="text" class="form-control " placeholder="Enter First Name" name="org_fname" id="org_fname" autocomplete="off" value="<?= $organsation_array->org_fname; ?>">
                                                                </div>
                                                            </div>
                                                            <div class="col-md-6">
                                                                <div class="form-group text-left">
                                                                    <label class="label-control" for="userinput2">Last Name
                                                                    </label>
                                                                    <input type="text" class="form-control " placeholder="Enter Last Name" name="org_lname" id="org_lname" autocomplete="off" value="<?= $organsation_array->org_lname; ?>">
                                                                </div>
                                                            </div>

                                                            <div class="col-md-6">
                                                                <div class="form-group text-left">
                                                                    <label class="label-control" for="userinput1">Username /
                                                                        Email </label>
                                                                    <input type="text" id="org_email" class="form-control " placeholder="Enter Email" name="org_email" autocomplete="off" value="<?= $organsation_array->org_email; ?>">
                                                                </div>
                                                            </div>

                                                            <div class="col-md-6">
                                                                <div class="form-group text-left">
                                                                    <label class="label-control" for="userinput2">Contact
                                                                        No. </label>
                                                                    <input type="text" class="form-control " placeholder="Contact No." name="org_contact" maxlength="10" autocomplete="off" value="<?= $organsation_array->org_contact; ?>">
                                                                </div>
                                                            </div>
                                                            <div class="col-md-6">
                                                                <div class="form-group text-left">
                                                                    <label class="label-control" for="userinput2">Landline
                                                                    </label>
                                                                    <input type="text" class="form-control " placeholder="Landline" name="org_landline" autocomplete="off" value="<?= $organsation_array->org_landline; ?>">
                                                                </div>
                                                            </div>
                                                            <div class="col-md-6">
                                                                <div class="form-group text-left">
                                                                    <label class="label-control" for="userinput2">Website
                                                                    </label>
                                                                    <input type="text" class="form-control " placeholder="Website" name="org_website" autocomplete="off" value="<?= $organsation_array->org_web_url; ?>">
                                                                </div>
                                                            </div>
                                                            <div class="col-md-12">
                                                                <div class="form-group text-left">
                                                                    <label class="label-control" for="userinput1">Address
                                                                    </label>
                                                                    <textarea class="form-control" rows="3" name="org_address" onblur="bind_address(this.value)"><?= $organsation_array->org_address; ?></textarea>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-xl-8 col-lg-8 col-md-8 col-sm-12 col-12 layout-spacing">
                                                <div class="widget-two form1">
                                                    <div class="row">
                                                        <div class="col-sm-6">
                                                            <div class="form-group">
                                                                <label class="label-control" for="userinput2">Country
                                                                </label>
                                                                <select class="form-control" name="org_country" id="org_country" onchange="GetState(this.value)">
                                                                    <option value="">Please Select Country</option>
                                                                    <?php
                                                                    foreach ($CountryArray as  $res) {
                                                                    ?>
                                                                        <option value="<?= $res->id; ?>" <?= $country = ($organsation_array->org_country == $res->id) ? 'selected' : ''; ?>>
                                                                            <?= $res->name; ?></option>
                                                                    <?php } ?>
                                                                </select>
                                                            </div>
                                                        </div>
                                                        <div class="col-sm-6">
                                                            <div class="form-group">
                                                                <label class="label-control" for="userinput1">State
                                                                </label>
                                                                <select class="form-control" name="org_state" id="bind_state_list">
                                                                    <option value="">Please Select State</option>
                                                                    <?php
                                                                    foreach ($StateArray as  $res) {
                                                                    ?>
                                                                        <option value="<?= $res->id; ?>" <?= $state = ($organsation_array->org_state == $res->id) ? 'selected' : ''; ?>>
                                                                            <?= $res->name; ?></option>
                                                                    <?php } ?>
                                                                </select>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-sm-6">
                                                            <div class="form-group">
                                                                <label class="label-control" for="userinput2">City
                                                                </label>
                                                                <input type="text" class="form-control " placeholder="City Name" name="org_city" autocomplete="off" value="<?= $organsation_array->org_city ?>">
                                                            </div>
                                                        </div>
                                                        <div class="col-sm-6">
                                                            <div class="form-group">
                                                                <label class="label-control" for="userinput2">Post Code
                                                                </label>
                                                                <input type="text" class="form-control " placeholder="Post Code" name="org_postcode" autocomplete="off" maxlength="6" value="<?= $organsation_array->org_postcode ?>">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-sm-6">
                                                            <div class="form-group">
                                                                <label class="label-control" for="userinput2">Time
                                                                    Zone</label>
                                                                <select class="form-control" name="org_timezone">
                                                                    <?php
                                                                    foreach ($TimeZoneArray as  $res) {
                                                                    ?>
                                                                        <option value="<?= $res->timezone_code; ?>" <?= $time = ($organsation_array->org_timezone == $res->timezone_code) ? 'selected' : ''; ?>>
                                                                            <?= ucfirst($res->country); ?></option>
                                                                    <?php } ?>
                                                                </select>
                                                            </div>
                                                        </div>
                                                        <div class="col-sm-6">
                                                            <div class="form-group">
                                                                <label class="label-control" for="userinput2">Currency</label>
                                                                <select class="form-control" name="org_currency">
                                                                    <?php
                                                                    foreach ($CurrencyArray as  $res) {
                                                                    ?>
                                                                        <option value="<?= $res->currency_id; ?>" <?= $crs = ($organsation_array->org_currency == $res->currency_id) ? 'selected' : ''; ?>>
                                                                            <?= ucfirst($res->currency_sign); ?></option>
                                                                    <?php } ?>
                                                                </select>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-sm-6">
                                                            <div class="form-group">
                                                                <label>Company Logo </label>
                                                                <div class="media no-margin-top">
                                                                    <div class="media-left">
                                                                        <?php
                                                                        if ($organsation_array->org_company_logo != '') {
                                                                            $file = base_url() . 'assets/admin/company_logo/' . $organsation_array->org_company_logo;
                                                                            $ext = pathinfo($file, PATHINFO_EXTENSION);
                                                                            if ($ext == 'pdf' || $ext == 'PDF') { ?>
                                                                                <a href="<?= $file ?>" target="_blank" style="width: 58px; height: 58px;" class="img-rounded" alt="" id="blah"><i class="icon-file-pdf" style="margin-top: 40%;font-size: 30px;color: red;" data-popup="tooltip" title="<?= $organsation_array->org_company_logo; ?>" data-placement="top" data-original-title=""></i></a>
                                                                            <?php    } elseif ($ext == "doc" || $ext == "docx") { ?>
                                                                                <a href="<?= $file ?>" target="_blank" style="width: 58px; height: 58px;" class="img-rounded" alt="" id="blah"><i class="icon-file-word" style="margin-top: 40%;font-size: 30px;color: red;" data-popup="tooltip" title="<?= $organsation_array->org_company_logo; ?>" data-placement="top" data-original-title=""></i></a>
                                                                            <?php    } else { ?>
                                                                                <a href="<?= $file ?>" target="_blank"><img src="<?= $file ?>" style="width: 58px; height: 58px;" class="img-rounded" alt="" id="blah" data-popup="tooltip" title="<?= $organsation_array->org_company_logo; ?>" data-placement="top" data-original-title=""></a>
                                                                            <?php }
                                                                        } else { ?>
                                                                            <a href="#"><img src="<?= base_url() ?>assets/admin/assets/images/company.png" style="width: 58px; height: 58px;" class="img-rounded" alt="" id="home_img"></a>
                                                                        <?php    }
                                                                        ?>
                                                                    </div>
                                                                    <div class="media-body ml-2">
                                                                        <input type="file" class="file-styled form-control" id="imgInp" name="fileup">
                                                                        <p id="error1" style="display:none; color:#FF0000;">
                                                                            Invalid Image Format! Image Format Must Be
                                                                            JPG, JPEG, PNG or GIF.
                                                                        </p>
                                                                        <p id="error2" style="display:none; color:#FF0000;">
                                                                            Maximum File Size Limit is 1MB.
                                                                        </p>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-sm-6">
                                                            <div class="form-group">
                                                                <label>Profile Attachment : </label>
                                                                <div class="media no-margin-top">
                                                                    <div class="media-left">
                                                                        <?php
                                                                        if ($organsation_array->org_company_attachment != '') {
                                                                            $file = base_url() . 'assets/admin/company_attachment/' . $organsation_array->org_company_attachment;
                                                                            $ext = pathinfo($file, PATHINFO_EXTENSION);
                                                                            if ($ext == 'pdf' || $ext == 'PDF') { ?>
                                                                                <a href="<?= $file ?>" target="_blank" style="width: 58px; height: 58px;" class="img-rounded" alt="" id="blah"><i class="icon-file-pdf" style="margin-top: 40%;font-size: 30px;color: red;" data-popup="tooltip" title="<?= $organsation_array->org_company_attachment; ?>" data-placement="top" data-original-title=""></i></a>
                                                                            <?php    } elseif ($ext == "doc" || $ext == "docx") { ?>
                                                                                <a href="<?= $file ?>" target="_blank" style="width: 58px; height: 58px;" class="img-rounded" alt="" id="blah"><i class="icon-file-word" style="margin-top: 40%;font-size: 30px;color: red;" data-popup="tooltip" title="<?= $organsation_array->org_company_attachment; ?>" data-placement="top" data-original-title=""></i></a>
                                                                            <?php    } else { ?>
                                                                                <a href="<?= $file ?>" target="_blank"><img src="<?= $file ?>" style="width: 58px; height: 58px;" class="img-rounded" alt="" id="blah" data-popup="tooltip" title="<?= $organsation_array->org_company_attachment; ?>" data-placement="top" data-original-title=""></a>
                                                                            <?php }
                                                                        } else { ?>
                                                                            <a><img src="<?= base_url(); ?>assets/admin/assets/images/placeholder1.jpg" style="width: 58px; height: 58px;" class="img-rounded" alt="" id="blah"></a>
                                                                        <?php    }
                                                                        ?>
                                                                    </div>
                                                                    <div class="media-body">
                                                                        <input type="file" name="org_company_attachment" id="org_company_attachment" class="form-control ml-3">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <hr>
                                                    <?php
                                                    $gst_applicable = $gst_array[0]->gst_applicable;
                                                    $gst_no = $gst_array[0]->gst_no;
                                                    ?>
                                                    <p class="GSTSdetails"> GST Details</p>
                                                    <div class="row">
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label>GST Applicable :</label>
                                                                <select class="form-control" name="gst_applicable" onchange="gst_details(this.value)">
                                                                    <option value="">Select GST Applicable</option>
                                                                    <option value="Yes" <?php if ($gst_applicable == 'Yes') {
                                                                                            echo 'selected';
                                                                                        } ?>>Yes</option>
                                                                    <option value="No" <?php if ($gst_applicable == 'No') {
                                                                                            echo 'selected';
                                                                                        } ?>>No</option>
                                                                </select>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label>GSI No. :</label>
                                                                <input type="text" placeholder="GST No." class="form-control" name="gst_no" id="gst_no" maxlength="15" value="<?= $gst_no; ?>">
                                                            </div>
                                                        </div>
                                                    </div>

                                                </div>
                                            </div>
                                            <div class="col-12 update-details">
                                                <button class="update text-white" id="submitBtn" type="submit"> Update Details &nbsp;<img src="<?= base_url() ?>assets/assets/img/arrow.png">
                                                </button>
                                                <span id="submitLoader"></span>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                                <div class="tab-pane fade inner-tab-content" id="justify-pills-profile" role="tabpanel" aria-labelledby="justify-pills-profile-tab">
                                    <h3>Time line Setting</h3>
                                    <hr>
                                    <form id="account_form" method="post">
                                        <fieldset>
                                            <legend class="text-semibold"><i class="icon-calendar position-left"></i> Add new period
                                            </legend>
                                            <div class="row">
                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label>Period Name :</label>
                                                        <input type="text" name="period_name" placeholder="Period Name" class="form-control">
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label>Short Year :</label>
                                                        <input type="text" name="short_year" placeholder="Short Year" class="form-control">
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label>Start Date :</label>
                                                        <input type="text" class="form-control" name="start_date" id="start_date" placeholder="Please select start date" autocomplete="off">
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label>End Date :</label>
                                                        <input type="text" class="form-control" name="end_date" id="end_date" placeholder="Please select end date" autocomplete="off">
                                                    </div>
                                                </div>
                                            </div>
                                            <br />
                                            <div class="row mr-1" style="float: right; ">
                                                <button type="submit" class="btn btn-primary">Add Details <i class="icon-arrow-right14 position-right"></i></button>
                                            </div>
                                        </fieldset>
                                    </form>

                                    <hr>
                                    <div class="row">
                                        <div class="table-responsive">
                                            <table class="table table-striped" id="perriodTable">
                                                <thead>
                                                    <tr>
                                                        <th>#</th>
                                                        <th>Period Name</th>
                                                        <th>Start Date</th>
                                                        <th>End Date</th>
                                                        <th class="text-center">Active / Closed</th>
                                                        <th class="text-center">Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php
                                                    $cnt1 = 1;
                                                    foreach ($account_period_array as $row) {

                                                    ?>
                                                        <tr>
                                                            <td><?= $cnt1; ?></td>
                                                            <td><?= $row->period_name; ?></td>
                                                            <td><?= date("d F, Y", strtotime($row->start_date)); ?>
                                                            </td>
                                                            <td><?= date("d F, Y", strtotime($row->end_date)); ?>
                                                            </td>
                                                            <td class="text-center">
                                                                <?php if ($row->status == 1) { ?>
                                                                    <a data-popup="tooltip" title="" data-placement="bottom" title="Click for Closed" onclick="deactivate(this.id)" id="<?= $row->period_id ?>"><span class="label label-success" style="color: #fff;background-color: #4CAF50;">Active</span></a>
                                                                <?php } else { ?>
                                                                    <a data-popup="tooltip" title="" data-placement="bottom" title="Click for Activate" onclick="activate(this.id)" id="<?= $row->period_id ?>"><span class="label label-danger" style="color: #fff;background-color: #F44336;">Closed</span></a>
                                                                <?php } ?>
                                                            </td>
                                                            <td class="text-center">
                                                                <ul class="icons-list ">
                                                                    <li style="display:block" ;=""><a data-toggle="modal" onclick="edit_accounting_period(id)" id="<?= $row->period_id ?>"><span class="label bg-success" style="line-height: 20px;border-radius: 4px;"><i class="fa fa-edit text-white" style="font-size: 12px;" data-toggle="tooltip" title="Edit group" data-placement="bottom"></i></span></a>
                                                                    </li>
                                                                </ul>
                                                            </td>
                                                        </tr>
                                                    <?php
                                                        $cnt1++;
                                                    }
                                                    ?>
                                                </tbody>
                                            </table>
                                        </div>

                                    </div>
                                    <br />
                                </div>
                                <div class="tab-pane fade inner-tab-content" id="justify-pills-settings" role="tabpanel" aria-labelledby="justify-pills-profile-tab">
                                    <h3>Basic Settings</h3>
                                    <hr>
                                    <form class="col-12" id="basic_settings_form" method="post">
                                        <div class="row">
                                            <div class="col-sm-6">
                                                <fieldset class="scheduler-border">
                                                    <legend class="text-semibold scheduler-border"><i class="icon-con52"></i> Quotation</legend>
                                                    <div class="row">
                                                        <div class="form-group">
                                                            <label class="control-label col-lg-12">Title : </label>
                                                            <div class="col-lg-12">
                                                                <input type="text" name="q_printing_title" class="form-control" id="q_printing_title" placeholder="Printing Title" value="<?= $organsation_array->q_printing_title ?>">
                                                            </div>
                                                        </div>
                                                        <br>
                                                        <div class="form-group">
                                                            <label class="control-label col-lg-12">Prefix : </label>
                                                            <div class="col-lg-12">
                                                                <input type="text" name="quote_prefix" class="form-control" id="quote_prefix" placeholder="Quotation Prefix" value="<?= $organsation_array->quote_prefix ?>">
                                                            </div>
                                                        </div>
                                                        <br>
                                                        <div class="form-group">
                                                            <label class="control-label col-lg-12">Suffix : </label>
                                                            <div class="col-lg-12">
                                                                <input type="text" name="quote_suffix" class="form-control" id="quote_suffix" placeholder="Quotation Suffix" value="<?= $organsation_array->quote_suffix ?>">
                                                            </div>
                                                        </div>
                                                        <br>
                                                        <div class="form-group">
                                                            <label class="control-label col-lg-12">Starting Number :
                                                            </label>
                                                            <div class="col-lg-12">
                                                                <input type="text" name="quote_number" class="form-control" id="quote_number" placeholder="Starting Number" value="<?= $organsation_array->quote_number ?>">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </fieldset>
                                            </div>
                                            <div class="col-sm-6">
                                                <fieldset class="scheduler-border">
                                                    <legend class="text-semibold scheduler-border"><i class="icon-con52"></i> CRM </legend>
                                                    <div class="row">
                                                        <div class="form-group">
                                                            <label class="control-label col-lg-12">Intimation On
                                                                Last Action ( By Days ) :</label>
                                                            <div class="col-lg-12">
                                                                <input type="text" name="intimation_days" class="form-control" id="intimation_days" placeholder="Intimation On Last Action ( By Days ) " value="<?= $id = ($organsation_array->intimation_days != '') ? $organsation_array->intimation_days : '2'; ?>">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </fieldset>
                                            </div>
                                        </div>
                                        <br />
                                        <div class="row mr-1 float-right">
                                            <button type="submit" class="btn btn-primary">Add Details <i class="icon-arrow-right14 position-right"></i></button>
                                        </div>
                                        <br>
                                        <br />
                                    </form>
                                </div>
                                <div class="tab-pane fade inner-tab-content" id="justify-pills-contact" role="tabpanel" aria-labelledby="justify-pills-profile-tab">
                                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 layout-spacing company-management pl-0 pr-0 pt-3">
                                        <figure>
                                            <a href="#" data-toggle="modal" data-target="#printingAdd" style="display: grid;">
                                                <img class="contact-img" src="<?= base_url() ?>assets/assets/img/add.png">
                                            </a>
                                        </figure>
                                    </div>
                                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 layout-spacing pl-0 pr-0">
                                        <div class="widget-two">
                                            <div class="widget-content blue">
                                                <div class="w-numeric-value cs1">
                                                    <div class="w-content contact blue">
                                                        <span class="w-value cs2">PRINTING CONFIGURATION</span>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row p-3">
                                                <div class="table-responsive">
                                                    <table class="table table-striped" id="PrintingTable">
                                                        <thead>
                                                            <tr>
                                                                <th width="10%" >#</th>
                                                                <th width="80%" >Name</th>
                                                                <th width="10%" class="text-center" style="width:10%;">Action</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <?php
                                                                $count = 1;
                                                                foreach ($get_section_array as $row) {
                                                            ?>
                                                                <tr>
                                                                    <td width="10%" ><?= $count;
                                                                        $count++; ?></td>
                                                                    <td width="70%" ><?= $row->section_name; ?></td>
                                                                    <td width="20%" class="text-center">
                                                                        <ul class="row icons-list">
                                                                            
                                                                            <li>
                                                                                <a class="ml-2" data-toggle="modal" onclick="Edit(id)" id="<?= $row->section_id; ?>">
                                                                                    <span class="label bg-success" style="line-height: 20px;border-radius: 4px;cursor: pointer;">
                                                                                        <i class="fa fa-edit text-white" style="font-size: 12px;" data-toggle="tooltip" title="Edit" data-placement="top"></i>
                                                                                    </span>
                                                                                </a>
                                                                            </li>
                                                                            <li>
                                                                                <a class="ml-2" data-toggle="modal" onclick="Delete(id)" id="<?= $row->section_id; ?>">
                                                                                    <span class="label bg-danger" style="line-height: 20px;border-radius: 4px;cursor: pointer;">
                                                                                        <i class="fa fa-trash text-white" style="font-size: 12px;" data-toggle="tooltip" title="Delete" data-placement="top"></i>
                                                                                    </span>
                                                                                </a>
                                                                            </li>
                                                                        </ul>
                                                                    </td>
                                                                </tr>
                                                            <?php $count++;
                                                            } ?>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="tab-pane fade inner-tab-content" id="justify-pills-sharing" role="tabpanel" aria-labelledby="justify-pills-profile-tab">
                                    <h3>Report Sharing</h3>
                                    <hr>
                                    <div class="container-boxes mbr-white">
                                        <div class="box-item">
                                            <div class="icon-block-top pb-4">
                                                <span class="display-2"><i class="icon-stats-dots " style="font-size: 20px;"></i></span>
                                            </div>
                                            <h4 class="box-item-title pb-3 mbr-fonts-style mbr-black display-6">
                                                CRM</h4>

                                            <table class="table table-striped" style="color:black">
                                                <tbody>

                                                    <tr>
                                                        <td>Leads Opportunity By Source</td>
                                                        <td style="text-align: right;">
                                                            <input type="checkbox" id="leadsopportunitybysourcecard" <?php for ($i = 0; $i <= 40; $i++) {
                                                                                                                            if ($new[0][$i] == 'leadsopportunitybysourcecard') {
                                                                                                                                print 'checked="checked" ';
                                                                                                                            }
                                                                                                                        } ?> />
                                                        </td>
                                                    </tr>

                                                    <tr>
                                                        <td>Leads Opportunity By Segment</td>
                                                        <td style="text-align: right;"> <a href="#"><span class="display-2">
                                                                    <input type="checkbox" id="leadsopportunitybysegment" <?php for ($i = 0; $i <= 40; $i++) {
                                                                                                                                if ($new[0][$i] == 'leadsopportunitybysegment') {
                                                                                                                                    print 'checked="checked" ';
                                                                                                                                }
                                                                                                                            } ?> />
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>Leads Opportunity by Product</td>
                                                        <td style="text-align: right;"> <a href="#"><span class="display-2">
                                                                    <input type="checkbox" id="leadoppbyproductservice" <?php for ($i = 0; $i <= 40; $i++) {
                                                                                                                            if ($new[0][$i] == 'leadoppbyproductservice') {
                                                                                                                                print 'checked="checked" ';
                                                                                                                            }
                                                                                                                        } ?> />
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>Leads Opportunity - Monthly Counts</td>
                                                        <td style="text-align: right;"> <a href="#"><span class="display-2">
                                                                    <input type="checkbox" id="leadoppbymonthlycount" <?php for ($i = 0; $i <= 40; $i++) {
                                                                                                                            if ($new[0][$i] == 'leadoppbymonthlycount') {
                                                                                                                                print 'checked="checked" ';
                                                                                                                            }
                                                                                                                        } ?> />
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>Leads Opportunity - Userwise Monthly Count</td>
                                                        <td style="text-align: right;"> <a href="#"><span class="display-2">
                                                                    <input type="checkbox" id="leadoppbyuserwisemonthlycount" <?php for ($i = 0; $i <= 40; $i++) {
                                                                                                                                    if ($new[0][$i] == 'leadoppbyuserwisemonthlycount') {
                                                                                                                                        print 'checked="checked" ';
                                                                                                                                    }
                                                                                                                                } ?> />
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>Leads|Opportunity by Sales Person</td>
                                                        <td style="text-align: right;"> <a href="#"><span class="display-2">
                                                                    <input type="checkbox" id="leadsopportunitybysalesperson" <?php for ($i = 0; $i <= 40; $i++) {
                                                                                                                                    if ($new[0][$i] == 'leadsopportunitybysalesperson') {
                                                                                                                                        print 'checked="checked" ';
                                                                                                                                    }
                                                                                                                                } ?> />
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>Leads|Opportunity by Stage</td>
                                                        <td style="text-align: right;"> <a href="#"><span class="display-2">
                                                                    <input type="checkbox" id="leadsopportunitybystagecard" <?php for ($i = 0; $i <= 40; $i++) {
                                                                                                                                if ($new[0][$i] == 'leadsopportunitybystagecard') {
                                                                                                                                    print 'checked="checked" ';
                                                                                                                                }
                                                                                                                            } ?> />
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>Leads|Opportunity by Sales Person -Segment wise</td>
                                                        <td style="text-align: right;"> <a href="#"><span class="display-2">
                                                                    <input type="checkbox" id="losalespersonsegmentwise" <?php for ($i = 0; $i <= 40; $i++) {
                                                                                                                                if ($new[0][$i] == 'losalespersonsegmentwise') {
                                                                                                                                    print 'checked="checked" ';
                                                                                                                                }
                                                                                                                            } ?> />
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>Leads|Opportunity by Sales Person -Product wise</td>
                                                        <td style="text-align: right;"> <a href="#"><span class="display-2">
                                                                    <input type="checkbox" />
                                                        </td>
                                                    </tr>

                                                </tbody>
                                            </table>
                                        </div>
                                        <div class="box-item">
                                            <div class="icon-block-top pb-4">
                                                <span class="display-2"><i class="icon-users4" style="font-size: 20px;"></i></span>
                                            </div>
                                            <h4 class="box-item-title pb-3 mbr-fonts-style mbr-black display-6">
                                                Contacts</h4>
                                            <!-- <p class="box-item-text mbr-fonts-style display-7">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aspernatur, cupiditate delectus doloremque ea enim eveniet id magni necessitatibus odio.</p>
                       													 <div class="mbr-section-btn"><a class="btn-underline mr-3 text-info display-4" href="index.html">Read More</a></div> -->
                                            <table class="table table-striped" style="color:black">
                                                <tbody>
                                                    <tr>
                                                        <td>All Contacts</td>
                                                        <td style="text-align: right;"> <a href="#"><span class="display-2">
                                                                    <input type="checkbox" />
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>Segments wise Contact</td>
                                                        <td style="text-align: right;"> <a href="#"><span class="display-2">
                                                                    <input type="checkbox" id="segmentwisecontact" <?php for ($i = 0; $i <= 40; $i++) {
                                                                                                                        if ($new[0][$i] == 'segmentwisecontact') {
                                                                                                                            print 'checked="checked" ';
                                                                                                                        }
                                                                                                                    } ?> />
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>Account Owner</td>
                                                        <td style="text-align: right;"> <a href="#"><span class="display-2">
                                                                    <input type="checkbox" id="leadopportunitybyowner" <?php for ($i = 0; $i <= 40; $i++) {
                                                                                                                            if ($new[0][$i] == 'leadopportunitybyowner') {
                                                                                                                                print 'checked="checked" ';
                                                                                                                            }
                                                                                                                        } ?> />
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>Account wise revenue</td>
                                                        <td style="text-align: right;"> <a href="#"><span class="display-2">
                                                                    <input type="checkbox" />
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>Contact Summary</td>
                                                        <td style="text-align: right;"> <a href="#"><span class="display-2">
                                                                    <input type="checkbox" id="contactsummary" <?php for ($i = 0; $i <= 40; $i++) {
                                                                                                                    if ($new[0][$i] == 'contactsummary') {
                                                                                                                        print 'checked="checked" ';
                                                                                                                    }
                                                                                                                } ?> />
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>Type wise Contact</td>
                                                        <td style="text-align: right;"> <a href="#"><span class="display-2">
                                                                    <input type="checkbox" id="typewisecontact" <?php for ($i = 0; $i <= 40; $i++) {
                                                                                                                    if ($new[0][$i] == 'typewisecontact') {
                                                                                                                        print 'checked="checked" ';
                                                                                                                    }
                                                                                                                } ?> />
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>Contact with activity</td>
                                                        <td style="text-align: right;"> <a href="#"><span class="display-2">
                                                                    <input type="checkbox" />
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>Contact with no activity</td>
                                                        <td style="text-align: right;"> <a href="#"><span class="display-2">
                                                                    <input type="checkbox" id="contactnoactivity" <?php for ($i = 0; $i <= 40; $i++) {
                                                                                                                        if ($new[0][$i] == 'contactnoactivity') {
                                                                                                                            print 'checked="checked" ';
                                                                                                                        }
                                                                                                                    } ?> />
                                                        </td>
                                                    </tr>

                                                </tbody>
                                            </table>
                                        </div>
                                        <div class="box-item">
                                            <div class="icon-block-top pb-4">
                                                <span class="display-2"><i class="icon-address-book2" style="font-size: 20px;"></i></span>
                                            </div>
                                            <h4 class="box-item-title pb-3 mbr-fonts-style mbr-black display-6">
                                                Employee</h4>
                                            <!-- <p class="box-item-text mbr-fonts-style display-7">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aspernatur, cupiditate delectus doloremque ea enim eveniet id magni necessitatibus odio.</p>
                       														 <div class="mbr-section-btn"><a class="btn-underline mr-3 text-info display-4" href="index.html">Read More</a></div> -->
                                            <table class="table table-striped" style="color:black">
                                                <tbody>
                                                    <tr>
                                                        <td>Available Time Slots</td>
                                                        <td style="text-align: right;"> <a href="#"><span class="display-2">
                                                                    <input type="checkbox" id="availabletimeslots" <?php for ($i = 0; $i <= 40; $i++) {
                                                                                                                        if ($new[0][$i] == 'availabletimeslots') {
                                                                                                                            print 'checked="checked" ';
                                                                                                                        }
                                                                                                                    } ?> />
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>Employee -Target</td>
                                                        <td style="text-align: right;"> <a href="#"><span class="display-2">
                                                                    <input type="checkbox" />
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>Employee Revenue</td>
                                                        <<td style="text-align: right;"> <a href="#"><span class="display-2">
                                                                    <input type="checkbox" id="employeerevenue" <?php for ($i = 0; $i <= 40; $i++) {
                                                                                                                    if ($new[0][$i] == 'employeerevenue') {
                                                                                                                        print 'checked="checked" ';
                                                                                                                    }
                                                                                                                } ?> />
                                                                    </td>
                                                    </tr>
                                                    <tr>
                                                        <td>Employee wise Activity</td>
                                                        <td style="text-align: right;"> <a href="#"><span class="display-2">
                                                                    <input type="checkbox" id="employeewiseactivity" <?php for ($i = 0; $i <= 40; $i++) {
                                                                                                                            if ($new[0][$i] == 'employeewiseactivity') {
                                                                                                                                print 'checked="checked" ';
                                                                                                                            }
                                                                                                                        } ?> />
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>Employee wise Activity Mapping</td>
                                                        <td style="text-align: right;"> <a href="#"><span class="display-2">
                                                                    <input type="checkbox" id="employeewiseactivitymapping" <?php for ($i = 0; $i <= 40; $i++) {
                                                                                                                                if ($new[0][$i] == 'employeewiseactivitymapping') {
                                                                                                                                    print 'checked="checked" ';
                                                                                                                                }
                                                                                                                            } ?> />
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                    <div class="container-boxes mbr-white">
                                        <div class="box-item">
                                            <div class="icon-block-top pb-4">
                                                <span class="display-2"><i class=" icon-stats-dots " style="font-size: 20px;"></i></span>
                                            </div>
                                            <h4 class="box-item-title pb-3 mbr-fonts-style mbr-black display-6">
                                                General Report</h4>

                                            <!-- <p class="box-item-text mbr-fonts-style display-7">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aspernatur, cupiditate delectus doloremque ea enim eveniet id magni necessitatibus odio.</p>
                        								<div class="mbr-section-btn"><a class="btn-underline mr-3 text-info display-4" href="index.html">Read More</a></div> -->

                                            <table class="table table-striped" style="color:black">
                                                <tbody>

                                                    <tr>
                                                        <td>Activity Summary</td>
                                                        <td style="text-align: right;">
                                                            <input type="checkbox" id="schedulesummarycard" <?php for ($i = 0; $i <= 40; $i++) {
                                                                                                                if ($new[0][$i] == 'schedulesummarycard') {
                                                                                                                    print 'checked="checked" ';
                                                                                                                }
                                                                                                            } ?> />
                                                        </td>
                                                    </tr>

                                                    <tr>
                                                        <td>Target Report</td>
                                                        <td style="text-align: right;"> <a href="#"><span class="display-2">
                                                                    <input type="checkbox" id="targetreport" <?php for ($i = 0; $i <= 40; $i++) {
                                                                                                                    if ($new[0][$i] == 'targetreport') {
                                                                                                                        print 'checked="checked" ';
                                                                                                                    }
                                                                                                                } ?> />
                                                        </td>
                                                    </tr>

                                                    <tr>
                                                        <td>Todays Activity</td>
                                                        <td style="text-align: right;"> <a href="#"><span class="display-2">
                                                                    <input type="checkbox" id="Todaysactivitiescard" <?php for ($i = 0; $i <= 40; $i++) {
                                                                                                                            if ($new[0][$i] == 'Todaysactivitiescard') {
                                                                                                                                print 'checked="checked" ';
                                                                                                                            }
                                                                                                                        } ?> />
                                                        </td>
                                                    </tr>

                                                    <tr>
                                                        <td>Leads Opportunity By Owner</td>
                                                        <td style="text-align: right;"> <a href="#"><span class="display-2">
                                                                    <input type="checkbox" id="leadsopportunitybyowner" <?php for ($i = 0; $i <= 40; $i++) {
                                                                                                                            if ($new[0][$i] == 'leadsopportunitybyowner') {
                                                                                                                                print 'checked="checked" ';
                                                                                                                            }
                                                                                                                        } ?> />
                                                        </td>
                                                    </tr>


                                                </tbody>
                                            </table>
                                        </div>


                                    </div>
                                </div>
                            </div>

                            <div id="modal_default" class="modal fade" data-keyboard="false" data-backdrop="static">
                                <div class="modal-dialog modal-lg">
                                    <div class="modal-content" style="    margin-top: 15%;">
                                        <div class="modal-header bg-info" style="background-color:#2196f3 !important;display: block;">
                                            <button type="button" class="close text-white" data-dismiss="modal">&times;</button>
                                            <h6 class="modal-title text-white text-left">Edit Timeline Settings</h6>
                                        </div>

                                        <div class="modal-body">
                                            <div id="complaint_model_data">

                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </div>
                            <div id="printingAdd" class="modal fade" data-backdrop="static" tabindex="-1" role="dialog">
                                <div class="modal-dialog modal-lg">
                                    <div class="modal-content">
                                        <div class="modal-header" style="background-color: #2196f3;color: white;padding: 13px; height: 55px;">
                                            <button type="button" style="color: white;top: 0%;font-weight:600;" class="close" data-dismiss="modal">&times;</button>
                                            <h5 class="modal-title text-white" style="margin-top: -4px">
                                                <i class=" icon-clipboard6" style="zoom:1.1; "></i>
                                                &nbsp;Add Section
                                            </h5>
                                        </div>
                                        <div class="modal-body">
                                            <form id="addform" method="post">
                                                <div class="panel panel-flat">
                                                    <div class="panel-body">
                                                        <fieldset>
                                                            <div class="row">
                                                                <div class="col-md-12">
                                                                    <div class="form-group">
                                                                        <label>Section For : <sup style="color: red">*</sup></label>
                                                                        <input type="text" name="section_name" id="section_name" class="form-control" placeholder="E.g. Section 1">
                                                                        <span id="error_section_name" style="color: red;font-size:13px"></span>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </fieldset>
                                                        <fieldset>
                                                            <label>Section : <sup style="color: red">*</sup></label>
                                                            <div class="row">
                                                                <div class="col-md-12">
                                                                    <textarea rows="1" name="section_content" id="section_content" class="form-control"></textarea>
                                                                    <span id="error_section" style="color: red;font-size:13px"></span>
                                                                </div>
                                                            </div>
                                                        </fieldset>
                                                        <br />
                                                        <div class="text-center">
                                                            <button type="submit" class="btn btn-primary">Submit <i class="icon-arrow-right14 position-right"></i></button>
                                                            <span id="preview_upload"></span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div id="edit_section" class="modal fade" data-keyboard="false" data-backdrop="static">
                                <div class="modal-dialog modal-lg">
                                    <div class="modal-content" style="margin-top: 15%;">
                                        <div class="modal-header bg-info" style="background-color:#2196f3 !important;">
                                            <button type="button" class="close text-white" data-dismiss="modal" style="top: 13px;">&times;</button>
                                            <h6 class="modal-title text-white float-left">Edit Section</h6>
                                        </div>

                                        <div class="modal-body">
                                            <div id="section_data">

                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </div>

                            <!-- END GLOBAL MANDATORY STYLES -->

                            <div class="footer-wrapper">
                                <div class="footer-section f-section-1">
                                    <p class="">Copyright © 2022 <a target="_blank" href="#"></a>, All rights reserved.</p>
                                </div>
                            </div>
                        </div>
                        <!--  END CONTENT AREA  -->

                    </div>
                </div>
            </div>
        </div>

        <!-- END MAIN CONTAINER -->

        <!-- BEGIN FOOTER -->
        <?php $this->load->view('Admin/includes/n-footer') ?>
        <!-- END FOOTER -->

        <script type="text/javascript">
            $(document).ready(function() {
                $('#section_content').summernote();
            });
            $('#perriodTable').DataTable();
            $('#PrintingTable').DataTable();

            function GetState(country_id) {
                var datastring = 'country_id=' + country_id;
                // alert(datastring);
                $.ajax({
                    type: "post",
                    url: "<?php echo site_url('CreateProfile/GetStates'); ?>",
                    cache: false,
                    data: datastring,
                    success: function(data) {
                        $('#bind_state_list').html(data);
                    },
                    error: function() {
                        alert('Error while request..');
                    }
                });
            }

            $(document).ready(function() {
                $('#gstform').bootstrapValidator({
                    message: 'This value is not valid',
                    fields: {
                        gst_applicable: {
                            validators: {
                                notEmpty: {
                                    message: 'Please Select GST Applicable'
                                }
                            }
                        },
                        url: {
                            validators: {
                                notEmpty: {
                                    message: 'Please Enter URL'
                                }
                            }
                        },
                    }
                });
            });
        </script>

        <script type="text/javascript">
            $(document).ready(function(e) {
                $("#gstform").on('submit', (function(e) {
                    //e.preventDefault();
                    if (e.isDefaultPrevented()) {
                        // alert('invalid');
                    } else {
                        $('#submitBtn').prop('disabled', true);
                        $('#submitLoader').html('<img src="<?= base_url() ?>assets/images/default.gif">');
                        $.ajax({
                            url: "<?php echo site_url('admin/Settings/InsertGstDetails'); ?>",
                            type: "POST",
                            data: new FormData(this),
                            contentType: false,
                            cache: false,
                            processData: false,
                            success: function(data) {
                                $('#submitBtn').prop('disabled', false);
                                $('#submitLoader').html('');
                                $(function() {
                                    new PNotify({
                                        title: 'Compay Setting',
                                        text: 'Compay Setting Updated Successfully',
                                        type: 'success'
                                    });
                                });
                                return false;
                                setTimeout(function() {
                                    window.location = "<?php echo site_url('admin/dashboard/CompanySetting'); ?>";
                                }, 1000);
                            },
                            error: function() {
                                $('#submitBtn').prop('disabled', false);
                                $('#submitLoader').html('');
                                alert('fail');
                            }
                        });
                    }
                    return false;

                }));
            });
        </script>
        <script type="text/javascript">
            function gst_details(value) {
                if (value == 'Yes') {
                    $("#igst_rate").prop("readonly", false);
                    $("#cgst_rate").prop("readonly", false);
                    $("#sgst_rate").prop("readonly", false);
                    $("#cess").prop("readonly", false);
                    $("#gst_no").prop("readonly", false);
                } else {
                    $("#igst_rate").prop("readonly", true);
                    $("#cgst_rate").prop("readonly", true);
                    $("#sgst_rate").prop("readonly", true);
                    $("#cess").prop("readonly", true);
                    $("#gst_no").prop("readonly", true);
                    $("#gst_no").val('');

                }
            }
        </script>
        <script type="text/javascript">
            $(document).ready(function() {
                $('#start_date').datetimepicker({
                    format: 'DD MMMM, YYYY',
                    useCurrent: true
                });
                $('#end_date').datetimepicker({
                    format: 'DD MMMM, YYYY',
                    useCurrent: true
                });
            });
        </script>
        <script type="text/javascript">
            $(document).ready(function() {
                $('#account_form').bootstrapValidator({
                    message: 'This value is not valid',
                    fields: {
                        period_name: {
                            validators: {
                                notEmpty: {
                                    message: 'Enter Period Name'
                                }
                            }
                        },

                        start_date: {
                            validators: {
                                notEmpty: {
                                    message: 'Select Start Date'
                                }
                            }
                        },

                        end_date: {
                            validators: {
                                notEmpty: {
                                    message: 'Select Start Date'
                                }
                            }
                        },

                    }
                });
            });
        </script>

        <script type="text/javascript">
            $(document).ready(function(e) {
                $("#account_form").on('submit', (function(e) {
                    //e.preventDefault();
                    if (e.isDefaultPrevented()) {
                        //alert('invalid');
                    } else {

                        $.ajax({
                            url: "<?php echo site_url('admin/Settings/AddAccountPeriod'); ?>",
                            type: "POST",
                            data: new FormData(this),
                            contentType: false,
                            cache: false,
                            processData: false,
                            success: function(data) {
                                // alert(data);
                                $(function() {
                                    new PNotify({
                                        title: 'Add Period',
                                        text: 'Added Successfully',
                                        type: 'success'
                                    });
                                });
                                setTimeout(function() {
                                    window.location =
                                        "<?php echo site_url('admin/dashboard/CompanySetting'); ?>";
                                }, 1000);
                            },
                            error: function() {
                                alert('fail');
                            }
                        });
                    }
                    return false;

                }));
            });
            $(document).ready(function(e) {
                $("#basic_settings_form").on('submit', (function(e) {
                    //e.preventDefault();
                    if (e.isDefaultPrevented()) {
                        //alert('invalid');
                    } else {

                        $.ajax({
                            url: "<?php echo site_url('admin/Settings/UpdateBasicSettingDetails'); ?>",
                            type: "POST",
                            data: new FormData(this),
                            contentType: false,
                            cache: false,
                            processData: false,
                            success: function(data) {
                                // alert(data);
                                $(function() {
                                    new PNotify({
                                        title: 'Basic Setting',
                                        text: 'Updated Successfully',
                                        type: 'success'
                                    });
                                });
                                setTimeout(function() {
                                    window.location =
                                        "<?php echo site_url('admin/dashboard/CompanySetting'); ?>";
                                }, 1000);
                            },
                            error: function() {
                                alert('fail');
                            }
                        });
                    }
                    return false;

                }));
            });
            $(document).ready(function(e) {
                $("#basic_settings_form").on('submit', (function(e) {
                    //e.preventDefault();
                    if (e.isDefaultPrevented()) {
                        //alert('invalid');
                    } else {

                        $.ajax({
                            url: "<?php echo site_url('admin/Settings/UpdateBasicSettingDetails'); ?>",
                            type: "POST",
                            data: new FormData(this),
                            contentType: false,
                            cache: false,
                            processData: false,
                            success: function(data) {
                                // alert(data);
                                $(function() {
                                    new PNotify({
                                        title: 'Basic Setting',
                                        text: 'Updated Successfully',
                                        type: 'success'
                                    });
                                });
                                setTimeout(function() {
                                    window.location =
                                        "<?php echo site_url('admin/dashboard/CompanySetting'); ?>";
                                }, 1000);
                            },
                            error: function() {
                                alert('fail');
                            }
                        });
                    }
                    return false;

                }));
            });
        </script>
        <script>
            function edit_accounting_period(id) {

                var datastring = 'id=' + id;

                $.ajax({
                    type: "post",
                    url: "<?php echo site_url('admin/dashboard/edit_mastergroup'); ?>",
                    cache: false,
                    data: datastring,
                    success: function(data) {
                        //   alert(data);
                        $('#modal_default').modal('show');
                        $('#complaint_model_data').html(data);
                    },
                    error: function() {
                        alert('Error while request..');
                    }
                });

            }

            function Edit(id) {

                var edit_section = 'id=' + id;

                $.ajax({
                    type: "post",
                    url: "<?php echo site_url('admin/Settings/getData'); ?>",
                    cache: false,
                    data: edit_section,
                    success: function(data) {
                        // alert(data);
                        $('#edit_section').modal('show');
                        $('#section_data').html(data);
                    },
                    error: function() {
                        alert('Error while request..');
                    }
                });

            }

            function Delete(id) {

                var notice = new PNotify({
                    title: 'Confirmation',
                    text: '<p>Are you sure you want to Delete this Section ?</p>',
                    hide: false,
                    type: 'warning',
                    confirm: {
                        confirm: true,
                        buttons: [{
                                text: 'Yes',
                                addClass: 'btn-sm'
                            },
                            {
                                text: 'No',
                                addClass: 'btn-sm'
                            }
                        ]
                    },
                    buttons: {
                        closer: false,
                        sticker: false
                    },
                    history: {
                        history: false
                    }
                })

                // On confirm
                notice.get().on('pnotify.confirm', function() {

                    var datastring = 'section_id=' + id;
                    // alert(datastring);
                    $.ajax({
                        type: "post",
                        url: "<?php echo site_url('admin/Settings/Delete'); ?>",
                        cache: false,
                        data: datastring,
                        success: function(data) {
                            //alert(data);
                            $(function() {
                                new PNotify({
                                    title: 'Delete Section',
                                    text: 'Deleted Section successfully',
                                    type: 'success'
                                });
                            });

                            setTimeout(function() {
                                window.location =
                                    "<?php echo site_url('admin/dashboard/CompanySetting'); ?>";
                            }, 800);


                        },
                        error: function() {
                            alert('Error while request..');
                        }
                    });
                })
                // On cancel
                notice.get().on('pnotify.cancel', function() {
                    // alert('Oh ok. Chicken, I see.');
                });

            }
        </script>
        <script>
            function deactivate(id) {

                var notice = new PNotify({
                    title: 'Confirmation',
                    text: '<p>Are you sure you want to Closed this financial year?</p>',
                    hide: false,
                    type: 'warning',
                    confirm: {
                        confirm: true,
                        buttons: [{
                                text: 'Yes',
                                addClass: 'btn-sm'
                            },
                            {
                                text: 'No',
                                addClass: 'btn-sm'
                            }
                        ]
                    },
                    buttons: {
                        closer: false,
                        sticker: false
                    },
                    history: {
                        history: false
                    }
                })

                // On confirm
                notice.get().on('pnotify.confirm', function() {

                    var datastring = 'p_id=' + id;
                    // alert(datastring);
                    $.ajax({
                        type: "post",
                        url: "<?php echo site_url('admin/dashboard/deactivate'); ?>",
                        cache: false,
                        data: datastring,
                        success: function(data) {
                            // alert(data);
                            if (data == 1) {
                                $(function() {
                                    new PNotify({
                                        title: 'Confirmation Form',
                                        text: 'Closed successfully',
                                        type: 'success'
                                    });
                                });
                            }

                            setTimeout(function() {
                                window.location =
                                    "<?php echo site_url('admin/dashboard/CompanySetting'); ?>";
                            }, 800);


                        },
                        error: function() {
                            alert('Error while request..');
                        }
                    });
                })
                // On cancel
                notice.get().on('pnotify.cancel', function() {
                    // alert('Oh ok. Chicken, I see.');
                });

            }

            function activate(id) {

                var notice = new PNotify({
                    title: 'Confirmation',
                    text: '<p>Are you sure you want to Activate this financial year?</p>',
                    hide: false,
                    type: 'warning',
                    confirm: {
                        confirm: true,
                        buttons: [{
                                text: 'Yes',
                                addClass: 'btn-sm'
                            },
                            {
                                text: 'No',
                                addClass: 'btn-sm'
                            }
                        ]
                    },
                    buttons: {
                        closer: false,
                        sticker: false
                    },
                    history: {
                        history: false
                    }
                })

                // On confirm
                notice.get().on('pnotify.confirm', function() {

                    var datastring = 'p_id=' + id;
                    // alert(datastring);
                    $.ajax({
                        type: "post",
                        url: "<?php echo site_url('admin/dashboard/activate'); ?>",
                        cache: false,
                        data: datastring,
                        success: function(data) {
                            //alert(data);
                            $(function() {
                                new PNotify({
                                    title: 'Confirmation Form',
                                    text: 'Activated successfully',
                                    type: 'success'
                                });
                            });

                            setTimeout(function() {
                                window.location =
                                    "<?php echo site_url('admin/dashboard/CompanySetting'); ?>";
                            }, 800);


                        },
                        error: function() {
                            alert('Error while request..');
                        }
                    });
                })
                // On cancel
                notice.get().on('pnotify.cancel', function() {
                    // alert('Oh ok. Chicken, I see.');
                });

            }
        </script>

        <!-- cards display starts.... -->
        <script>
            $(document).ready(function() {
                $('#leadsopportunitybysourcecard').change(function() {
                    var reportname = document.getElementById('leadsopportunitybysourcecard').id;
                    var datastring = 'report_name=' + reportname + ',';
                    if (this.checked != true) {
                        // alert('not checked');
                        // alert(datastring);

                        $.ajax({
                            type: "post",
                            url: "<?php echo site_url('admin/Dashboard/Report_settings_delete'); ?>",
                            cache: false,
                            data: datastring,
                            success: function(data) {
                                //alert("working"+data);
                            },
                            error: function() {
                                alert('Error while request..2');
                            }
                        });

                    } else {
                        //alert('checked');
                        //alert(datastring);

                        $.ajax({
                            type: "post",
                            url: "<?php echo site_url('admin/Dashboard/Report_settings_add'); ?>",
                            cache: false,
                            data: datastring,
                            success: function(data) {
                                //alert("working"+data);
                            },
                            error: function() {
                                alert('Error while request..2');
                            }
                        });
                    }
                });
            });
        </script>

        <script>
            $(document).ready(function() {
                $('#leadsopportunitybystagecard').change(function() {
                    var reportname = document.getElementById('leadsopportunitybystagecard').id;
                    var datastring = 'report_name=' + reportname + ',';
                    if (this.checked != true) {
                        //alert('not checked');
                        //alert(datastring);

                        $.ajax({
                            type: "post",
                            url: "<?php echo site_url('admin/Dashboard/Report_settings_delete'); ?>",
                            cache: false,
                            data: datastring,
                            success: function(data) {
                                //alert("working"+data);
                            },
                            error: function() {
                                //alert('Error while request..2');
                            }
                        });

                    } else {
                        //alert('checked');
                        // alert(datastring);

                        $.ajax({
                            type: "post",
                            url: "<?php echo site_url('admin/Dashboard/Report_settings_add'); ?>",
                            cache: false,
                            data: datastring,
                            success: function(data) {
                                //alert("working"+data);
                            },
                            error: function() {
                                alert('Error while request..2');
                            }
                        });
                    }
                });
            });
        </script>

        <script>
            $(document).ready(function() {
                $('#typewisecontact').change(function() {
                    var reportname = document.getElementById('typewisecontact').id;
                    var datastring = 'report_name=' + reportname + ',';
                    if (this.checked != true) {
                        //alert('not checked');
                        // alert(datastring);

                        $.ajax({
                            type: "post",
                            url: "<?php echo site_url('admin/Dashboard/Report_settings_delete'); ?>",
                            cache: false,
                            data: datastring,
                            success: function(data) {
                                //alert("working"+data);
                            },
                            error: function() {
                                alert('Error while request..2');
                            }
                        });

                    } else {
                        //alert('checked');
                        //alert(datastring);

                        $.ajax({
                            type: "post",
                            url: "<?php echo site_url('admin/Dashboard/Report_settings_add'); ?>",
                            cache: false,
                            data: datastring,
                            success: function(data) {
                                //alert("working"+data);
                            },
                            error: function() {
                                alert('Error while request..2');
                            }
                        });
                    }
                });
            });
        </script>


        <script>
            $(document).ready(function() {
                $('#schedulesummarycard').change(function() {
                    var reportname = document.getElementById('schedulesummarycard').id;
                    var datastring = 'report_name=' + reportname + ',';
                    if (this.checked != true) {
                        // alert('not checked');
                        // alert(datastring);

                        $.ajax({
                            type: "post",
                            url: "<?php echo site_url('admin/Dashboard/Report_settings_delete'); ?>",
                            cache: false,
                            data: datastring,
                            success: function(data) {
                                //alert("working"+data);
                            },
                            error: function() {
                                alert('Error while request..2');
                            }
                        });

                    } else {
                        //alert('checked');
                        // alert(datastring);

                        $.ajax({
                            type: "post",
                            url: "<?php echo site_url('admin/Dashboard/Report_settings_add'); ?>",
                            cache: false,
                            data: datastring,
                            success: function(data) {
                                //alert("working"+data);
                            },
                            error: function() {
                                alert('Error while request..2');
                            }
                        });
                    }
                });
            });
        </script>

        <script>
            $(document).ready(function() {
                $('#contactsummary').change(function() {
                    var reportname = document.getElementById('contactsummary').id;
                    var datastring = 'report_name=' + reportname + ',';
                    if (this.checked != true) {
                        //alert('not checked');
                        //alert(datastring);

                        $.ajax({
                            type: "post",
                            url: "<?php echo site_url('admin/Dashboard/Report_settings_delete'); ?>",
                            cache: false,
                            data: datastring,
                            success: function(data) {
                                //	alert("working"+data);
                            },
                            error: function() {
                                alert('Error while request..2');
                            }
                        });

                    } else {
                        //	alert('checked');
                        // alert(datastring);

                        $.ajax({
                            type: "post",
                            url: "<?php echo site_url('admin/Dashboard/Report_settings_add'); ?>",
                            cache: false,
                            data: datastring,
                            success: function(data) {
                                //	alert("working"+data);
                            },
                            error: function() {
                                alert('Error while request..2');
                            }
                        });
                    }
                });
            });
        </script>

        <script>
            $(document).ready(function() {
                $('#leadsopportunitybysalesperson').change(function() {
                    var reportname = document.getElementById('leadsopportunitybysalesperson').id;
                    var datastring = 'report_name=' + reportname + ',';
                    if (this.checked != true) {
                        // alert('not checked');
                        //alert(datastring);

                        $.ajax({
                            type: "post",
                            url: "<?php echo site_url('admin/Dashboard/Report_settings_delete'); ?>",
                            cache: false,
                            data: datastring,
                            success: function(data) {
                                //alert("working"+data);
                            },
                            error: function() {
                                alert('Error while request..2');
                            }
                        });

                    } else {
                        //alert('checked');
                        //alert(datastring);

                        $.ajax({
                            type: "post",
                            url: "<?php echo site_url('admin/Dashboard/Report_settings_add'); ?>",
                            cache: false,
                            data: datastring,
                            success: function(data) {
                                //	alert("working"+data);
                            },
                            error: function() {
                                alert('Error while request..2');
                            }
                        });
                    }
                });
            });
        </script>

        <script>
            $(document).ready(function() {
                $('#leadsopportunitybysegment').change(function() {
                    var reportname = document.getElementById('leadsopportunitybysegment').id;
                    var datastring = 'report_name=' + reportname + ',';
                    if (this.checked != true) {
                        // alert('not checked');
                        // alert(datastring);

                        $.ajax({
                            type: "post",
                            url: "<?php echo site_url('admin/Dashboard/Report_settings_delete'); ?>",
                            cache: false,
                            data: datastring,
                            success: function(data) {
                                //	alert("working"+data);
                            },
                            error: function() {
                                alert('Error while request..2');
                            }
                        });

                    } else {
                        //alert('checked');
                        //alert(datastring);

                        $.ajax({
                            type: "post",
                            url: "<?php echo site_url('admin/Dashboard/Report_settings_add'); ?>",
                            cache: false,
                            data: datastring,
                            success: function(data) {
                                //alert("working"+data);
                            },
                            error: function() {
                                alert('Error while request..2');
                            }
                        });
                    }
                });
            });
        </script>

        <script>
            $(document).ready(function() {
                $('#leadopportunitybyowner').change(function() {
                    var reportname = document.getElementById('leadopportunitybyowner').id;
                    var datastring = 'report_name=' + reportname + ',';
                    if (this.checked != true) {
                        // alert('not checked');
                        // alert(datastring);

                        $.ajax({
                            type: "post",
                            url: "<?php echo site_url('admin/Dashboard/Report_settings_delete'); ?>",
                            cache: false,
                            data: datastring,
                            success: function(data) {
                                //	alert("working"+data);
                            },
                            error: function() {
                                alert('Error while request..2');
                            }
                        });

                    } else {
                        //alert('checked');
                        //alert(datastring);

                        $.ajax({
                            type: "post",
                            url: "<?php echo site_url('admin/Dashboard/Report_settings_add'); ?>",
                            cache: false,
                            data: datastring,
                            success: function(data) {
                                //alert("working"+data);
                            },
                            error: function() {
                                alert('Error while request..2');
                            }
                        });
                    }
                });
            });
        </script>

        <script>
            $(document).ready(function() {
                $('#targetreport').change(function() {
                    var reportname = document.getElementById('targetreport').id;
                    var datastring = 'report_name=' + reportname + ',';
                    if (this.checked != true) {
                        // alert('not checked');
                        //alert(datastring);

                        $.ajax({
                            type: "post",
                            url: "<?php echo site_url('admin/Dashboard/Report_settings_delete'); ?>",
                            cache: false,
                            data: datastring,
                            success: function(data) {
                                //alert("working"+data);
                            },
                            error: function() {
                                alert('Error while request..2');
                            }
                        });

                    } else {
                        //alert('checked');
                        //alert(datastring);

                        $.ajax({
                            type: "post",
                            url: "<?php echo site_url('admin/Dashboard/Report_settings_add'); ?>",
                            cache: false,
                            data: datastring,
                            success: function(data) {
                                //alert("working"+data);
                            },
                            error: function() {
                                alert('Error while request..2');
                            }
                        });
                    }
                });
            });
        </script>

        <script>
            $(document).ready(function() {
                $('#Todaysactivitiescard').change(function() {
                    var reportname = document.getElementById('Todaysactivitiescard').id;
                    var datastring = 'report_name=' + reportname + ',';
                    if (this.checked != true) {
                        //alert('not checked');
                        // alert(datastring);

                        $.ajax({
                            type: "post",
                            url: "<?php echo site_url('admin/Dashboard/Report_settings_delete'); ?>",
                            cache: false,
                            data: datastring,
                            success: function(data) {
                                //alert("working"+data);
                            },
                            error: function() {
                                alert('Error while request..2');
                            }
                        });

                    } else {
                        //alert('checked');
                        //alert(datastring);

                        $.ajax({
                            type: "post",
                            url: "<?php echo site_url('admin/Dashboard/Report_settings_add'); ?>",
                            cache: false,
                            data: datastring,
                            success: function(data) {
                                //	alert("working"+data);
                            },
                            error: function() {
                                alert('Error while request..2');
                            }
                        });
                    }
                });
            });
        </script>

        <script>
            $(document).ready(function() {
                $('#leadsopportunitybyowner').change(function() {
                    var reportname = document.getElementById('leadsopportunitybyowner').id;
                    var datastring = 'report_name=' + reportname + ',';
                    if (this.checked != true) {
                        //alert('not checked');
                        //alert(datastring);

                        $.ajax({
                            type: "post",
                            url: "<?php echo site_url('admin/Dashboard/Report_settings_delete'); ?>",
                            cache: false,
                            data: datastring,
                            success: function(data) {
                                //alert("working"+data);
                            },
                            error: function() {
                                alert('Error while request..2');
                            }
                        });

                    } else {
                        //alert('checked');
                        // alert(datastring);

                        $.ajax({
                            type: "post",
                            url: "<?php echo site_url('admin/Dashboard/Report_settings_add'); ?>",
                            cache: false,
                            data: datastring,
                            success: function(data) {
                                //	alert("working"+data);
                            },
                            error: function() {
                                alert('Error while request..2');
                            }
                        });
                    }
                });
            });
        </script>

        <script>
            $(document).ready(function() {
                $('#segmentwisecontact').change(function() {
                    var reportname = document.getElementById('segmentwisecontact').id;
                    var datastring = 'report_name=' + reportname + ',';
                    if (this.checked != true) {
                        //alert('not checked');
                        //alert(datastring);

                        $.ajax({
                            type: "post",
                            url: "<?php echo site_url('admin/Dashboard/Report_settings_delete'); ?>",
                            cache: false,
                            data: datastring,
                            success: function(data) {
                                //alert("working"+data);
                            },
                            error: function() {
                                alert('Error while request..2');
                            }
                        });

                    } else {
                        //alert('checked');
                        // alert(datastring);

                        $.ajax({
                            type: "post",
                            url: "<?php echo site_url('admin/Dashboard/Report_settings_add'); ?>",
                            cache: false,
                            data: datastring,
                            success: function(data) {
                                //	alert("working"+data);
                            },
                            error: function() {
                                alert('Error while request..2');
                            }
                        });
                    }
                });
            });
        </script>

        <script>
            $(document).ready(function() {
                $('#employeerevenue').change(function() {
                    var reportname = document.getElementById('employeerevenue').id;
                    var datastring = 'report_name=' + reportname + ',';
                    if (this.checked != true) {
                        //alert('not checked');
                        //alert(datastring);

                        $.ajax({
                            type: "post",
                            url: "<?php echo site_url('admin/Dashboard/Report_settings_delete'); ?>",
                            cache: false,
                            data: datastring,
                            success: function(data) {
                                //alert("working"+data);
                            },
                            error: function() {
                                alert('Error while request..2');
                            }
                        });

                    } else {
                        //alert('checked');
                        //alert(datastring);

                        $.ajax({
                            type: "post",
                            url: "<?php echo site_url('admin/Dashboard/Report_settings_add'); ?>",
                            cache: false,
                            data: datastring,
                            success: function(data) {
                                //alert("working"+data);
                            },
                            error: function() {
                                alert('Error while request..2');
                            }
                        });
                    }
                });
            });
        </script>

        <script>
            $(document).ready(function() {
                $('#leadoppbyproductservice').change(function() {
                    var reportname = document.getElementById('leadoppbyproductservice').id;
                    var datastring = 'report_name=' + reportname + ',';
                    if (this.checked != true) {
                        //alert('not checked');
                        //alert(datastring);

                        $.ajax({
                            type: "post",
                            url: "<?php echo site_url('admin/Dashboard/Report_settings_delete'); ?>",
                            cache: false,
                            data: datastring,
                            success: function(data) {
                                //alert("working"+data);
                            },
                            error: function() {
                                alert('Error while request..2');
                            }
                        });

                    } else {
                        //alert('checked');
                        //alert(datastring);

                        $.ajax({
                            type: "post",
                            url: "<?php echo site_url('admin/Dashboard/Report_settings_add'); ?>",
                            cache: false,
                            data: datastring,
                            success: function(data) {
                                //alert("working"+data);
                            },
                            error: function() {
                                alert('Error while request..2');
                            }
                        });
                    }
                });
            });
        </script>


        <script>
            $(document).ready(function() {
                $('#leadoppbymonthlycount').change(function() {
                    var reportname = document.getElementById('leadoppbymonthlycount').id;
                    var datastring = 'report_name=' + reportname + ',';
                    if (this.checked != true) {
                        //alert('not checked');
                        //alert(datastring);

                        $.ajax({
                            type: "post",
                            url: "<?php echo site_url('admin/Dashboard/Report_settings_delete'); ?>",
                            cache: false,
                            data: datastring,
                            success: function(data) {
                                //alert("working"+data);
                            },
                            error: function() {
                                alert('Error while request..2');
                            }
                        });

                    } else {
                        //alert('checked');
                        //alert(datastring);

                        $.ajax({
                            type: "post",
                            url: "<?php echo site_url('admin/Dashboard/Report_settings_add'); ?>",
                            cache: false,
                            data: datastring,
                            success: function(data) {
                                //alert("working"+data);
                            },
                            error: function() {
                                alert('Error while request..2');
                            }
                        });
                    }
                });
            });
        </script>

        <script>
            $(document).ready(function() {
                $('#employeewiseactivity').change(function() {
                    var reportname = document.getElementById('employeewiseactivity').id;
                    var datastring = 'report_name=' + reportname + ',';
                    if (this.checked != true) {
                        //alert('not checked');
                        //alert(datastring);

                        $.ajax({
                            type: "post",
                            url: "<?php echo site_url('admin/Dashboard/Report_settings_delete'); ?>",
                            cache: false,
                            data: datastring,
                            success: function(data) {
                                //alert("working"+data);
                            },
                            error: function() {
                                alert('Error while request..2');
                            }
                        });

                    } else {
                        //alert('checked');
                        //alert(datastring);

                        $.ajax({
                            type: "post",
                            url: "<?php echo site_url('admin/Dashboard/Report_settings_add'); ?>",
                            cache: false,
                            data: datastring,
                            success: function(data) {
                                //alert("working"+data);
                            },
                            error: function() {
                                alert('Error while request..2');
                            }
                        });
                    }
                });
            });
        </script>

        <script>
            $(document).ready(function() {
                $('#employeewiseactivitymapping').change(function() {
                    var reportname = document.getElementById('employeewiseactivitymapping').id;
                    var datastring = 'report_name=' + reportname + ',';
                    if (this.checked != true) {
                        //alert('not checked');
                        //alert(datastring);

                        $.ajax({
                            type: "post",
                            url: "<?php echo site_url('admin/Dashboard/Report_settings_delete'); ?>",
                            cache: false,
                            data: datastring,
                            success: function(data) {
                                //alert("working"+data);
                            },
                            error: function() {
                                alert('Error while request..2');
                            }
                        });

                    } else {
                        //alert('checked');
                        //alert(datastring);

                        $.ajax({
                            type: "post",
                            url: "<?php echo site_url('admin/Dashboard/Report_settings_add'); ?>",
                            cache: false,
                            data: datastring,
                            success: function(data) {
                                //alert("working"+data);
                            },
                            error: function() {
                                alert('Error while request..2');
                            }
                        });
                    }
                });
            });
        </script>
</body>

</html>