
<link href="<?= base_url() ?>assets/admin/assets/css/components.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="<?= base_url() ?>assets/admin/assets/js/pages/form_layouts.js"></script>
<script type="text/javascript" src="<?= base_url() ?>assets/admin/assets/js/plugins/forms/styling/uniform.min.js"></script>
<style type="text/css">
  .table > thead > tr > th, .table > tbody > tr > th, .table > tfoot > tr > th, .table > thead > tr > td, .table > tbody > tr > td, .table > tfoot > tr > td 
  {
    padding: 3px 10px !important;
    line-height: 1.5384616 !important;
    border-top: 1px solid #ddd !important;
  }
</style>
  

    <div class="table-responsive" style="border: 2px solid #bb9c9c8c;">
      <table class="table">
        <tbody>
           <?php
                $i=1;
                foreach ($feature_list as $row)
                 {
                   $collapse="demo".$i;
                   $privilege=$row['privilege'];
                   $component_id=$row['component_id'];
               ?>
                     <tr>
                        <td style="width: 25%;background-color: #f3f3f3;border-right: 2px solid #ded4d4 !important;"><b><?= $row['component_title']; ?></b></td>
                        <td style="width: 75%;">   
                          <div class="form-group">
                              <div class="row">
                                <?php
                                  $checkbox=1;
                                  foreach ($privilege as  $row) 
                                  {
                                    $custom_id=$component_id.'/'.$row['privilege_id'];
                                    $checkbox=$row['checkbox'];
                                  ?>
                                   <div class="col-md-2">                                   
                                          <div class="checkbox">
                                              <label>
                                                  <input type="checkbox" name="feature_ids[]" class="styled" value="<?=$custom_id; ?>"  <?= $checkbox; ?>>
                                                  <?= $row['privilege'];  ?>                                           
                                              </label>
                                          </div>
                                   </div>  
                                  <?php
                                    $checkbox++;
                                    }
                                  ?>
                              </div>
                          </div>


                        </td>
                      </tr>
             <?php 
              $i++;} ?>

          </tbody>
        </table>
      </div>
       <div class="col-md-12">
        <div class="text-right">
            <br/>
            <button type="submit" class="btn btn-primary">Update <i class="icon-arrow-right14 position-right"></i></button>
            <span id="preview44"></span>
        </div>  
          <input type="hidden" name="action_for" value="<?= count($module_list);?>">
      <br/> <br/> <br/>
    </div> 

