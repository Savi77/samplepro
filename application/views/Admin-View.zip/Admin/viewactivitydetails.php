	
	<?php

		// echo json_encode($profile_array);

		$scheduledatetime=date("H:ia",strtotime($profile_array->assign_starttime)).' To '.date("H:ia",strtotime($profile_array->assign_endtime));
	
		if($profile_array->priority=='Normal')
		{
			$Normal='selected';
		}
		else if($profile_array->priority=='Low')
		{
			$Low='selected';
		}
		else if($profile_array->priority=='High')
		{
			$High='selected';
		}
	?>

	<div class="panel" style="box-shadow: 0 1px 3px rgba(0,0,0,.12), 0 1px 2px rgba(0,0,0,.24);">
	  <div class="panel-body">
	    <div class="row">
	      <div class="col-sm-12">

	        <div class="row">
	          <div class="col-md-6" align="left">
	            <h6><a href="#">#<?= $profile_array->title; ?></a></h6>                                        
	          </div>
	          <div class="col-md-6" align="right">
	            <h6><i class=" icon-user-tie"></i>&nbsp;: &nbsp;<?= $profile_array->empname; ?></h6>                                        
	          </div>                                      
	        </div>  

	        <div class="row">
	          <div class="col-md-6" align="left">                                  
	            <ul class="list list-unstyled">
	              <li><i class="icon-calendar"></i>&nbsp;: &nbsp;<?= date("d F, Y",strtotime($profile_array->assign_date)); ?><br> <i style="font-size: 10px;">Created on <?= date("d F, Y",strtotime($profile_array->created_date)); ?></i></li>
	            </ul> 
	          </div>
	          <div class="col-md-6" align="right">
	             <ul class="list list-unstyled ">
	                 <li class="dropdown">
	                    <i class=" icon-shrink3"></i>&nbsp;: &nbsp;
	                      <?= $profile_array->product_name; ?>
	                  </li>
	            </ul> 
	          </div>
	        </div> 
	        <div class="row">
	          <div class="col-md-6" align="left">                                  
	            <ul class="list list-unstyled">
	              <li><i class="icon-office"></i>&nbsp;: &nbsp;<?= $profile_array->company_name; ?></li>
	              <!-- <li><i class=" icon-office"></i>&nbsp;: &nbsp;dexterity techsys</li> -->
	            </ul> 
	          </div>
	          <div class="col-md-6" align="right">
	             <ul class="list list-unstyled ">
	               <li class="dropdown">
	                 <i class="icon-hour-glass"></i>&nbsp;: &nbsp;	                    
						<a href="#" class="label label-info dropdown-toggle" data-toggle="dropdown">
						 Normal <span class="caret"></span>
						</a>
						<ul class="dropdown-menu dropdown-menu-right active">
							<li class="<?= $Normal ?>">
							  <a href="#">
							     <span class="status-mark position-left bg-danger"></span> Normal
							  </a>
							</li>
							<li class="<?= $Normal ?>">
							   <a href="#">
							     <span class="status-mark position-left bg-info"></span> Low
							   </a>
							</li>
							<li class="<?= $Normal ?>">
							    <a href="#">
							      <span class="status-mark position-left bg-primary"></span> High
							    </a>
							</li>
						</ul>
	                </li>
	             </ul> 
	          </div>
	        </div> 

	        <ul class="list list-unstyled">
	           <li><i class=" icon-magazine"></i>&nbsp;: &nbsp;<span class="text-semibold"><?= $profile_array->issue; ?></span></li>
	        </ul>
	      </div>
	    </div>
	  </div>
	  <div class="panel-footer">                            
	    <ul>
	         <li><i class="icon-alarm-check"></i>&nbsp;: &nbsp;<span class="text-semibold"><?= $scheduledatetime; ?></span></li>
	    </ul>
	    <ul class="pull-right">
	      <li><b><?= ucwords($profile_array->newstatus); ?></b></li> 
	    </ul>   
	  </div>
	</div>