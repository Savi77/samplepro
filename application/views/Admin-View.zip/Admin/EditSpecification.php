

  <?php 

  foreach ($edit_data as $row) 
  {

  ?>
        <form  id="editform" method="post">
          <input type="hidden" name="specification_id" value="<?= $row->specification_id;?>">
          <div class="panel panel-flat">
            <div class="panel-body">
                <fieldset>
                  <div class="row">
                      <div class="col-md-12"> 
                        <div class="form-group">
                           <label>Specification Name : <sup style="color: red">*</sup></label>
                            <input type="text" class="form-control" name="specification_name" value="<?= $row->specification_name;?>">
                        </div>
                      </div>          
                  </div>
                </fieldset>
                <fieldset>
                 <div class="row">
                   <div class="col-md-12"> 
                      <div class="form-group clockpicker"  data-autoclose="true">
                        <label>Specification Description :  </label>
                         <input type="text" class="form-control" name="specification_desc" value="<?= $row->specification_desc;?>"  autocomplete="off">
                      </div>
                    </div>
                  </div>
                </fieldset>   
                                              
             <br/>
            <div class="text-right">
            <button type="submit" class="btn btn-primary">Update<i class="icon-arrow-right14 position-right"></i></button>
            <span id="preview_edit"></span>
          </div>  
        </div>
      </div>
    </form>

<?php } ?>



<script type="text/javascript">
$(document).ready(function() {
    $('#editform').bootstrapValidator({
        message: 'This value is not valid',
        fields: {
               specification_name: {
                      validators: {
                          notEmpty: {
                              message: 'Specification Name Required'
                          }
                  }
              }
        }
    });
});
</script>



<script type="text/javascript">
  $(document).ready(function (e)
     {

       $("#editform").on('submit',(function(e)
           {  
             //e.preventDefault();
             if (e.isDefaultPrevented())
              {
                //alert('invalid');
              }
              else
              {
                $("#preview_upload").html('<img src="<?= base_url() ?>assets/images/default.gif" style="height:30px;width:30px;" alt="sending data...."/>');
                $("#preview_upload").show();      

                  $.ajax({
                    url: "<?php echo site_url('admin/ProductSpecification/Update'); ?>",
                    type: "POST",
                    data:  new FormData(this),
                    contentType: false,
                    cache: false,
                    processData:false,
                    success: function(data)
                      {
                        $("#preview_upload").hide();      

                         $(function(){
                           new PNotify({
                                        title: 'Update Specification',
                                        text: 'Updated Successfully !!',
                                        type: 'success'
                                       });
                          });
                           setTimeout(function()
                             {
                                 window.location="<?php echo site_url('admin/ProductSpecification');?>";
                             }, 1000);
                      },
                      error: function() 
                      {
                        alert('fail');
                        }           
                   });
              }
              return false;
          
          }));
      });
</script>


