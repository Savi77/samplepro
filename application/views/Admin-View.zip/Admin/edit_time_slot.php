<script type="text/javascript" src="<?= base_url() ?>assets/admin/assets/js/pages/form_layouts.js"></script>
<script type="text/javascript" src="<?= base_url() ?>assets/admin/assets/js/plugins/forms/styling/uniform.min.js"></script>
<link href="<?= base_url() ?>assets/notify/pnotify.custom.min.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="<?= base_url() ?>assets/notify/pnotify.custom.min.js"></script>
<script type="text/javascript" src="<?= base_url() ?>assets/admin/assets/js/plugins/notifications/pnotify.min.js"></script>
<script type="text/javascript" src="<?= base_url() ?>assets/admin/assets/js/pages/components_notifications_pnotify.js"></script>

<?php foreach ($edit_time_slot_data->result() as $value) {   ?>
    <form class="form-horizontal" id="EditData" method="POST">
        <input type="hidden" class="form-control" id="time_id" name="time_id" value="<?= $value->time_id ?>">

        <div class="form-group">
            <label class="control-label col-sm-3" for="email">Time Slot <span style="color: red;">*</span></label>
            <div class="col-sm-9">
                <input type="text" class="form-control" id="edit_time_slot" name="edit_time_slot" value="<?= $value->time_slot ?>" placeholder="Enter Time Slot" maxlength="50" onkeypress="return Validate(event);">
                <span id="error_time_slot" style="color: red;font-size:80%" ></span>
            </div>
        </div>

        <div class="form-group">
            <div class="col-sm-offset-3 col-sm-9">
                <button type="button" onclick="updateData()" class="btn btn-primary pull-right">Update<i class="icon-arrow-right14 position-right"></i></button>
            </div>
        </div>
    </form>
<?php } ?>

<script type="text/javascript">
    $(document).ready(function() {
        $('#EditData').bootstrapValidator({
            message: 'This value is not valid',
            fields: {
                edit_time_slot: {
                    validators: {
                        notEmpty: {
                            message: 'Please Enter Time Slot'
                        }
                    }
                }
            }
        });
    });

    function updateData(){
        timeSlot = $('#edit_time_slot').val();
        timeId = $('#time_id').val();
        
        if (timeSlot == '') {
            $('#error_time_slot').html('');
            $('#error_time_slot').html('Please enter time slot');
        }else{
            var datastring = 'time_slot_id=' + timeId + '&time_slot=' + timeSlot;
            
            $.ajax({
                type: "post",
                url: "<?php echo site_url('admin/Master/updateTimeSlot'); ?>",
                cache: false,
                data: datastring,
                success: function(data) {

                    $(function() {
                        new PNotify({
                            title: 'Register Form',
                            text: 'Updated Successfully',
                            type: 'success'
                        });
                    });

                    setTimeout(function() {
                        window.location = "<?php echo site_url('admin/Master/time_list'); ?>";
                    }, 1000);
                },
                error: function() {
                    alert('Error while request..');
                }
            });
        }
    }

    function Validate(e){
        $('#error_time_slot').html('');

        var keyCode = e.keyCode || e.which;

        var pattern = /^[0-9\d\s:]+$/i;

        var isValid = pattern.test(String.fromCharCode(keyCode));
        
        return isValid
    }
</script>
