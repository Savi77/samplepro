<script type="text/javascript" src="<?= base_url() ?>assets/admin/assets/js/pages/form_layouts.js"></script>
<script type="text/javascript" src="<?= base_url() ?>assets/admin/assets/js/plugins/forms/styling/uniform.min.js"></script>

<form class="form-horizontal" id="EditData" method="post">
     <input type="hidden" class="form-control" id="dep_id" name="dep_id" value="<?php echo $edit_dep->dep_id; ?>" placeholder="Enter Company Name">
     <input type="hidden" class="form-control" id="deg_id" name="deg_id" value="<?= $edit_deg->deg_id; ?>" placeholder="Enter Company Name">

     <div class="form-group row">
          <label class="control-label col-sm-3" for="email">Department <span style="color: red;">*</span></label>
          <div class="col-sm-9">
               <input type="text" class="form-control" id="department_name" name="department_name" value="<?= $edit_dep->department_name; ?>" placeholder="Enter Department" maxlength="50">
          </div>
     </div>
     <div class="form-group row">
          <label class="control-label col-sm-3" for="email">Designation <span style="color: red;">*</span></label>
          <div class="col-sm-9">
               <input type="text" class="form-control" id="designation_name" name="designation_name" value="<?= $edit_deg->designation_name; ?>" placeholder="Enter Designation" maxlength="50">
          </div>
     </div>
     <div class="form-group row">
          <div class="col-sm-12">
               <button type="submit" class="btn btn-primary pull-right">Update<i class="icon-arrow-right14 position-right"></i></button>
          </div>
     </div>
</form>
<script type="text/javascript">
     $(document).ready(function() {
          $('#EditData').bootstrapValidator({
               message: 'This value is not valid',
               fields: {
                    designation_name: {
                         validators: {
                              notEmpty: {
                                   message: 'Please Enter Designation'
                              }
                         }
                    },
                    department_name: {
                         validators: {
                              notEmpty: {
                                   message: 'Please Enter Department'
                              }
                         }
                    }
               }
          });
     });
</script>
<script type="text/javascript">
     $(document).ready(function(e) {

          $("#EditData").on('submit', (function(e) {
               //e.preventDefault();
               if (e.isDefaultPrevented()) {
                    //alert('invalid');
                    return false;
               } else {

                    // alert('test');  
                    
                    $.ajax({
                         url: "<?php echo site_url('admin/Master/Edit_DepartmentDesignation'); ?>",
                         type: "POST",
                         data: new FormData(this),
                         contentType: false,
                         cache: false,
                         processData: false,
                         success: function(data) {
                              PNotify.removeAll()
                              // alert(data);

                              $(function() {
                                   new PNotify({
                                        title: 'Edit Form',
                                        text: 'Updated  Successfully',
                                        type: 'success'
                                   });
                              });

                              setTimeout(function() {
                                   window.location = "<?php echo site_url('admin/Master/department_designation'); ?>";
                              }, 300);


                         },
                         error: function() {
                              alert('fail');
                         }
                    });
               }
               return false;

          }));
     });
</script>

