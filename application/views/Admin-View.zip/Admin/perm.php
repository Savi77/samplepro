<link rel="stylesheet" type="text/css" href="https://ssg.accounting.deskera.com/lib/resources/css/wtf-all.css">


<div class="x-window-bwrap" id="wtf-gen845">
    <div class="x-window-ml">
        <div class="x-window-mr" id="wtf-gen10048">
            <div class="x-window-mc" id="wtf-gen10050">
                <div class="x-window-body" id="wtf-gen846" style="width: 686px; height: 534px;">
                    <div id="wtf-comp-1115" class="x-panel x-panel-noborder">
                        <div class="x-panel-bwrap" id="wtf-gen889">
                            <div class="x-panel-body x-panel-body-noheader x-panel-body-noborder x-border-layout-ct" id="wtf-gen890" style="height: 533px; position: relative;">
                                <div id="wtf-comp-1116" class="x-panel x-border-panel x-panel-noborder" style="left: 0px; top: 0px; width: 686px;">
                                    <div class="x-panel-bwrap" id="wtf-gen891">
                                        <div class="x-panel-body x-panel-body-noheader x-panel-body-noborder" id="wtf-gen892" style="background: white; border-bottom: 1px solid rgb(191, 191, 191); height: 74px; width: 686px;">
                                            <div style="width:100%;height:100%;position:relative;float:left;" id="wtf-gen10044">
                                                <div style="float:left;height:100%;width:auto;position:relative;" id="wtf-gen10041"><img src="../../images/accounting_image/role-assign.gif" class="adminWinImg" id="wtf-gen10040"></div>
                                                <div style="float:left;height:100%;width:80%;position:relative;" id="wtf-gen10039">
                                                    <div style="font-size:12px;font-style:bold;float:left;margin:15px 0px 0px 10px;width:100%;position:relative;" id="wtf-gen10042"><b id="wtf-gen10043">Set User Permissions</b></div>
                                                    <div style="font-size:10px;float:left;margin:2mm 0px 3mm 3mm;width:100%;position:relative;">Set Role and Permissions for the User : <b id="wtf-gen5487">Kedar Adhangale</b></div>
                                                    <div class="medatory-msg">* indicates required fields</div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div id="wtf-comp-1117" class="x-panel x-border-panel x-panel-noborder" style="left: 0px; top: 75px; width: 686px;">
                                    <div class="x-panel-bwrap" id="wtf-gen893">
                                        <div class="x-panel-body x-panel-body-noheader x-panel-body-noborder" id="wtf-gen894" style="background: rgb(241, 241, 241); width: 686px; height: 458px;">
                                            <div id="AssPerForm" class="x-panel x-panel-body x-panel-body-noheader x-panel-body-noborder x-panel-noborder x-form-label-left" style="background: transparent; width: 686px;">
                                                <div class="x-panel-bwrap" id="wtf-gen895">
                                                    <div class="x-panel-body x-panel-body-noheader x-panel-body-noborder" id="wtf-gen896" style="background: transparent; overflow: auto; width: 686px; height: 458px;">
                                                        <form method="POST" id="wtf-gen897" class=" x-form">
                                                            <input type="hidden" size="20" autocomplete="off" id="wtf-comp-1109" name="userid" class=" x-form-hidden x-form-field">
                                                            <div id="wtf-comp-1110" class="x-panel x-panel-noborder" style="padding: 20px;">
                                                                <div class="x-panel-bwrap" id="wtf-gen899">
                                                                    <div class="x-panel-body x-panel-body-noheader x-panel-body-noborder x-column-layout-ct" id="wtf-gen900">
                                                                        <div class="x-column-inner" id="wtf-gen903" style="width: 631px;">
                                                                            <div id="wtf-comp-1111" class="x-panel x-column x-panel-noborder x-form-label-left" style="width: 460px;">
                                                                                <div class="x-panel-bwrap" id="wtf-gen904">
                                                                                    <div class="x-panel-body x-panel-body-noheader x-panel-body-noborder" id="wtf-gen905" style="width: 460px;">
                                                                                        <div class="x-form-item  x-hide-label" tabindex="-1" id="wtf-gen909">
                                                                                            <label for="wtf-comp-1105" style="width:50px;" class="x-form-item-label">Role:</label>
                                                                                            <div class="x-form-element" id="x-form-el-wtf-comp-1105" style="padding-left:55px">
                                                                                                <div class="x-form-field-wrap" id="wtf-gen911" style="width: 208px; display: none;">
                                                                                                    <input type="hidden" name="roleid" id="roleid" value="2">
                                                                                                    <input type="text" size="24" autocomplete="off" id="wtf-comp-1105" class=" x-form-text x-form-field x-combo-noedit" readonly="true"><img src="../../lib/resources/images/default/s.gif" class="x-form-trigger x-form-arrow-trigger" id="wtf-gen912"></div>
                                                                                            </div>
                                                                                            <div class="x-form-clear-left"></div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div id="wtf-comp-1112" class="x-panel x-column x-panel-noborder x-form-label-left" style="width: 145px;">
                                                                                <div class="x-panel-bwrap" id="wtf-gen906">
                                                                                    <div class="x-panel-body x-panel-body-noheader x-panel-body-noborder" id="wtf-gen907" style="width: 145px;">
                                                                                        <table border="0" cellpadding="0" cellspacing="0" class="x-btn-wrap x-btn x-hide-display" id="wtf-comp-1113" style="width: auto;">
                                                                                            <tbody>
                                                                                                <tr>
                                                                                                    <td class="x-btn-left"><i>&nbsp;</i></td>
                                                                                                    <td class="x-btn-center"><em unselectable="on"><button class="x-btn-text" type="button" id="wtf-gen924">Delete Role</button></em></td>
                                                                                                    <td class="x-btn-right"><i>&nbsp;</i></td>
                                                                                                </tr>
                                                                                            </tbody>
                                                                                        </table>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div class="x-clear" id="wtf-gen908"></div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div id="wtf-comp-1114" class="x-panel x-panel-noborder">
                                                                <div class="x-panel-bwrap" id="wtf-gen901">
                                                                    <div class="x-panel-body x-panel-body-noheader x-panel-body-noborder x-column-layout-ct" id="wtf-gen902">
                                                                        <div class="x-column-inner" id="wtf-gen930" style="width: 671px;">
                                                                            <div id="AP-col0" class="x-panel x-column x-panel-noborder x-form-label-left" style="width: 322px;">
                                                                                <div class="x-panel-bwrap" id="wtf-gen931">
                                                                                    <div class="x-panel-body x-panel-body-noheader x-panel-body-noborder" id="wtf-gen932" style="width: 322px;">
                                                                                        <fieldset id="featureff80808122f9dba90122fa4704a5002e" class=" x-fieldset x-panel-collapsed" style="margin: 10px;">
                                                                                            <legend class="x-fieldset-header x-unselectable" id="wtf-gen5488">
                                                                                                <div class="x-tool x-tool-toggle " id="wtf-gen5492">&nbsp;</div><span class="x-fieldset-header-text" id="wtf-gen5496">Account Preferences</span></legend>
                                                                                            <div class="x-fieldset-bwrap" id="wtf-gen5489">
                                                                                                <div class="x-fieldset-body" id="wtf-gen5490" style="height: auto;">
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6091">
                                                                                                        <label for="activityff80808122f9dba90122fa4a54f10032" style="width:250px; font-weight:bold;" class="x-form-item-label" id="wtf-gen10045">View :</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba90122fa4a54f10032" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6092">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba90122fa4a54f10032" name="actff80808122f9dba90122fa4a54f10032" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6098">
                                                                                                        <label for="activityff80808122f9dba90122fa4aa48b0033" style="padding-left:25px;width:225px;" class="x-form-item-label" id="wtf-gen10046">...Modify:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba90122fa4aa48b0033" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6099">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba90122fa4aa48b0033" name="actff80808122f9dba90122fa4aa48b0033" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6105">
                                                                                                        <label for="activity67f013889bbwe4b5cbeca8ewrwfp8e9d" style="padding-left:25px;width:225px;" class="x-form-item-label" id="wtf-gen10047">...Export:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity67f013889bbwe4b5cbeca8ewrwfp8e9d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6106">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity67f013889bbwe4b5cbeca8ewrwfp8e9d" name="act67f013889bbwe4b5cbeca8ewrwfp8e9d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6112">
                                                                                                        <label for="activity7b45ddbe9bb7wee4b5cbeca86bpsdws8e9d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Import:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity7b45ddbe9bb7wee4b5cbeca86bpsdws8e9d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6113">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity7b45ddbe9bb7wee4b5cbeca86bpsdws8e9d" name="act7b45ddbe9bb7wee4b5cbeca86bpsdws8e9d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                        <fieldset id="featureff80808122f3cb640122f44bd982000f" class=" x-fieldset x-panel-collapsed" style="margin: 10px;">
                                                                                            <legend class="x-fieldset-header x-unselectable" id="wtf-gen5497">
                                                                                                <div class="x-tool x-tool-toggle " id="wtf-gen5501">&nbsp;</div><span class="x-fieldset-header-text" id="wtf-gen5505">Customer</span></legend>
                                                                                            <div class="x-fieldset-bwrap" id="wtf-gen5498">
                                                                                                <div class="x-fieldset-body" id="wtf-gen5499" style="height: auto;">
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6119">
                                                                                                        <label for="activityff80808122f3cb640122f45d38430039" style="width:250px; font-weight:bold;" class="x-form-item-label">Create:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f3cb640122f45d38430039" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6120">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f3cb640122f45d38430039" name="actff80808122f3cb640122f45d38430039" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6126">
                                                                                                        <label for="activityff80808122f3cb640122f45d38430078" style="width:250px; font-weight:bold;" class="x-form-item-label">View :</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f3cb640122f45d38430078" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6127">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f3cb640122f45d38430078" name="actff80808122f3cb640122f45d38430078" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6133">
                                                                                                        <label for="activityff80808122f3cb640122f461b4bf0045" style="padding-left:25px;width:225px;" class="x-form-item-label">...Modify:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f3cb640122f461b4bf0045" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6134">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f3cb640122f461b4bf0045" name="actff80808122f3cb640122f461b4bf0045" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6140">
                                                                                                        <label for="activityff80808122f9dba90122fa4888cf00209" style="padding-left:25px;width:225px;" class="x-form-item-label">...Chart:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba90122fa4888cf00209" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6141">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba90122fa4888cf00209" name="actff80808122f9dba90122fa4888cf00209" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6147">
                                                                                                        <label for="activityff80808122f9dba90122fa4888cf00217" style="padding-left:25px;width:225px;" class="x-form-item-label">...Delete:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba90122fa4888cf00217" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6148">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba90122fa4888cf00217" name="actff80808122f9dba90122fa4888cf00217" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6154">
                                                                                                        <label for="activityff80808122f9dba90122fa4888cf00210" style="padding-left:25px;width:225px;" class="x-form-item-label">...Import Data:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba90122fa4888cf00210" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6155">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba90122fa4888cf00210" name="actff80808122f9dba90122fa4888cf00210" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6161">
                                                                                                        <label for="activityff80808122f9dba90122fa4888cf00211" style="padding-left:25px;width:225px;" class="x-form-item-label">...Export Data:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba90122fa4888cf00211" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6162">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba90122fa4888cf00211" name="actff80808122f9dba90122fa4888cf00211" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6168">
                                                                                                        <label for="activityff80808122f9dba90122fa4888cf00212" style="padding-left:25px;width:225px;" class="x-form-item-label">...Print:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba90122fa4888cf00212" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6169">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba90122fa4888cf00212" name="actff80808122f9dba90122fa4888cf00212" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6175">
                                                                                                        <label for="activity739d3cc16b3b11e5a3d314dda97926b6" style="padding-left:25px;width:225px;" class="x-form-item-label">...View All:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity739d3cc16b3b11e5a3d314dda97926b6" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6176">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity739d3cc16b3b11e5a3d314dda97926b6" name="act739d3cc16b3b11e5a3d314dda97926b6" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6182">
                                                                                                        <label for="activity42a8da1ab23911e7abc4cec278b6b50a" style="padding-left:25px;width:225px;" class="x-form-item-label">...Opening Balance:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity42a8da1ab23911e7abc4cec278b6b50a" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6183">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity42a8da1ab23911e7abc4cec278b6b50a" name="act42a8da1ab23911e7abc4cec278b6b50a" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6189">
                                                                                                        <label for="activityf6e0e6878cab4ca3b9732084a035b3b3" style="padding-left:25px;width:225px;" class="x-form-item-label">...View IBG Details:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityf6e0e6878cab4ca3b9732084a035b3b3" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6190">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityf6e0e6878cab4ca3b9732084a035b3b3" name="actf6e0e6878cab4ca3b9732084a035b3b3" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6196">
                                                                                                        <label for="activity42c2c124a65348b8ac17f207c77744d2" style="padding-left:25px;width:225px;" class="x-form-item-label">...Edit IBG Details:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity42c2c124a65348b8ac17f207c77744d2" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6197">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity42c2c124a65348b8ac17f207c77744d2" name="act42c2c124a65348b8ac17f207c77744d2" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6203">
                                                                                                        <label for="activity93cdefaf67c211e89f1f4ccc6a2d6a4d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Copy:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity93cdefaf67c211e89f1f4ccc6a2d6a4d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6204">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity93cdefaf67c211e89f1f4ccc6a2d6a4d" name="act93cdefaf67c211e89f1f4ccc6a2d6a4d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                        <fieldset id="featureff80808122f9dba90122fa4827210030" class=" x-fieldset x-panel-collapsed" style="margin: 10px;">
                                                                                            <legend class="x-fieldset-header x-unselectable" id="wtf-gen5506">
                                                                                                <div class="x-tool x-tool-toggle" id="wtf-gen5510">&nbsp;</div><span class="x-fieldset-header-text" id="wtf-gen5514">Product Management</span></legend>
                                                                                            <div class="x-fieldset-bwrap" id="wtf-gen5507">
                                                                                                <div class="x-fieldset-body" id="wtf-gen5508">
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6210">
                                                                                                        <label for="activityff80808122f9dba90122fa4bfda10036" style="width:250px; font-weight:bold;" class="x-form-item-label">Create:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba90122fa4bfda10036" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6211">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba90122fa4bfda10036" name="actff80808122f9dba90122fa4bfda10036" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6217">
                                                                                                        <label for="activityff80808122f9dba90122fa4c54f60037" style="width:250px; font-weight:bold;" class="x-form-item-label">View :</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba90122fa4c54f60037" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6218">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba90122fa4c54f60037" name="actff80808122f9dba90122fa4c54f60037" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6224">
                                                                                                        <label for="activityff80808122f9dba90122fa4ca10d0038" style="padding-left:25px;width:225px;" class="x-form-item-label">...Modify:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba90122fa4ca10d0038" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6225">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba90122fa4ca10d0038" name="actff80808122f9dba90122fa4ca10d0038" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6231">
                                                                                                        <label for="activityff80808122f9dba90122fa4888cf00219" style="padding-left:25px;width:225px;" class="x-form-item-label">...Delete:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba90122fa4888cf00219" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6232">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba90122fa4888cf00219" name="actff80808122f9dba90122fa4888cf00219" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6238">
                                                                                                        <label for="activityff80808122f9dba90122fa4888cf00220" style="padding-left:25px;width:225px;" class="x-form-item-label">...Add Price:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba90122fa4888cf00220" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6239">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba90122fa4888cf00220" name="actff80808122f9dba90122fa4888cf00220" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6245">
                                                                                                        <label for="activityff80808122f9dba90122fa4888cf00221" style="padding-left:25px;width:225px;" class="x-form-item-label">...View Price List:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba90122fa4888cf00221" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6246">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba90122fa4888cf00221" name="actff80808122f9dba90122fa4888cf00221" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6252">
                                                                                                        <label for="activityff80808122f9dba90122fa4888cf00222" style="padding-left:25px;width:225px;" class="x-form-item-label">...Inventory Report:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba90122fa4888cf00222" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6253">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba90122fa4888cf00222" name="actff80808122f9dba90122fa4888cf00222" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6259">
                                                                                                        <label for="activityff80808122f9dba90122fa4888cf00223" style="padding-left:25px;width:225px;" class="x-form-item-label">...Build Assembly:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba90122fa4888cf00223" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6260">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba90122fa4888cf00223" name="actff80808122f9dba90122fa4888cf00223" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6266">
                                                                                                        <label for="activityff80808122f9dba90122fa4888cf00224" style="padding-left:25px;width:225px;" class="x-form-item-label">...Inventory Valuation:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba90122fa4888cf00224" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6267">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba90122fa4888cf00224" name="actff80808122f9dba90122fa4888cf00224" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6273">
                                                                                                        <label for="activityff80808122f9dba90122fa4888cf00225" style="padding-left:25px;width:225px;" class="x-form-item-label">...Cycle Count:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba90122fa4888cf00225" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6274">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba90122fa4888cf00225" name="actff80808122f9dba90122fa4888cf00225" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6280">
                                                                                                        <label for="activityff80808122f9dba90122fa4888cf00226" style="padding-left:25px;width:225px;" class="x-form-item-label">...Reorder Products:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba90122fa4888cf00226" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6281">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba90122fa4888cf00226" name="actff80808122f9dba90122fa4888cf00226" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6287">
                                                                                                        <label for="activityff80808122f9dba90122fa4888cf00227" style="padding-left:25px;width:225px;" class="x-form-item-label">...Sync Products:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba90122fa4888cf00227" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6288">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba90122fa4888cf00227" name="actff80808122f9dba90122fa4888cf00227" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6294">
                                                                                                        <label for="activityff80808122f9dba90122fa4888cf00628" style="padding-left:25px;width:225px;" class="x-form-item-label">...Print:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba90122fa4888cf00628" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6295">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba90122fa4888cf00628" name="actff80808122f9dba90122fa4888cf00628" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6301">
                                                                                                        <label for="activityff80808122f9dba90122fa4888cf00429" style="padding-left:25px;width:225px;" class="x-form-item-label">...Export:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba90122fa4888cf00429" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6302">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba90122fa4888cf00429" name="actff80808122f9dba90122fa4888cf00429" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6308">
                                                                                                        <label for="activityeb214daaa2cc11e4adaceca86bxf8f9g" style="padding-left:25px;width:225px;" class="x-form-item-label">...price List-Band:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityeb214daaa2cc11e4adaceca86bxf8f9g" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6309">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityeb214daaa2cc11e4adaceca86bxf8f9g" name="acteb214daaa2cc11e4adaceca86bxf8f9g" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6315">
                                                                                                        <label for="activityeb214daaa2cc11e4adbceca86bxf8f1g" style="padding-left:25px;width:225px;" class="x-form-item-label">...Price list -Volume Discount:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityeb214daaa2cc11e4adbceca86bxf8f1g" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6316">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityeb214daaa2cc11e4adbceca86bxf8f1g" name="acteb214daaa2cc11e4adbceca86bxf8f1g" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6322">
                                                                                                        <label for="activity7b45ddbe9wq7wee4b5cbeca86bpsdws8e9d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Import:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity7b45ddbe9wq7wee4b5cbeca86bpsdws8e9d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6323">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity7b45ddbe9wq7wee4b5cbeca86bpsdws8e9d" name="act7b45ddbe9wq7wee4b5cbeca86bpsdws8e9d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6329">
                                                                                                        <label for="activity9d4ea617bbca405bb57b6df907b39f91" style="padding-left:25px;width:225px;" class="x-form-item-label">...Show Purchase Price:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity9d4ea617bbca405bb57b6df907b39f91" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6330">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity9d4ea617bbca405bb57b6df907b39f91" name="act9d4ea617bbca405bb57b6df907b39f91" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6336">
                                                                                                        <label for="activity64144a1b629c4fd88f56f32cfd19f5eb" style="padding-left:25px;width:225px;" class="x-form-item-label">...Show Sales Price:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity64144a1b629c4fd88f56f32cfd19f5eb" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6337">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity64144a1b629c4fd88f56f32cfd19f5eb" name="act64144a1b629c4fd88f56f32cfd19f5eb" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6343">
                                                                                                        <label for="activity55326266f65911e5b48ceca86bfcd415" style="padding-left:25px;width:225px;" class="x-form-item-label">...Edit Price:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity55326266f65911e5b48ceca86bfcd415" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6344">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity55326266f65911e5b48ceca86bfcd415" name="act55326266f65911e5b48ceca86bfcd415" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6350">
                                                                                                        <label for="activity5d42ac40f65911e5b48ceca86bfcd415" style="padding-left:25px;width:225px;" class="x-form-item-label">...Delete Price:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity5d42ac40f65911e5b48ceca86bfcd415" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6351">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity5d42ac40f65911e5b48ceca86bfcd415" name="act5d42ac40f65911e5b48ceca86bfcd415" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                        <fieldset id="featureff80808122f3cb640122f44c9db10012" class=" x-fieldset x-panel-collapsed" style="margin: 10px;">
                                                                                            <legend class="x-fieldset-header x-unselectable" id="wtf-gen5515">
                                                                                                <div class="x-tool x-tool-toggle" id="wtf-gen5519">&nbsp;</div><span class="x-fieldset-header-text" id="wtf-gen5523">Sales and Billing Management</span></legend>
                                                                                            <div class="x-fieldset-bwrap" id="wtf-gen5516">
                                                                                                <div class="x-fieldset-body" id="wtf-gen5517">
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6357">
                                                                                                        <label for="activityff80808122f9dba90122fa4888cf0097" style="width:250px; font-weight:bold;" class="x-form-item-label">Create Customer Quotation:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba90122fa4888cf0097" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6358">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba90122fa4888cf0097" name="actff80808122f9dba90122fa4888cf0097" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6364">
                                                                                                        <label for="activityff80808122f9dba90122fa4888cf1000" style="width:250px; font-weight:bold;" class="x-form-item-label">View Customer Quotation Report:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba90122fa4888cf1000" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6365">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba90122fa4888cf1000" name="actff80808122f9dba90122fa4888cf1000" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6371">
                                                                                                        <label for="activityb1b84ae8a1f811e489a8eca86bff8e7d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Edit:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityb1b84ae8a1f811e489a8eca86bff8e7d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6372">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityb1b84ae8a1f811e489a8eca86bff8e7d" name="actb1b84ae8a1f811e489a8eca86bff8e7d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6378">
                                                                                                        <label for="activitybf470884a1f811e489a8eca86bff8e7d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Delete:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activitybf470884a1f811e489a8eca86bff8e7d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6379">
                                                                                                                <input type="checkbox" autocomplete="off" id="activitybf470884a1f811e489a8eca86bff8e7d" name="actbf470884a1f811e489a8eca86bff8e7d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6385">
                                                                                                        <label for="activitycc1a6588a1f811e489a8eca86bff8e7d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Export:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activitycc1a6588a1f811e489a8eca86bff8e7d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6386">
                                                                                                                <input type="checkbox" autocomplete="off" id="activitycc1a6588a1f811e489a8eca86bff8e7d" name="actcc1a6588a1f811e489a8eca86bff8e7d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6392">
                                                                                                        <label for="activityd772fd32a1f811e489a8eca86bff8e7d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Print:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityd772fd32a1f811e489a8eca86bff8e7d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6393">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityd772fd32a1f811e489a8eca86bff8e7d" name="actd772fd32a1f811e489a8eca86bff8e7d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6399">
                                                                                                        <label for="activity3846576f47ad41c7a7b5c1e8d7f7ey93" style="padding-left:25px;width:225px;" class="x-form-item-label">...Copy:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity3846576f47ad41c7a7b5c1e8d7f7ey93" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6400">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity3846576f47ad41c7a7b5c1e8d7f7ey93" name="act3846576f47ad41c7a7b5c1e8d7f7ey93" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6406">
                                                                                                        <label for="activity6c384af2634c11e5a11beca86bfcd415" style="padding-left:25px;width:225px;" class="x-form-item-label">...Unlink:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity6c384af2634c11e5a11beca86bfcd415" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6407">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity6c384af2634c11e5a11beca86bfcd415" name="act6c384af2634c11e5a11beca86bfcd415" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6413">
                                                                                                        <label for="activity6c384af2634c11e5a11pera86bfcd415" style="padding-left:25px;width:225px;" class="x-form-item-label">...Margin:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity6c384af2634c11e5a11pera86bfcd415" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6414">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity6c384af2634c11e5a11pera86bfcd415" name="act6c384af2634c11e5a11pera86bfcd415" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6420">
                                                                                                        <label for="activityff80808122f9dba90122fa4888cf0048" style="width:250px; font-weight:bold;" class="x-form-item-label">Create Sales Order:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba90122fa4888cf0048" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6421">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba90122fa4888cf0048" name="actff80808122f9dba90122fa4888cf0048" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6427">
                                                                                                        <label for="activityff80808122f9dba90122fa4888cf00105" style="width:250px; font-weight:bold;" class="x-form-item-label">View Sales Order Report:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba90122fa4888cf00105" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6428">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba90122fa4888cf00105" name="actff80808122f9dba90122fa4888cf00105" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6434">
                                                                                                        <label for="activityff80808122f9dba90122fa4888cf0049" style="padding-left:25px;width:225px;" class="x-form-item-label">...Edit:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba90122fa4888cf0049" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6435">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba90122fa4888cf0049" name="actff80808122f9dba90122fa4888cf0049" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6441">
                                                                                                        <label for="activityff80808122f9dba90122fa4888cf0050" style="padding-left:25px;width:225px;" class="x-form-item-label">...Delete:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba90122fa4888cf0050" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6442">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba90122fa4888cf0050" name="actff80808122f9dba90122fa4888cf0050" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6448">
                                                                                                        <label for="activityff80808122f9dba90122fa4888cf00103" style="padding-left:25px;width:225px;" class="x-form-item-label">...Export Data:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba90122fa4888cf00103" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6449">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba90122fa4888cf00103" name="actff80808122f9dba90122fa4888cf00103" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6455">
                                                                                                        <label for="activityff80808122f9dba90122fa4888cf00201" style="padding-left:25px;width:225px;" class="x-form-item-label">...Print:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba90122fa4888cf00201" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6456">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba90122fa4888cf00201" name="actff80808122f9dba90122fa4888cf00201" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6462">
                                                                                                        <label for="activity3846576f47ad41c7a7b5c1e8d7f7ey95" style="padding-left:25px;width:225px;" class="x-form-item-label">...Copy:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity3846576f47ad41c7a7b5c1e8d7f7ey95" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6463">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity3846576f47ad41c7a7b5c1e8d7f7ey95" name="act3846576f47ad41c7a7b5c1e8d7f7ey95" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6469">
                                                                                                        <label for="activitya48af3a2636d11e5a11beca86bfcd415" style="padding-left:25px;width:225px;" class="x-form-item-label">...Unlink:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activitya48af3a2636d11e5a11beca86bfcd415" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6470">
                                                                                                                <input type="checkbox" autocomplete="off" id="activitya48af3a2636d11e5a11beca86bfcd415" name="acta48af3a2636d11e5a11beca86bfcd415" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6476">
                                                                                                        <label for="activitya48af3a2636d11e5a11bsdfa86bfcd415" style="padding-left:25px;width:225px;" class="x-form-item-label">...Margin:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activitya48af3a2636d11e5a11bsdfa86bfcd415" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6477">
                                                                                                                <input type="checkbox" autocomplete="off" id="activitya48af3a2636d11e5a11bsdfa86bfcd415" name="acta48af3a2636d11e5a11bsdfa86bfcd415" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6483">
                                                                                                        <label for="activity6dafbedea1f911e489a8eca86bff8e7d" style="width:250px; font-weight:bold;" class="x-form-item-label">Import Sales Invoice:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity6dafbedea1f911e489a8eca86bff8e7d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6484">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity6dafbedea1f911e489a8eca86bff8e7d" name="act6dafbedea1f911e489a8eca86bff8e7d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6490">
                                                                                                        <label for="activityff80808122f9dba90122fa4888cf00268" style="width:250px; font-weight:bold;" class="x-form-item-label">Create Cash Sales:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba90122fa4888cf00268" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6491">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba90122fa4888cf00268" name="actff80808122f9dba90122fa4888cf00268" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6497">
                                                                                                        <label for="activityff80808122f3cb640122f45e2010003c" style="width:250px; font-weight:bold;" class="x-form-item-label">Create Sales Invoice:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f3cb640122f45e2010003c" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6498">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f3cb640122f45e2010003c" name="actff80808122f3cb640122f45e2010003c" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6504">
                                                                                                        <label for="activityff80808122f3cb640122f457435a0027" style="width:250px; font-weight:bold;" class="x-form-item-label">View Sales Invoices and Cash Sales Report:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f3cb640122f457435a0027" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6505">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f3cb640122f457435a0027" name="actff80808122f3cb640122f457435a0027" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6511">
                                                                                                        <label for="activityff80808122f9dba90122fa4888cf0089" style="padding-left:25px;width:225px;" class="x-form-item-label">...Email:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba90122fa4888cf0089" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6512">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba90122fa4888cf0089" name="actff80808122f9dba90122fa4888cf0089" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6518">
                                                                                                        <label for="activityff80808122f3cb640122f45fcc510040" style="padding-left:25px;width:225px;" class="x-form-item-label">...Edit:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f3cb640122f45fcc510040" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6519">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f3cb640122f45fcc510040" name="actff80808122f3cb640122f45fcc510040" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6525">
                                                                                                        <label for="activityff80808122f3cb640122f46014a90041" style="padding-left:25px;width:225px;" class="x-form-item-label">...Delete:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f3cb640122f46014a90041" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6526">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f3cb640122f46014a90041" name="actff80808122f3cb640122f46014a90041" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6532">
                                                                                                        <label for="activityff80808122f9dba90122fa4888cf0093" style="padding-left:25px;width:225px;" class="x-form-item-label">...Recurring Invoice:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba90122fa4888cf0093" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6533">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba90122fa4888cf0093" name="actff80808122f9dba90122fa4888cf0093" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6539">
                                                                                                        <label for="activityff80808122f9dba90122fa4888cf0094" style="padding-left:25px;width:225px;" class="x-form-item-label">...Copy:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba90122fa4888cf0094" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6540">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba90122fa4888cf0094" name="actff80808122f9dba90122fa4888cf0094" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6546">
                                                                                                        <label for="activityff80808122f9dba90122fa4888cf0095" style="padding-left:25px;width:225px;" class="x-form-item-label">...Export:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba90122fa4888cf0095" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6547">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba90122fa4888cf0095" name="actff80808122f9dba90122fa4888cf0095" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6553">
                                                                                                        <label for="activityff80808122f9dba90122fa4888cf0096" style="padding-left:25px;width:225px;" class="x-form-item-label">...Print:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba90122fa4888cf0096" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6554">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba90122fa4888cf0096" name="actff80808122f9dba90122fa4888cf0096" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6560">
                                                                                                        <label for="activityf2ad0406628e11e5b942eca86bfcd415" style="padding-left:25px;width:225px;" class="x-form-item-label">...Unlink:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityf2ad0406628e11e5b942eca86bfcd415" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6561">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityf2ad0406628e11e5b942eca86bfcd415" name="actf2ad0406628e11e5b942eca86bfcd415" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6567">
                                                                                                        <label for="activityf2ad0406628e11e5b942iery86bfcd415" style="padding-left:25px;width:225px;" class="x-form-item-label">...Margin:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityf2ad0406628e11e5b942iery86bfcd415" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6568">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityf2ad0406628e11e5b942iery86bfcd415" name="actf2ad0406628e11e5b942iery86bfcd415" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                        <fieldset id="featureff80808122f9dba90122fa4888cf0048" class=" x-fieldset x-panel-collapsed" style="margin: 10px;">
                                                                                            <legend class="x-fieldset-header x-unselectable" id="wtf-gen5524">
                                                                                                <div class="x-tool x-tool-toggle" id="wtf-gen5528">&nbsp;</div><span class="x-fieldset-header-text" id="wtf-gen5532">Currency Exchange</span></legend>
                                                                                            <div class="x-fieldset-bwrap" id="wtf-gen5525">
                                                                                                <div class="x-fieldset-body" id="wtf-gen5526">
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6574">
                                                                                                        <label for="activityff80808122f9dba90122fa4888cf0065" style="width:250px; font-weight:bold;" class="x-form-item-label">View :</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba90122fa4888cf0065" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6575">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba90122fa4888cf0065" name="actff80808122f9dba90122fa4888cf0065" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6581">
                                                                                                        <label for="activityff80808122f9dba90122fa4888cf00262" style="padding-left:25px;width:225px;" class="x-form-item-label">...Modify:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba90122fa4888cf00262" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6582">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba90122fa4888cf00262" name="actff80808122f9dba90122fa4888cf00262" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                        <fieldset id="featureff80808122f9dba90122fa4888cf0062" class=" x-fieldset x-panel-collapsed" style="margin: 10px;">
                                                                                            <legend class="x-fieldset-header x-unselectable" id="wtf-gen5533">
                                                                                                <div class="x-tool x-tool-toggle" id="wtf-gen5537">&nbsp;</div><span class="x-fieldset-header-text" id="wtf-gen5541">Tax</span></legend>
                                                                                            <div class="x-fieldset-bwrap" id="wtf-gen5534">
                                                                                                <div class="x-fieldset-body" id="wtf-gen5535">
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6588">
                                                                                                        <label for="activityff80808122f9dba90122fa4888cf00265" style="width:250px; font-weight:bold;" class="x-form-item-label">View :</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba90122fa4888cf00265" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6589">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba90122fa4888cf00265" name="actff80808122f9dba90122fa4888cf00265" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6595">
                                                                                                        <label for="activityff80808122f9dba90122fa4888cf00266" style="padding-left:25px;width:225px;" class="x-form-item-label">...Modify:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba90122fa4888cf00266" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6596">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba90122fa4888cf00266" name="actff80808122f9dba90122fa4888cf00266" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6602">
                                                                                                        <label for="activity67f013877bb713y4b5cbete86bfu8e9d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Export:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity67f013877bb713y4b5cbete86bfu8e9d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6603">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity67f013877bb713y4b5cbete86bfu8e9d" name="act67f013877bb713y4b5cbete86bfu8e9d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6609">
                                                                                                        <label for="activity67f013877bb713y4b5cbete86rfu8e9d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Sync:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity67f013877bb713y4b5cbete86rfu8e9d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6610">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity67f013877bb713y4b5cbete86rfu8e9d" name="act67f013877bb713y4b5cbete86rfu8e9d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                        <fieldset id="featureff80808122f3cb640122f449ca47000b" class=" x-fieldset x-panel-collapsed" style="margin: 10px;">
                                                                                            <legend class="x-fieldset-header x-unselectable" id="wtf-gen5542">
                                                                                                <div class="x-tool x-tool-toggle" id="wtf-gen5546">&nbsp;</div><span class="x-fieldset-header-text" id="wtf-gen5550">Payment Term</span></legend>
                                                                                            <div class="x-fieldset-bwrap" id="wtf-gen5543">
                                                                                                <div class="x-fieldset-body" id="wtf-gen5544">
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6616">
                                                                                                        <label for="activityff80808122f3cb640122f4542dab0020" style="width:250px; font-weight:bold;" class="x-form-item-label">View :</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f3cb640122f4542dab0020" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6617">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f3cb640122f4542dab0020" name="actff80808122f3cb640122f4542dab0020" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6623">
                                                                                                        <label for="activityff80808122f3cb640122f462fca70047" style="padding-left:25px;width:225px;" class="x-form-item-label">...Modify:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f3cb640122f462fca70047" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6624">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f3cb640122f462fca70047" name="actff80808122f3cb640122f462fca70047" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                        <fieldset id="featureff80808122f9dba90122fa4888cf0060" class=" x-fieldset x-panel-collapsed" style="margin: 10px;">
                                                                                            <legend class="x-fieldset-header x-unselectable" id="wtf-gen5551">
                                                                                                <div class="x-tool x-tool-toggle" id="wtf-gen5555">&nbsp;</div><span class="x-fieldset-header-text" id="wtf-gen5559">Master Configuration</span></legend>
                                                                                            <div class="x-fieldset-bwrap" id="wtf-gen5552">
                                                                                                <div class="x-fieldset-body" id="wtf-gen5553">
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6630">
                                                                                                        <label for="activityff80808122f9dba90122fa4888cf00258" style="width:250px; font-weight:bold;" class="x-form-item-label">View :</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba90122fa4888cf00258" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6631">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba90122fa4888cf00258" name="actff80808122f9dba90122fa4888cf00258" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6637">
                                                                                                        <label for="activityff80808122f9dba90122fa4888cf00259" style="padding-left:25px;width:225px;" class="x-form-item-label">...Create:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba90122fa4888cf00259" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6638">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba90122fa4888cf00259" name="actff80808122f9dba90122fa4888cf00259" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6644">
                                                                                                        <label for="activityff80808122f9dba90122fa4888cf00260" style="padding-left:25px;width:225px;" class="x-form-item-label">...Modify:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba90122fa4888cf00260" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6645">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba90122fa4888cf00260" name="actff80808122f9dba90122fa4888cf00260" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6651">
                                                                                                        <label for="activityff80808122f9dba90122fa4888cf00261" style="padding-left:25px;width:225px;" class="x-form-item-label">...Delete:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba90122fa4888cf00261" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6652">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba90122fa4888cf00261" name="actff80808122f9dba90122fa4888cf00261" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6658">
                                                                                                        <label for="activity67f0138875f711e4b5iueca86bfp8e9d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Import:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity67f0138875f711e4b5iueca86bfp8e9d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6659">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity67f0138875f711e4b5iueca86bfp8e9d" name="act67f0138875f711e4b5iueca86bfp8e9d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6665">
                                                                                                        <label for="activity67f0138875f711e4b5cfdereca86bfp8e9d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Export:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity67f0138875f711e4b5cfdereca86bfp8e9d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6666">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity67f0138875f711e4b5cfdereca86bfp8e9d" name="act67f0138875f711e4b5cfdereca86bfp8e9d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6672">
                                                                                                        <label for="activity67f0138875f711e4b5cbeca86bfp8e9d" style="width:250px; font-weight:bold;" class="x-form-item-label">View Custom Layouts:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity67f0138875f711e4b5cbeca86bfp8e9d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6673">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity67f0138875f711e4b5cbeca86bfp8e9d" name="act67f0138875f711e4b5cbeca86bfp8e9d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6679">
                                                                                                        <label for="activity7b45ddbe9bb711e4b57591286bpf8e9d" style="width:250px; font-weight:bold;" class="x-form-item-label">View Custom Designer:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity7b45ddbe9bb711e4b57591286bpf8e9d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6680">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity7b45ddbe9bb711e4b57591286bpf8e9d" name="act7b45ddbe9bb711e4b57591286bpf8e9d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6686">
                                                                                                        <label for="activity7b45ddbe9bb798434b57591286bpf8e9d" style="width:250px; font-weight:bold;" class="x-form-item-label">View Active Date Range:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity7b45ddbe9bb798434b57591286bpf8e9d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6687">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity7b45ddbe9bb798434b57591286bpf8e9d" name="act7b45ddbe9bb798434b57591286bpf8e9d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                        <fieldset id="featureff80808122f9dba90122fa4888cf0047" class=" x-fieldset x-panel-collapsed" style="margin: 10px;">
                                                                                            <legend class="x-fieldset-header x-unselectable" id="wtf-gen5560">
                                                                                                <div class="x-tool x-tool-toggle" id="wtf-gen5564">&nbsp;</div><span class="x-fieldset-header-text" id="wtf-gen5568">Bank Reconciliation</span></legend>
                                                                                            <div class="x-fieldset-bwrap" id="wtf-gen5561">
                                                                                                <div class="x-fieldset-body" id="wtf-gen5562">
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6693">
                                                                                                        <label for="activityff80808122f9dba90122fa4888cf0064" style="width:250px; font-weight:bold;" class="x-form-item-label">View :</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba90122fa4888cf0064" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6694">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba90122fa4888cf0064" name="actff80808122f9dba90122fa4888cf0064" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                        <fieldset id="featureff80808122f9dba90122fa4888cf0061" class=" x-fieldset x-panel-collapsed" style="margin: 10px;">
                                                                                            <legend class="x-fieldset-header x-unselectable" id="wtf-gen5569">
                                                                                                <div class="x-tool x-tool-toggle" id="wtf-gen5573">&nbsp;</div><span class="x-fieldset-header-text" id="wtf-gen5577">Import Log</span></legend>
                                                                                            <div class="x-fieldset-bwrap" id="wtf-gen5570">
                                                                                                <div class="x-fieldset-body" id="wtf-gen5571">
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6700">
                                                                                                        <label for="activityff80808122f9dba90122fa4888cf00263" style="width:250px; font-weight:bold;" class="x-form-item-label">View :</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba90122fa4888cf00263" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6701">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba90122fa4888cf00263" name="actff80808122f9dba90122fa4888cf00263" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                        <fieldset id="featureff80808122f9dba90122fa4888cf0068" class=" x-fieldset x-panel-collapsed" style="margin: 10px;">
                                                                                            <legend class="x-fieldset-header x-unselectable" id="wtf-gen5578">
                                                                                                <div class="x-tool x-tool-toggle" id="wtf-gen5582">&nbsp;</div><span class="x-fieldset-header-text" id="wtf-gen5586">Purchase Requisition</span></legend>
                                                                                            <div class="x-fieldset-bwrap" id="wtf-gen5579">
                                                                                                <div class="x-fieldset-body" id="wtf-gen5580">
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6707">
                                                                                                        <label for="activity5f215c442e864aa0b32d9dedb238a3fb" style="width:250px; font-weight:bold;" class="x-form-item-label">Create Purchase Requisition:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity5f215c442e864aa0b32d9dedb238a3fb" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6708">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity5f215c442e864aa0b32d9dedb238a3fb" name="act5f215c442e864aa0b32d9dedb238a3fb" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6714">
                                                                                                        <label for="activity3cea98179586416480d7d862fbea2868" style="width:250px; font-weight:bold;" class="x-form-item-label">View Purchase Requisition Report:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity3cea98179586416480d7d862fbea2868" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6715">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity3cea98179586416480d7d862fbea2868" name="act3cea98179586416480d7d862fbea2868" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6721">
                                                                                                        <label for="activity2d543fcafa734f0dba1cfdc83d08063a" style="padding-left:25px;width:225px;" class="x-form-item-label">...Modify:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity2d543fcafa734f0dba1cfdc83d08063a" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6722">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity2d543fcafa734f0dba1cfdc83d08063a" name="act2d543fcafa734f0dba1cfdc83d08063a" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6728">
                                                                                                        <label for="activity6477aebcc07f4cc284051d8dd96a407d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Delete:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity6477aebcc07f4cc284051d8dd96a407d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6729">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity6477aebcc07f4cc284051d8dd96a407d" name="act6477aebcc07f4cc284051d8dd96a407d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6735">
                                                                                                        <label for="activity64e82784a92d4d79bd0db8fab04ab3a6" style="padding-left:25px;width:225px;" class="x-form-item-label">...Export Data:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity64e82784a92d4d79bd0db8fab04ab3a6" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6736">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity64e82784a92d4d79bd0db8fab04ab3a6" name="act64e82784a92d4d79bd0db8fab04ab3a6" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6742">
                                                                                                        <label for="activity8a26e5693d9d49968a25bd00a3815658" style="padding-left:25px;width:225px;" class="x-form-item-label">...Print:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity8a26e5693d9d49968a25bd00a3815658" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6743">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity8a26e5693d9d49968a25bd00a3815658" name="act8a26e5693d9d49968a25bd00a3815658" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6749">
                                                                                                        <label for="activityadd0fe3240d311e5a22tc03fd5632a48" style="padding-left:25px;width:225px;" class="x-form-item-label">...Copy:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityadd0fe3240d311e5a22tc03fd5632a48" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6750">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityadd0fe3240d311e5a22tc03fd5632a48" name="actadd0fe3240d311e5a22tc03fd5632a48" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6756">
                                                                                                        <label for="activity7c915ef1edd24ea6a17075b9ae800ce3" style="width:250px; font-weight:bold;" class="x-form-item-label">View RFQ Report:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity7c915ef1edd24ea6a17075b9ae800ce3" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6757">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity7c915ef1edd24ea6a17075b9ae800ce3" name="act7c915ef1edd24ea6a17075b9ae800ce3" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6763">
                                                                                                        <label for="activitybafc116c0eda4abd8c68155b2f90dbb0" style="padding-left:25px;width:225px;" class="x-form-item-label">...Initiate/Create:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activitybafc116c0eda4abd8c68155b2f90dbb0" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6764">
                                                                                                                <input type="checkbox" autocomplete="off" id="activitybafc116c0eda4abd8c68155b2f90dbb0" name="actbafc116c0eda4abd8c68155b2f90dbb0" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6770">
                                                                                                        <label for="activity82909459cdaa44b392777229ff7540ac" style="padding-left:25px;width:225px;" class="x-form-item-label">...Delete:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity82909459cdaa44b392777229ff7540ac" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6771">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity82909459cdaa44b392777229ff7540ac" name="act82909459cdaa44b392777229ff7540ac" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6777">
                                                                                                        <label for="activity84c8cee2d8e0429894b1ee2df6ad83f0" style="padding-left:25px;width:225px;" class="x-form-item-label">...Export Data:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity84c8cee2d8e0429894b1ee2df6ad83f0" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6778">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity84c8cee2d8e0429894b1ee2df6ad83f0" name="act84c8cee2d8e0429894b1ee2df6ad83f0" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6784">
                                                                                                        <label for="activity1a121fdfc0e848ad93da6e62e18608b0" style="padding-left:25px;width:225px;" class="x-form-item-label">...Print:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity1a121fdfc0e848ad93da6e62e18608b0" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6785">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity1a121fdfc0e848ad93da6e62e18608b0" name="act1a121fdfc0e848ad93da6e62e18608b0" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6791">
                                                                                                        <label for="activitye18feea844e911e5a952c03fd5632a48" style="padding-left:25px;width:225px;" class="x-form-item-label">...Copy:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activitye18feea844e911e5a952c03fd5632a48" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6792">
                                                                                                                <input type="checkbox" autocomplete="off" id="activitye18feea844e911e5a952c03fd5632a48" name="acte18feea844e911e5a952c03fd5632a48" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6798">
                                                                                                        <label for="activity6b08cfadd769446490e2cj7a3c23259b" style="padding-left:25px;width:225px;" class="x-form-item-label">...Edit:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity6b08cfadd769446490e2cj7a3c23259b" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6799">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity6b08cfadd769446490e2cj7a3c23259b" name="act6b08cfadd769446490e2cj7a3c23259b" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                        <fieldset id="featuref487fea4b35b11e39a00001cc066e9f0" class=" x-fieldset x-panel-collapsed" style="margin: 10px;">
                                                                                            <legend class="x-fieldset-header x-unselectable" id="wtf-gen5587">
                                                                                                <div class="x-tool x-tool-toggle" id="wtf-gen5591">&nbsp;</div><span class="x-fieldset-header-text" id="wtf-gen5595">Delivery Order</span></legend>
                                                                                            <div class="x-fieldset-bwrap" id="wtf-gen5588">
                                                                                                <div class="x-fieldset-body" id="wtf-gen5589">
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6805">
                                                                                                        <label for="activity6eb27b28b35c11e39a00001cc066e9f0" style="width:250px; font-weight:bold;" class="x-form-item-label">Create:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity6eb27b28b35c11e39a00001cc066e9f0" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6806">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity6eb27b28b35c11e39a00001cc066e9f0" name="act6eb27b28b35c11e39a00001cc066e9f0" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6812">
                                                                                                        <label for="activity7a6d0d5cb35c11e39a00001cc066e9f0" style="width:250px; font-weight:bold;" class="x-form-item-label">View:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity7a6d0d5cb35c11e39a00001cc066e9f0" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6813">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity7a6d0d5cb35c11e39a00001cc066e9f0" name="act7a6d0d5cb35c11e39a00001cc066e9f0" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6819">
                                                                                                        <label for="activity87bc17dcb35c11e39a00001cc066e9f0" style="padding-left:25px;width:225px;" class="x-form-item-label">...Modify:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity87bc17dcb35c11e39a00001cc066e9f0" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6820">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity87bc17dcb35c11e39a00001cc066e9f0" name="act87bc17dcb35c11e39a00001cc066e9f0" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6826">
                                                                                                        <label for="activity94c84874b35c11e39a00001cc066e9f0" style="padding-left:25px;width:225px;" class="x-form-item-label">...Delete:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity94c84874b35c11e39a00001cc066e9f0" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6827">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity94c84874b35c11e39a00001cc066e9f0" name="act94c84874b35c11e39a00001cc066e9f0" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6833">
                                                                                                        <label for="activity9fdd70ccb35c11e39a00001cc066e9f0" style="padding-left:25px;width:225px;" class="x-form-item-label">...Export:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity9fdd70ccb35c11e39a00001cc066e9f0" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6834">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity9fdd70ccb35c11e39a00001cc066e9f0" name="act9fdd70ccb35c11e39a00001cc066e9f0" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6840">
                                                                                                        <label for="activityaf4bcb08b35c11e39a00001cc066e9f0" style="padding-left:25px;width:225px;" class="x-form-item-label">...Print:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityaf4bcb08b35c11e39a00001cc066e9f0" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6841">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityaf4bcb08b35c11e39a00001cc066e9f0" name="actaf4bcb08b35c11e39a00001cc066e9f0" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6847">
                                                                                                        <label for="activity3346576f47ad41c7a7b5c1e8d7f7ee95" style="padding-left:25px;width:225px;" class="x-form-item-label">...Copy:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity3346576f47ad41c7a7b5c1e8d7f7ee95" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6848">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity3346576f47ad41c7a7b5c1e8d7f7ee95" name="act3346576f47ad41c7a7b5c1e8d7f7ee95" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6854">
                                                                                                        <label for="activity834a22c0640e11e58e15eca86bfcd415" style="padding-left:25px;width:225px;" class="x-form-item-label">...Unlink:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity834a22c0640e11e58e15eca86bfcd415" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6855">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity834a22c0640e11e58e15eca86bfcd415" name="act834a22c0640e11e58e15eca86bfcd415" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                        <fieldset id="featurea528df089bd711e4bbfeeca86bff8e7d" class=" x-fieldset x-panel-collapsed" style="margin: 10px;">
                                                                                            <legend class="x-fieldset-header x-unselectable" id="wtf-gen5596">
                                                                                                <div class="x-tool x-tool-toggle" id="wtf-gen5600">&nbsp;</div><span class="x-fieldset-header-text" id="wtf-gen5604">Purchase Return</span></legend>
                                                                                            <div class="x-fieldset-bwrap" id="wtf-gen5597">
                                                                                                <div class="x-fieldset-body" id="wtf-gen5598">
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6861">
                                                                                                        <label for="activity0d17ec089bd811e4bbfeeca86bff8e7d" style="width:250px; font-weight:bold;" class="x-form-item-label">Create Purchase Return:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity0d17ec089bd811e4bbfeeca86bff8e7d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6862">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity0d17ec089bd811e4bbfeeca86bff8e7d" name="act0d17ec089bd811e4bbfeeca86bff8e7d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6868">
                                                                                                        <label for="activity151e5ab89bd811e4bbfeeca86bff8e7d" style="width:250px; font-weight:bold;" class="x-form-item-label">View Purchase Return:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity151e5ab89bd811e4bbfeeca86bff8e7d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6869">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity151e5ab89bd811e4bbfeeca86bff8e7d" name="act151e5ab89bd811e4bbfeeca86bff8e7d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6875">
                                                                                                        <label for="activity1c8a32ea9bd811e4bbfeeca86bff8e7d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Edit:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity1c8a32ea9bd811e4bbfeeca86bff8e7d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6876">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity1c8a32ea9bd811e4bbfeeca86bff8e7d" name="act1c8a32ea9bd811e4bbfeeca86bff8e7d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6882">
                                                                                                        <label for="activity26647c1c9bd811e4bbfeeca86bff8e7d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Delete:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity26647c1c9bd811e4bbfeeca86bff8e7d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6883">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity26647c1c9bd811e4bbfeeca86bff8e7d" name="act26647c1c9bd811e4bbfeeca86bff8e7d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6889">
                                                                                                        <label for="activity2deb44709bd811e4bbfeeca86bff8e7d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Export:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity2deb44709bd811e4bbfeeca86bff8e7d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6890">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity2deb44709bd811e4bbfeeca86bff8e7d" name="act2deb44709bd811e4bbfeeca86bff8e7d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6896">
                                                                                                        <label for="activity371d2db09bd811e4bbfeeca86bff8e7d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Print:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity371d2db09bd811e4bbfeeca86bff8e7d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6897">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity371d2db09bd811e4bbfeeca86bff8e7d" name="act371d2db09bd811e4bbfeeca86bff8e7d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6903">
                                                                                                        <label for="activity3346576f47ad41c7a7b5c1e8d7f7ee96" style="padding-left:25px;width:225px;" class="x-form-item-label">...Copy:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity3346576f47ad41c7a7b5c1e8d7f7ee96" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6904">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity3346576f47ad41c7a7b5c1e8d7f7ee96" name="act3346576f47ad41c7a7b5c1e8d7f7ee96" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6910">
                                                                                                        <label for="activity06a49cfc641111e58e15eca86bfcd415" style="padding-left:25px;width:225px;" class="x-form-item-label">...Unlink:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity06a49cfc641111e58e15eca86bfcd415" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6911">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity06a49cfc641111e58e15eca86bfcd415" name="act06a49cfc641111e58e15eca86bfcd415" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                        <fieldset id="feature1b3e04c4a2f011e4adaceca86bff8e7d" class=" x-fieldset x-panel-collapsed" style="margin: 10px;">
                                                                                            <legend class="x-fieldset-header x-unselectable" id="wtf-gen5605">
                                                                                                <div class="x-tool x-tool-toggle" id="wtf-gen5609">&nbsp;</div><span class="x-fieldset-header-text" id="wtf-gen5613">Aged Receivable</span></legend>
                                                                                            <div class="x-fieldset-bwrap" id="wtf-gen5606">
                                                                                                <div class="x-fieldset-body" id="wtf-gen5607">
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6917">
                                                                                                        <label for="activity49be97bea2f011e4adaceca86bff8e7d" style="width:250px; font-weight:bold;" class="x-form-item-label">View Aged Receivable Report:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity49be97bea2f011e4adaceca86bff8e7d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6918">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity49be97bea2f011e4adaceca86bff8e7d" name="act49be97bea2f011e4adaceca86bff8e7d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6924">
                                                                                                        <label for="activity5f561f48a2f011e4adaceca86bff8e7d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Charts:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity5f561f48a2f011e4adaceca86bff8e7d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6925">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity5f561f48a2f011e4adaceca86bff8e7d" name="act5f561f48a2f011e4adaceca86bff8e7d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6931">
                                                                                                        <label for="activity69f6e8baa2f011e4adaceca86bff8e7d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Export Data:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity69f6e8baa2f011e4adaceca86bff8e7d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6932">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity69f6e8baa2f011e4adaceca86bff8e7d" name="act69f6e8baa2f011e4adaceca86bff8e7d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6938">
                                                                                                        <label for="activity74986b7ca2f011e4adaceca86bff8e7d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Print:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity74986b7ca2f011e4adaceca86bff8e7d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6939">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity74986b7ca2f011e4adaceca86bff8e7d" name="act74986b7ca2f011e4adaceca86bff8e7d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                        <fieldset id="featureac4d34fea2f411e4adaceca86bff8e7d" class=" x-fieldset x-panel-collapsed" style="margin: 10px;">
                                                                                            <legend class="x-fieldset-header x-unselectable" id="wtf-gen5614">
                                                                                                <div class="x-tool x-tool-toggle" id="wtf-gen5618">&nbsp;</div><span class="x-fieldset-header-text" id="wtf-gen5622">Credit Note</span></legend>
                                                                                            <div class="x-fieldset-bwrap" id="wtf-gen5615">
                                                                                                <div class="x-fieldset-body" id="wtf-gen5616">
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6945">
                                                                                                        <label for="activityda606dc0a2f411e4adaceca86bff8e7d" style="width:250px; font-weight:bold;" class="x-form-item-label">Import Credit Note:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityda606dc0a2f411e4adaceca86bff8e7d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6946">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityda606dc0a2f411e4adaceca86bff8e7d" name="actda606dc0a2f411e4adaceca86bff8e7d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6952">
                                                                                                        <label for="activitye57c1ecaa2f411e4adaceca86bff8e7d" style="width:250px; font-weight:bold;" class="x-form-item-label">Create Credit Note:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activitye57c1ecaa2f411e4adaceca86bff8e7d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6953">
                                                                                                                <input type="checkbox" autocomplete="off" id="activitye57c1ecaa2f411e4adaceca86bff8e7d" name="acte57c1ecaa2f411e4adaceca86bff8e7d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6959">
                                                                                                        <label for="activityf126f86ca2f411e4adaceca86bff8e7d" style="width:250px; font-weight:bold;" class="x-form-item-label">View Credit Note Report:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityf126f86ca2f411e4adaceca86bff8e7d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6960">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityf126f86ca2f411e4adaceca86bff8e7d" name="actf126f86ca2f411e4adaceca86bff8e7d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6966">
                                                                                                        <label for="activity128960e4a2f511e4adaceca86bff8e7d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Edit:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity128960e4a2f511e4adaceca86bff8e7d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6967">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity128960e4a2f511e4adaceca86bff8e7d" name="act128960e4a2f511e4adaceca86bff8e7d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6973">
                                                                                                        <label for="activity2074e6e2a2f511e4adaceca86bff8e7d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Delete:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity2074e6e2a2f511e4adaceca86bff8e7d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6974">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity2074e6e2a2f511e4adaceca86bff8e7d" name="act2074e6e2a2f511e4adaceca86bff8e7d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6980">
                                                                                                        <label for="activity2b264d7ea2f511e4adaceca86bff8e7d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Export Data:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity2b264d7ea2f511e4adaceca86bff8e7d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6981">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity2b264d7ea2f511e4adaceca86bff8e7d" name="act2b264d7ea2f511e4adaceca86bff8e7d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6987">
                                                                                                        <label for="activity34d00e6ea2f511e4adaceca86bff8e7d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Print:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity34d00e6ea2f511e4adaceca86bff8e7d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6988">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity34d00e6ea2f511e4adaceca86bff8e7d" name="act34d00e6ea2f511e4adaceca86bff8e7d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen6994">
                                                                                                        <label for="activity3846576f47ad41c8a8b5c1e8d7f7ee93" style="padding-left:25px;width:225px;" class="x-form-item-label">...Copy:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity3846576f47ad41c8a8b5c1e8d7f7ee93" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen6995">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity3846576f47ad41c8a8b5c1e8d7f7ee93" name="act3846576f47ad41c8a8b5c1e8d7f7ee93" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                        <fieldset id="feature2d428a08f31f11e48635eca86bff9ae1" class=" x-fieldset x-panel-collapsed" style="margin: 10px;">
                                                                                            <legend class="x-fieldset-header x-unselectable" id="wtf-gen5623">
                                                                                                <div class="x-tool x-tool-toggle" id="wtf-gen5627">&nbsp;</div><span class="x-fieldset-header-text" id="wtf-gen5631">Consignment Stock - Sales</span></legend>
                                                                                            <div class="x-fieldset-bwrap" id="wtf-gen5624">
                                                                                                <div class="x-fieldset-body" id="wtf-gen5625">
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7001">
                                                                                                        <label for="activity2d428a08f31f11e48635eca86bff9001" style="width:250px; font-weight:bold;" class="x-form-item-label">Create Consignment Request:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity2d428a08f31f11e48635eca86bff9001" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7002">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity2d428a08f31f11e48635eca86bff9001" name="act2d428a08f31f11e48635eca86bff9001" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7008">
                                                                                                        <label for="activity2d428a08f31f11e48635eca86bff9002" style="width:250px; font-weight:bold;" class="x-form-item-label">View Consignment Request:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity2d428a08f31f11e48635eca86bff9002" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7009">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity2d428a08f31f11e48635eca86bff9002" name="act2d428a08f31f11e48635eca86bff9002" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7015">
                                                                                                        <label for="activity2d428a08f31f11e48635eca86bff9003" style="padding-left:25px;width:225px;" class="x-form-item-label">...Modify:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity2d428a08f31f11e48635eca86bff9003" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7016">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity2d428a08f31f11e48635eca86bff9003" name="act2d428a08f31f11e48635eca86bff9003" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7022">
                                                                                                        <label for="activity2d428a08f31f11e48635eca86bff9004" style="padding-left:25px;width:225px;" class="x-form-item-label">...Delete/Freeze:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity2d428a08f31f11e48635eca86bff9004" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7023">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity2d428a08f31f11e48635eca86bff9004" name="act2d428a08f31f11e48635eca86bff9004" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7029">
                                                                                                        <label for="activity2d428a08f31f11e48635eca86bff9005" style="padding-left:25px;width:225px;" class="x-form-item-label">...Export Data:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity2d428a08f31f11e48635eca86bff9005" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7030">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity2d428a08f31f11e48635eca86bff9005" name="act2d428a08f31f11e48635eca86bff9005" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7036">
                                                                                                        <label for="activity2d428a08f31f11e48635eca86bff9006" style="padding-left:25px;width:225px;" class="x-form-item-label">...Print:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity2d428a08f31f11e48635eca86bff9006" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7037">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity2d428a08f31f11e48635eca86bff9006" name="act2d428a08f31f11e48635eca86bff9006" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7043">
                                                                                                        <label for="activity2d428a08f31f11e48635eca86bff9007" style="width:250px; font-weight:bold;" class="x-form-item-label">Create Consignment Delivery Order:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity2d428a08f31f11e48635eca86bff9007" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7044">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity2d428a08f31f11e48635eca86bff9007" name="act2d428a08f31f11e48635eca86bff9007" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7050">
                                                                                                        <label for="activity2d428a08f31f11e48635eca86bff9008" style="width:250px; font-weight:bold;" class="x-form-item-label">View Consignment Delivery Order:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity2d428a08f31f11e48635eca86bff9008" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7051">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity2d428a08f31f11e48635eca86bff9008" name="act2d428a08f31f11e48635eca86bff9008" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7057">
                                                                                                        <label for="activity2d428a08f31f11e48635eca86bff9009" style="padding-left:25px;width:225px;" class="x-form-item-label">...Modify:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity2d428a08f31f11e48635eca86bff9009" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7058">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity2d428a08f31f11e48635eca86bff9009" name="act2d428a08f31f11e48635eca86bff9009" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7064">
                                                                                                        <label for="activity2d428a08f31f11e48635eca86bff9010" style="padding-left:25px;width:225px;" class="x-form-item-label">...Delete:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity2d428a08f31f11e48635eca86bff9010" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7065">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity2d428a08f31f11e48635eca86bff9010" name="act2d428a08f31f11e48635eca86bff9010" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7071">
                                                                                                        <label for="activity2d428a08f31f11e48635eca86bff9011" style="padding-left:25px;width:225px;" class="x-form-item-label">...Export Data:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity2d428a08f31f11e48635eca86bff9011" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7072">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity2d428a08f31f11e48635eca86bff9011" name="act2d428a08f31f11e48635eca86bff9011" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7078">
                                                                                                        <label for="activity2d428a08f31f11e48635eca86bff9012" style="padding-left:25px;width:225px;" class="x-form-item-label">...Print:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity2d428a08f31f11e48635eca86bff9012" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7079">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity2d428a08f31f11e48635eca86bff9012" name="act2d428a08f31f11e48635eca86bff9012" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7085">
                                                                                                        <label for="activity2d428a08f31f11e48635eca86bff9013" style="width:250px; font-weight:bold;" class="x-form-item-label">Create Consignment Invoice:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity2d428a08f31f11e48635eca86bff9013" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7086">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity2d428a08f31f11e48635eca86bff9013" name="act2d428a08f31f11e48635eca86bff9013" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7092">
                                                                                                        <label for="activity2d428a08f31f11e48635eca86bff9014" style="width:250px; font-weight:bold;" class="x-form-item-label">View Consignment Sales Invoice:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity2d428a08f31f11e48635eca86bff9014" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7093">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity2d428a08f31f11e48635eca86bff9014" name="act2d428a08f31f11e48635eca86bff9014" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7099">
                                                                                                        <label for="activity2d428a08f31f11e48635eca86bff9015" style="padding-left:25px;width:225px;" class="x-form-item-label">...Modify:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity2d428a08f31f11e48635eca86bff9015" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7100">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity2d428a08f31f11e48635eca86bff9015" name="act2d428a08f31f11e48635eca86bff9015" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7106">
                                                                                                        <label for="activity2d428a08f31f11e48635eca86bff9016" style="padding-left:25px;width:225px;" class="x-form-item-label">...Delete:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity2d428a08f31f11e48635eca86bff9016" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7107">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity2d428a08f31f11e48635eca86bff9016" name="act2d428a08f31f11e48635eca86bff9016" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7113">
                                                                                                        <label for="activity2d428a08f31f11e48635eca86bff9017" style="padding-left:25px;width:225px;" class="x-form-item-label">...Export Data:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity2d428a08f31f11e48635eca86bff9017" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7114">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity2d428a08f31f11e48635eca86bff9017" name="act2d428a08f31f11e48635eca86bff9017" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7120">
                                                                                                        <label for="activity2d428a08f31f11e48635eca86bff9018" style="padding-left:25px;width:225px;" class="x-form-item-label">...Print:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity2d428a08f31f11e48635eca86bff9018" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7121">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity2d428a08f31f11e48635eca86bff9018" name="act2d428a08f31f11e48635eca86bff9018" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7127">
                                                                                                        <label for="activity2d428a08f31f11e48635eca86bff9019" style="width:250px; font-weight:bold;" class="x-form-item-label">Create Consignment Return:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity2d428a08f31f11e48635eca86bff9019" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7128">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity2d428a08f31f11e48635eca86bff9019" name="act2d428a08f31f11e48635eca86bff9019" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7134">
                                                                                                        <label for="activity2d428a08f31f11e48635eca86bff9020" style="width:250px; font-weight:bold;" class="x-form-item-label">View Consignment Return:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity2d428a08f31f11e48635eca86bff9020" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7135">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity2d428a08f31f11e48635eca86bff9020" name="act2d428a08f31f11e48635eca86bff9020" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7141">
                                                                                                        <label for="activity2d428a08f31f11e48635eca86bff9021" style="padding-left:25px;width:225px;" class="x-form-item-label">...Modify:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity2d428a08f31f11e48635eca86bff9021" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7142">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity2d428a08f31f11e48635eca86bff9021" name="act2d428a08f31f11e48635eca86bff9021" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7148">
                                                                                                        <label for="activity2d428a08f31f11e48635eca86bff9022" style="padding-left:25px;width:225px;" class="x-form-item-label">...Delete:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity2d428a08f31f11e48635eca86bff9022" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7149">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity2d428a08f31f11e48635eca86bff9022" name="act2d428a08f31f11e48635eca86bff9022" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7155">
                                                                                                        <label for="activity2d428a08f31f11e48635eca86bff9023" style="padding-left:25px;width:225px;" class="x-form-item-label">...Export Data:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity2d428a08f31f11e48635eca86bff9023" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7156">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity2d428a08f31f11e48635eca86bff9023" name="act2d428a08f31f11e48635eca86bff9023" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7162">
                                                                                                        <label for="activity2d428a08f31f11e48635eca86bff9024" style="padding-left:25px;width:225px;" class="x-form-item-label">...Print:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity2d428a08f31f11e48635eca86bff9024" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7163">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity2d428a08f31f11e48635eca86bff9024" name="act2d428a08f31f11e48635eca86bff9024" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7169">
                                                                                                        <label for="activity2d428a08f31f11e48635eca86bfg1056" style="width:250px; font-weight:bold;" class="x-form-item-label">View Consignment Loan Report:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity2d428a08f31f11e48635eca86bfg1056" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7170">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity2d428a08f31f11e48635eca86bfg1056" name="act2d428a08f31f11e48635eca86bfg1056" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7176">
                                                                                                        <label for="activity2d428a08f31f11e48635eca86bfg1057" style="padding-left:25px;width:225px;" class="x-form-item-label">...Export:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity2d428a08f31f11e48635eca86bfg1057" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7177">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity2d428a08f31f11e48635eca86bfg1057" name="act2d428a08f31f11e48635eca86bfg1057" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7183">
                                                                                                        <label for="activity2d428a08f31f11e48635eca86bfg1058" style="width:250px; font-weight:bold;" class="x-form-item-label">View Consignment Outstanding Loan Report:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity2d428a08f31f11e48635eca86bfg1058" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7184">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity2d428a08f31f11e48635eca86bfg1058" name="act2d428a08f31f11e48635eca86bfg1058" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7190">
                                                                                                        <label for="activity2d428a08f31f11e48635eca86bfg1059" style="padding-left:25px;width:225px;" class="x-form-item-label">...Export:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity2d428a08f31f11e48635eca86bfg1059" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7191">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity2d428a08f31f11e48635eca86bfg1059" name="act2d428a08f31f11e48635eca86bfg1059" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7197">
                                                                                                        <label for="activity2d428a08f31f11e48635eca86bfg1060" style="width:250px; font-weight:bold;" class="x-form-item-label">View Stock availability by customer Warehouse:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity2d428a08f31f11e48635eca86bfg1060" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7198">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity2d428a08f31f11e48635eca86bfg1060" name="act2d428a08f31f11e48635eca86bfg1060" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                        <fieldset id="feature4f52f9615e344a50a7e1c8c6a51ded39" class=" x-fieldset x-panel-collapsed" style="margin: 10px;">
                                                                                            <legend class="x-fieldset-header x-unselectable" id="wtf-gen5632">
                                                                                                <div class="x-tool x-tool-toggle" id="wtf-gen5636">&nbsp;</div><span class="x-fieldset-header-text" id="wtf-gen5640">Stock Request</span></legend>
                                                                                            <div class="x-fieldset-bwrap" id="wtf-gen5633">
                                                                                                <div class="x-fieldset-body" id="wtf-gen5634">
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7204">
                                                                                                        <label for="activitybfce585be66c4997b03fb4230450e6de" style="width:250px; font-weight:bold;" class="x-form-item-label">Create:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activitybfce585be66c4997b03fb4230450e6de" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7205">
                                                                                                                <input type="checkbox" autocomplete="off" id="activitybfce585be66c4997b03fb4230450e6de" name="actbfce585be66c4997b03fb4230450e6de" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7211">
                                                                                                        <label for="activity7f7e63b7589b4de4b9ae13b804f6cfb9" style="width:250px; font-weight:bold;" class="x-form-item-label">View:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity7f7e63b7589b4de4b9ae13b804f6cfb9" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7212">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity7f7e63b7589b4de4b9ae13b804f6cfb9" name="act7f7e63b7589b4de4b9ae13b804f6cfb9" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7218">
                                                                                                        <label for="activity1bc39d2fb2e04911aeac61ee9eef5a98" style="padding-left:25px;width:225px;" class="x-form-item-label">...Issue Stock:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity1bc39d2fb2e04911aeac61ee9eef5a98" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7219">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity1bc39d2fb2e04911aeac61ee9eef5a98" name="act1bc39d2fb2e04911aeac61ee9eef5a98" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7225">
                                                                                                        <label for="activity6835afb53f3b43ad946e32af419edcf9" style="padding-left:25px;width:225px;" class="x-form-item-label">...Collect Stock:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity6835afb53f3b43ad946e32af419edcf9" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7226">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity6835afb53f3b43ad946e32af419edcf9" name="act6835afb53f3b43ad946e32af419edcf9" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7232">
                                                                                                        <label for="activitye5c73219f867429c856ec0c6d2f88099" style="padding-left:25px;width:225px;" class="x-form-item-label">...Print:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activitye5c73219f867429c856ec0c6d2f88099" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7233">
                                                                                                                <input type="checkbox" autocomplete="off" id="activitye5c73219f867429c856ec0c6d2f88099" name="acte5c73219f867429c856ec0c6d2f88099" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7239">
                                                                                                        <label for="activityec9f2a27ac254e1298792216c7d5a39c" style="padding-left:25px;width:225px;" class="x-form-item-label">...Export:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityec9f2a27ac254e1298792216c7d5a39c" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7240">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityec9f2a27ac254e1298792216c7d5a39c" name="actec9f2a27ac254e1298792216c7d5a39c" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                        <fieldset id="featurebd7ef07de36f443aaeb8f56c3550fa85" class=" x-fieldset x-panel-collapsed" style="margin: 10px;">
                                                                                            <legend class="x-fieldset-header x-unselectable" id="wtf-gen5641">
                                                                                                <div class="x-tool x-tool-toggle" id="wtf-gen5645">&nbsp;</div><span class="x-fieldset-header-text" id="wtf-gen5649">Stock Adjustment</span></legend>
                                                                                            <div class="x-fieldset-bwrap" id="wtf-gen5642">
                                                                                                <div class="x-fieldset-body" id="wtf-gen5643">
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7246">
                                                                                                        <label for="activity22fdbbe5620d47c08fdbe4e61a5f0475" style="width:250px; font-weight:bold;" class="x-form-item-label">Create:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity22fdbbe5620d47c08fdbe4e61a5f0475" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7247">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity22fdbbe5620d47c08fdbe4e61a5f0475" name="act22fdbbe5620d47c08fdbe4e61a5f0475" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7253">
                                                                                                        <label for="activityefc3c2f2763046afbc282d27213c619a" style="width:250px; font-weight:bold;" class="x-form-item-label">View:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityefc3c2f2763046afbc282d27213c619a" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7254">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityefc3c2f2763046afbc282d27213c619a" name="actefc3c2f2763046afbc282d27213c619a" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7260">
                                                                                                        <label for="activity638047ff81ec40589f578817743c77c3" style="padding-left:25px;width:225px;" class="x-form-item-label">...Export:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity638047ff81ec40589f578817743c77c3" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7261">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity638047ff81ec40589f578817743c77c3" name="act638047ff81ec40589f578817743c77c3" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                        <fieldset id="feature01156a6e8f6649cfb885d78b7a1ab6d1" class=" x-fieldset x-panel-collapsed" style="margin: 10px;">
                                                                                            <legend class="x-fieldset-header x-unselectable" id="wtf-gen5650">
                                                                                                <div class="x-tool x-tool-toggle" id="wtf-gen5654">&nbsp;</div><span class="x-fieldset-header-text" id="wtf-gen5658">Inter Location Stock Transfer</span></legend>
                                                                                            <div class="x-fieldset-bwrap" id="wtf-gen5651">
                                                                                                <div class="x-fieldset-body" id="wtf-gen5652">
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7267">
                                                                                                        <label for="activity088600e381f14663a5b3d7d83dedf642" style="width:250px; font-weight:bold;" class="x-form-item-label">Create:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity088600e381f14663a5b3d7d83dedf642" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7268">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity088600e381f14663a5b3d7d83dedf642" name="act088600e381f14663a5b3d7d83dedf642" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                        <fieldset id="feature8aa257b02afc4f04875d1a54810257fd" class=" x-fieldset x-panel-collapsed" style="margin: 10px;">
                                                                                            <legend class="x-fieldset-header x-unselectable" id="wtf-gen5659">
                                                                                                <div class="x-tool x-tool-toggle" id="wtf-gen5663">&nbsp;</div><span class="x-fieldset-header-text" id="wtf-gen5667">Inventory Reports</span></legend>
                                                                                            <div class="x-fieldset-bwrap" id="wtf-gen5660">
                                                                                                <div class="x-fieldset-body" id="wtf-gen5661">
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7274">
                                                                                                        <label for="activity3346576f47ad41c7a7b5c1e8d7f1ec93" style="width:250px; font-weight:bold;" class="x-form-item-label">Stock Availability By Warehouse:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity3346576f47ad41c7a7b5c1e8d7f1ec93" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7275">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity3346576f47ad41c7a7b5c1e8d7f1ec93" name="act3346576f47ad41c7a7b5c1e8d7f1ec93" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7281">
                                                                                                        <label for="activity7adb6a622f124129af6e23b9b26cbaf7" style="width:250px; font-weight:bold;" class="x-form-item-label">Batch Wise Stock Tracking:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity7adb6a622f124129af6e23b9b26cbaf7" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7282">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity7adb6a622f124129af6e23b9b26cbaf7" name="act7adb6a622f124129af6e23b9b26cbaf7" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7288">
                                                                                                        <label for="activityee38e3affabd48179023bfb3f8342e1d" style="width:250px; font-weight:bold;" class="x-form-item-label">Material In/Out Register:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityee38e3affabd48179023bfb3f8342e1d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7289">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityee38e3affabd48179023bfb3f8342e1d" name="actee38e3affabd48179023bfb3f8342e1d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7295">
                                                                                                        <label for="activitybd01dd3c2e3b4dc3a3c1c809eb4399ba" style="width:250px; font-weight:bold;" class="x-form-item-label">Stock Movement Register:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activitybd01dd3c2e3b4dc3a3c1c809eb4399ba" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7296">
                                                                                                                <input type="checkbox" autocomplete="off" id="activitybd01dd3c2e3b4dc3a3c1c809eb4399ba" name="actbd01dd3c2e3b4dc3a3c1c809eb4399ba" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7302">
                                                                                                        <label for="activity3346576f47ad41c7a7b5c1e8d7f1ee93" style="width:250px; font-weight:bold;" class="x-form-item-label">View product threshold Report:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity3346576f47ad41c7a7b5c1e8d7f1ee93" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7303">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity3346576f47ad41c7a7b5c1e8d7f1ee93" name="act3346576f47ad41c7a7b5c1e8d7f1ee93" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7309">
                                                                                                        <label for="activity7adb6a622f124129af6e23b9b26ceaf7" style="width:250px; font-weight:bold;" class="x-form-item-label">View Inventory Configuration:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity7adb6a622f124129af6e23b9b26ceaf7" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7310">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity7adb6a622f124129af6e23b9b26ceaf7" name="act7adb6a622f124129af6e23b9b26ceaf7" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                        <fieldset id="feature4f52f9615e344a50a7e1c8c6a51def99" class=" x-fieldset x-panel-collapsed" style="margin: 10px;">
                                                                                            <legend class="x-fieldset-header x-unselectable" id="wtf-gen5668">
                                                                                                <div class="x-tool x-tool-toggle" id="wtf-gen5672">&nbsp;</div><span class="x-fieldset-header-text" id="wtf-gen5676">Receive payment</span></legend>
                                                                                            <div class="x-fieldset-bwrap" id="wtf-gen5669">
                                                                                                <div class="x-fieldset-body" id="wtf-gen5670">
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7316">
                                                                                                        <label for="activity7f6b5cfaa1f911e489a8eca86yff8204" style="width:250px; font-weight:bold;" class="x-form-item-label">Import Receive Payments:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity7f6b5cfaa1f911e489a8eca86yff8204" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7317">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity7f6b5cfaa1f911e489a8eca86yff8204" name="act7f6b5cfaa1f911e489a8eca86yff8204" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7323">
                                                                                                        <label for="activityff80808122f3cb640122f45ef38b0197e" style="width:250px; font-weight:bold;" class="x-form-item-label">Create Receive Payment:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f3cb640122f45ef38b0197e" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7324">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f3cb640122f45ef38b0197e" name="actff80808122f3cb640122f45ef38b0197e" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7330">
                                                                                                        <label for="activityff80808122f9dba90122fa4888cf01985" style="width:250px; font-weight:bold;" class="x-form-item-label">View Payment Received Report:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba90122fa4888cf01985" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7331">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba90122fa4888cf01985" name="actff80808122f9dba90122fa4888cf01985" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7337">
                                                                                                        <label for="activityff80808122f9dba90122fa4888cf01994" style="padding-left:25px;width:225px;" class="x-form-item-label">...Modify:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba90122fa4888cf01994" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7338">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba90122fa4888cf01994" name="actff80808122f9dba90122fa4888cf01994" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7344">
                                                                                                        <label for="activity3846576f47ad41c7a7b5c1e8d7f7e1200" style="padding-left:25px;width:225px;" class="x-form-item-label">...Copy:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity3846576f47ad41c7a7b5c1e8d7f7e1200" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7345">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity3846576f47ad41c7a7b5c1e8d7f7e1200" name="act3846576f47ad41c7a7b5c1e8d7f7e1200" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7351">
                                                                                                        <label for="activityff80808122f9dba90122fa4888yf00201" style="padding-left:25px;width:225px;" class="x-form-item-label">...Delete:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba90122fa4888yf00201" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7352">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba90122fa4888yf00201" name="actff80808122f9dba90122fa4888yf00201" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7358">
                                                                                                        <label for="activityff80808122f9dba90122fa4888yf00202" style="padding-left:25px;width:225px;" class="x-form-item-label">...Email:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba90122fa4888yf00202" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7359">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba90122fa4888yf00202" name="actff80808122f9dba90122fa4888yf00202" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7365">
                                                                                                        <label for="activityff80808122f9dba90122fa4888yf00203" style="padding-left:25px;width:225px;" class="x-form-item-label">...Export Data:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba90122fa4888yf00203" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7366">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba90122fa4888yf00203" name="actff80808122f9dba90122fa4888yf00203" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7372">
                                                                                                        <label for="activityff80808122f9dba90122fa4888yf00205" style="padding-left:25px;width:225px;" class="x-form-item-label">...Print:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba90122fa4888yf00205" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7373">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba90122fa4888yf00205" name="actff80808122f9dba90122fa4888yf00205" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                        <fieldset id="feature5f52f9615e344a50a7e1c8c6a51def99" class=" x-fieldset x-panel-collapsed" style="margin: 10px;">
                                                                                            <legend class="x-fieldset-header x-unselectable" id="wtf-gen5677">
                                                                                                <div class="x-tool x-tool-toggle" id="wtf-gen5681">&nbsp;</div><span class="x-fieldset-header-text" id="wtf-gen5685">Asset Sales  Management</span></legend>
                                                                                            <div class="x-fieldset-bwrap" id="wtf-gen5678">
                                                                                                <div class="x-fieldset-body" id="wtf-gen5679">
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7379">
                                                                                                        <label for="activity3f13c30a9bb811e48d2eeca86bff8e8d" style="width:250px; font-weight:bold;" class="x-form-item-label">Create Asset Delivery Order:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity3f13c30a9bb811e48d2eeca86bff8e8d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7380">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity3f13c30a9bb811e48d2eeca86bff8e8d" name="act3f13c30a9bb811e48d2eeca86bff8e8d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7386">
                                                                                                        <label for="activity645c75269bb811e48d2eeca86bff8e8d" style="width:250px; font-weight:bold;" class="x-form-item-label">View Asset Delivery Order:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity645c75269bb811e48d2eeca86bff8e8d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7387">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity645c75269bb811e48d2eeca86bff8e8d" name="act645c75269bb811e48d2eeca86bff8e8d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7393">
                                                                                                        <label for="activity6bd106829bb811e48d2eeca86bff8e8d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Edit:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity6bd106829bb811e48d2eeca86bff8e8d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7394">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity6bd106829bb811e48d2eeca86bff8e8d" name="act6bd106829bb811e48d2eeca86bff8e8d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7400">
                                                                                                        <label for="activity73e151889bb811e48d2eeca86bff8e8d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Delete:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity73e151889bb811e48d2eeca86bff8e8d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7401">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity73e151889bb811e48d2eeca86bff8e8d" name="act73e151889bb811e48d2eeca86bff8e8d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7407">
                                                                                                        <label for="activity7b5afdb09bb811e48d2eeca86bff8e8d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Export:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity7b5afdb09bb811e48d2eeca86bff8e8d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7408">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity7b5afdb09bb811e48d2eeca86bff8e8d" name="act7b5afdb09bb811e48d2eeca86bff8e8d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7414">
                                                                                                        <label for="activity826982029bb811e48d2eeca86bff8e8d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Print:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity826982029bb811e48d2eeca86bff8e8d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7415">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity826982029bb811e48d2eeca86bff8e8d" name="act826982029bb811e48d2eeca86bff8e8d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7421">
                                                                                                        <label for="activityaeb02ec09bb711e4b5cbeca86bff8e8d" style="width:250px; font-weight:bold;" class="x-form-item-label">Create Disposal Invoice:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityaeb02ec09bb711e4b5cbeca86bff8e8d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7422">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityaeb02ec09bb711e4b5cbeca86bff8e8d" name="actaeb02ec09bb711e4b5cbeca86bff8e8d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7428">
                                                                                                        <label for="activityb6e1ce829bb711e4b5cbeca86bff8e8d" style="width:250px; font-weight:bold;" class="x-form-item-label">View Disposal Invoice:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityb6e1ce829bb711e4b5cbeca86bff8e8d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7429">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityb6e1ce829bb711e4b5cbeca86bff8e8d" name="actb6e1ce829bb711e4b5cbeca86bff8e8d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7435">
                                                                                                        <label for="activityc31ee8a69bb711e48d2eeca86bff8e8d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Edit:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityc31ee8a69bb711e48d2eeca86bff8e8d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7436">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityc31ee8a69bb711e48d2eeca86bff8e8d" name="actc31ee8a69bb711e48d2eeca86bff8e8d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7442">
                                                                                                        <label for="activitycc4da7469bb711e48d2eeca86bff8e8d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Delete:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activitycc4da7469bb711e48d2eeca86bff8e8d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7443">
                                                                                                                <input type="checkbox" autocomplete="off" id="activitycc4da7469bb711e48d2eeca86bff8e8d" name="actcc4da7469bb711e48d2eeca86bff8e8d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7449">
                                                                                                        <label for="activityd5d0a44e9bb711e48d2eeca86bff8e8d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Export:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityd5d0a44e9bb711e48d2eeca86bff8e8d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7450">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityd5d0a44e9bb711e48d2eeca86bff8e8d" name="actd5d0a44e9bb711e48d2eeca86bff8e8d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7456">
                                                                                                        <label for="activityded60e769bb711e48d2eeca86bff8e8d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Print:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityded60e769bb711e48d2eeca86bff8e8d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7457">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityded60e769bb711e48d2eeca86bff8e8d" name="actded60e769bb711e48d2eeca86bff8e8d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                        <fieldset id="feature5f52f9615e374a50a7e1c8c6a61deg99" class=" x-fieldset x-panel-collapsed" style="margin: 10px;">
                                                                                            <legend class="x-fieldset-header x-unselectable" id="wtf-gen5686">
                                                                                                <div class="x-tool x-tool-toggle" id="wtf-gen5690">&nbsp;</div><span class="x-fieldset-header-text" id="wtf-gen5694">Lease Management</span></legend>
                                                                                            <div class="x-fieldset-bwrap" id="wtf-gen5687">
                                                                                                <div class="x-fieldset-body" id="wtf-gen5688">
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7463">
                                                                                                        <label for="activity0cf856b69cb813e48d2eeca86bff8e8d" style="width:250px; font-weight:bold;" class="x-form-item-label">Create Lease Quotation:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity0cf856b69cb813e48d2eeca86bff8e8d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7464">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity0cf856b69cb813e48d2eeca86bff8e8d" name="act0cf856b69cb813e48d2eeca86bff8e8d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7470">
                                                                                                        <label for="activity177f2c309cb814e48d2eeca86bff8e8d" style="width:250px; font-weight:bold;" class="x-form-item-label">View Lease Quotation Report:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity177f2c309cb814e48d2eeca86bff8e8d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7471">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity177f2c309cb814e48d2eeca86bff8e8d" name="act177f2c309cb814e48d2eeca86bff8e8d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7477">
                                                                                                        <label for="activity1f488cc29cb814e48d2eeca86bff8e8d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Edit:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity1f488cc29cb814e48d2eeca86bff8e8d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7478">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity1f488cc29cb814e48d2eeca86bff8e8d" name="act1f488cc29cb814e48d2eeca86bff8e8d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7484">
                                                                                                        <label for="activity26b311629cb814e48d2eeca86bff8e8d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Delete:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity26b311629cb814e48d2eeca86bff8e8d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7485">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity26b311629cb814e48d2eeca86bff8e8d" name="act26b311629cb814e48d2eeca86bff8e8d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7491">
                                                                                                        <label for="activity2f483f6e9cb815e48d2eeca86bff8e9d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Export:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity2f483f6e9cb815e48d2eeca86bff8e9d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7492">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity2f483f6e9cb815e48d2eeca86bff8e9d" name="act2f483f6e9cb815e48d2eeca86bff8e9d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7498">
                                                                                                        <label for="activity360ba9b29cb814e48d2eeca86bff8e8d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Print:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity360ba9b29cb814e48d2eeca86bff8e8d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7499">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity360ba9b29cb814e48d2eeca86bff8e8d" name="act360ba9b29cb814e48d2eeca86bff8e8d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7505">
                                                                                                        <label for="activity67f013889cb714e4b5cbeca86bff8e9d" style="width:250px; font-weight:bold;" class="x-form-item-label">Create Lease Order:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity67f013889cb714e4b5cbeca86bff8e9d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7506">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity67f013889cb714e4b5cbeca86bff8e9d" name="act67f013889cb714e4b5cbeca86bff8e9d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7512">
                                                                                                        <label for="activity7b45ddbe9cb714e4b5cbeca86bff8e9d" style="width:250px; font-weight:bold;" class="x-form-item-label">View Lease Order Report:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity7b45ddbe9cb714e4b5cbeca86bff8e9d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7513">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity7b45ddbe9cb714e4b5cbeca86bff8e9d" name="act7b45ddbe9cb714e4b5cbeca86bff8e9d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7519">
                                                                                                        <label for="activity8af321d69cb714e4b5cbeca86bff8e9d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Edit:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity8af321d69cb714e4b5cbeca86bff8e9d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7520">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity8af321d69cb714e4b5cbeca86bff8e9d" name="act8af321d69cb714e4b5cbeca86bff8e9d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7526">
                                                                                                        <label for="activity938481789cb714e4b5cbeca86bff8e9d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Delete:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity938481789cb714e4b5cbeca86bff8e9d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7527">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity938481789cb714e4b5cbeca86bff8e9d" name="act938481789cb714e4b5cbeca86bff8e9d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7533">
                                                                                                        <label for="activity9c99f7669cb714e4b5cbeca86bff8e9d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Export:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity9c99f7669cb714e4b5cbeca86bff8e9d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7534">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity9c99f7669cb714e4b5cbeca86bff8e9d" name="act9c99f7669cb714e4b5cbeca86bff8e9d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7540">
                                                                                                        <label for="activitya6ca0d2a9cb714e4b5cbeca86bff8e9d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Print:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activitya6ca0d2a9cb714e4b5cbeca86bff8e9d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7541">
                                                                                                                <input type="checkbox" autocomplete="off" id="activitya6ca0d2a9cb714e4b5cbeca86bff8e9d" name="acta6ca0d2a9cb714e4b5cbeca86bff8e9d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7547">
                                                                                                        <label for="activity69f013889cb714e4b5cbeca86bff8e9d" style="width:250px; font-weight:bold;" class="x-form-item-label">Create Lease Delivery Order:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity69f013889cb714e4b5cbeca86bff8e9d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7548">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity69f013889cb714e4b5cbeca86bff8e9d" name="act69f013889cb714e4b5cbeca86bff8e9d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7554">
                                                                                                        <label for="activity7b49ddbe9cb714e4b5cbeca86bff8e9d" style="width:250px; font-weight:bold;" class="x-form-item-label">View Lease Delivery Order Report:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity7b49ddbe9cb714e4b5cbeca86bff8e9d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7555">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity7b49ddbe9cb714e4b5cbeca86bff8e9d" name="act7b49ddbe9cb714e4b5cbeca86bff8e9d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7561">
                                                                                                        <label for="activity8af381d69cb714e4b5cbeca86bff8e9d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Edit:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity8af381d69cb714e4b5cbeca86bff8e9d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7562">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity8af381d69cb714e4b5cbeca86bff8e9d" name="act8af381d69cb714e4b5cbeca86bff8e9d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7568">
                                                                                                        <label for="activity938491789cb714e4b5cbeca86bff8e9d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Delete:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity938491789cb714e4b5cbeca86bff8e9d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7569">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity938491789cb714e4b5cbeca86bff8e9d" name="act938491789cb714e4b5cbeca86bff8e9d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7575">
                                                                                                        <label for="activity9c99k7669cb714e4b5cbeca86bff8e9d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Export:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity9c99k7669cb714e4b5cbeca86bff8e9d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7576">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity9c99k7669cb714e4b5cbeca86bff8e9d" name="act9c99k7669cb714e4b5cbeca86bff8e9d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7582">
                                                                                                        <label for="activitya6ci7d2a9cb714e4b5cbeca86bff8e9d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Print:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activitya6ci7d2a9cb714e4b5cbeca86bff8e9d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7583">
                                                                                                                <input type="checkbox" autocomplete="off" id="activitya6ci7d2a9cb714e4b5cbeca86bff8e9d" name="acta6ci7d2a9cb714e4b5cbeca86bff8e9d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7589">
                                                                                                        <label for="activity67f013889cb714e4b5cbeca86bfp8e9d" style="width:250px; font-weight:bold;" class="x-form-item-label">Create Lease invoice:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity67f013889cb714e4b5cbeca86bfp8e9d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7590">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity67f013889cb714e4b5cbeca86bfp8e9d" name="act67f013889cb714e4b5cbeca86bfp8e9d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7596">
                                                                                                        <label for="activity7b45ddbe9cb714e4b5cbeca86bpf8e9d" style="width:250px; font-weight:bold;" class="x-form-item-label">View Lease invoice List:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity7b45ddbe9cb714e4b5cbeca86bpf8e9d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7597">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity7b45ddbe9cb714e4b5cbeca86bpf8e9d" name="act7b45ddbe9cb714e4b5cbeca86bpf8e9d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7603">
                                                                                                        <label for="activity8af321d69cb714e4b5cbeca86bpf8e9d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Edit:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity8af321d69cb714e4b5cbeca86bpf8e9d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7604">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity8af321d69cb714e4b5cbeca86bpf8e9d" name="act8af321d69cb714e4b5cbeca86bpf8e9d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7610">
                                                                                                        <label for="activity938481789cb714e4b5cbeca86pff8e9d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Delete:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity938481789cb714e4b5cbeca86pff8e9d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7611">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity938481789cb714e4b5cbeca86pff8e9d" name="act938481789cb714e4b5cbeca86pff8e9d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7617">
                                                                                                        <label for="activity9c99f7669cb714e4b5cbeca86pff8e9d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Export:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity9c99f7669cb714e4b5cbeca86pff8e9d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7618">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity9c99f7669cb714e4b5cbeca86pff8e9d" name="act9c99f7669cb714e4b5cbeca86pff8e9d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7624">
                                                                                                        <label for="activitya6ca0d2a9cb714e4b5cbeca86pff8e9d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Print:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activitya6ca0d2a9cb714e4b5cbeca86pff8e9d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7625">
                                                                                                                <input type="checkbox" autocomplete="off" id="activitya6ca0d2a9cb714e4b5cbeca86pff8e9d" name="acta6ca0d2a9cb714e4b5cbeca86pff8e9d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7631">
                                                                                                        <label for="activity67f013889cb714e4b5cbeca86bmf8e9d" style="width:250px; font-weight:bold;" class="x-form-item-label">Create Lease Return:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity67f013889cb714e4b5cbeca86bmf8e9d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7632">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity67f013889cb714e4b5cbeca86bmf8e9d" name="act67f013889cb714e4b5cbeca86bmf8e9d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7638">
                                                                                                        <label for="activity7b45ddbe9cb714e4b5cbeca86bmf8e9d" style="width:250px; font-weight:bold;" class="x-form-item-label">View Lease Return List:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity7b45ddbe9cb714e4b5cbeca86bmf8e9d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7639">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity7b45ddbe9cb714e4b5cbeca86bmf8e9d" name="act7b45ddbe9cb714e4b5cbeca86bmf8e9d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7645">
                                                                                                        <label for="activity8af321d69cb714e4b5cbeca86bmf8e9d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Edit:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity8af321d69cb714e4b5cbeca86bmf8e9d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7646">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity8af321d69cb714e4b5cbeca86bmf8e9d" name="act8af321d69cb714e4b5cbeca86bmf8e9d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7652">
                                                                                                        <label for="activity938481789cb714e4b5cbeca86bmf8e9d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Delete:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity938481789cb714e4b5cbeca86bmf8e9d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7653">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity938481789cb714e4b5cbeca86bmf8e9d" name="act938481789cb714e4b5cbeca86bmf8e9d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7659">
                                                                                                        <label for="activity9c99f7669cb714e4b5cbeca86bmf8e9d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Export:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity9c99f7669cb714e4b5cbeca86bmf8e9d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7660">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity9c99f7669cb714e4b5cbeca86bmf8e9d" name="act9c99f7669cb714e4b5cbeca86bmf8e9d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7666">
                                                                                                        <label for="activitya6ca0d2a9cb714e4b5cbeca86bmf8e9d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Print:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activitya6ca0d2a9cb714e4b5cbeca86bmf8e9d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7667">
                                                                                                                <input type="checkbox" autocomplete="off" id="activitya6ca0d2a9cb714e4b5cbeca86bmf8e9d" name="acta6ca0d2a9cb714e4b5cbeca86bmf8e9d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                        <fieldset id="feature3a0cb967a6c14c65903391cce5627f03" class=" x-fieldset x-panel-collapsed" style="margin: 10px;">
                                                                                            <legend class="x-fieldset-header x-unselectable" id="wtf-gen5695">
                                                                                                <div class="x-tool x-tool-toggle" id="wtf-gen5699">&nbsp;</div><span class="x-fieldset-header-text" id="wtf-gen5703">Stock Repair</span></legend>
                                                                                            <div class="x-fieldset-bwrap" id="wtf-gen5696">
                                                                                                <div class="x-fieldset-body" id="wtf-gen5697">
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7673">
                                                                                                        <label for="activity936ce3123d144bce96f5fc72e709e8eb" style="width:250px; font-weight:bold;" class="x-form-item-label">View:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity936ce3123d144bce96f5fc72e709e8eb" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7674">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity936ce3123d144bce96f5fc72e709e8eb" name="act936ce3123d144bce96f5fc72e709e8eb" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7680">
                                                                                                        <label for="activityc29da636c0394fcabda451e24aa31802" style="padding-left:25px;width:225px;" class="x-form-item-label">...Approve / Reject:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityc29da636c0394fcabda451e24aa31802" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7681">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityc29da636c0394fcabda451e24aa31802" name="actc29da636c0394fcabda451e24aa31802" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                        <fieldset id="feature5f92f9615e374a50a7e1c8c6a51deg99" class=" x-fieldset x-panel-collapsed" style="margin: 10px;">
                                                                                            <legend class="x-fieldset-header x-unselectable" id="wtf-gen5704">
                                                                                                <div class="x-tool x-tool-toggle" id="wtf-gen5708">&nbsp;</div><span class="x-fieldset-header-text" id="wtf-gen5712">Asset Purchase Requisition</span></legend>
                                                                                            <div class="x-fieldset-bwrap" id="wtf-gen5705">
                                                                                                <div class="x-fieldset-body" id="wtf-gen5706">
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7687">
                                                                                                        <label for="activity67f013889bb711e4b5cbeca86bfp8e9d" style="width:250px; font-weight:bold;" class="x-form-item-label">Create Asset Purchase Requisition:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity67f013889bb711e4b5cbeca86bfp8e9d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7688">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity67f013889bb711e4b5cbeca86bfp8e9d" name="act67f013889bb711e4b5cbeca86bfp8e9d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7694">
                                                                                                        <label for="activity7b45ddbe9bb711e4b5cbeca86bpf8e9d" style="width:250px; font-weight:bold;" class="x-form-item-label">View Asset Purchase Requisition:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity7b45ddbe9bb711e4b5cbeca86bpf8e9d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7695">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity7b45ddbe9bb711e4b5cbeca86bpf8e9d" name="act7b45ddbe9bb711e4b5cbeca86bpf8e9d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7701">
                                                                                                        <label for="activity8af321d69bb711e4b5cbeca86bpf8e9d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Edit:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity8af321d69bb711e4b5cbeca86bpf8e9d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7702">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity8af321d69bb711e4b5cbeca86bpf8e9d" name="act8af321d69bb711e4b5cbeca86bpf8e9d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7708">
                                                                                                        <label for="activity938481789bb711e4b5cbeca86pff8e9d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Delete:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity938481789bb711e4b5cbeca86pff8e9d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7709">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity938481789bb711e4b5cbeca86pff8e9d" name="act938481789bb711e4b5cbeca86pff8e9d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7715">
                                                                                                        <label for="activity9c99f7669bb711e4b5cbeca86pff8e9d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Export:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity9c99f7669bb711e4b5cbeca86pff8e9d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7716">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity9c99f7669bb711e4b5cbeca86pff8e9d" name="act9c99f7669bb711e4b5cbeca86pff8e9d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7722">
                                                                                                        <label for="activitya6ca0d2a9bb711e4b5cbeca86pff8e9d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Print:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activitya6ca0d2a9bb711e4b5cbeca86pff8e9d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7723">
                                                                                                                <input type="checkbox" autocomplete="off" id="activitya6ca0d2a9bb711e4b5cbeca86pff8e9d" name="acta6ca0d2a9bb711e4b5cbeca86pff8e9d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7729">
                                                                                                        <label for="activityadd0fe3240d313e5a22tc03fd5632a48" style="padding-left:25px;width:225px;" class="x-form-item-label">...Copy:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityadd0fe3240d313e5a22tc03fd5632a48" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7730">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityadd0fe3240d313e5a22tc03fd5632a48" name="actadd0fe3240d313e5a22tc03fd5632a48" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7736">
                                                                                                        <label for="activity6b08cfadd769446490e2cf7a3c23259b" style="width:250px; font-weight:bold;" class="x-form-item-label">Create Asset RFQ:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity6b08cfadd769446490e2cf7a3c23259b" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7737">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity6b08cfadd769446490e2cf7a3c23259b" name="act6b08cfadd769446490e2cf7a3c23259b" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7743">
                                                                                                        <label for="activity7c915ef1edd24ea6a87075b9ae800ce3" style="width:250px; font-weight:bold;" class="x-form-item-label">View Asset RFQ Report:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity7c915ef1edd24ea6a87075b9ae800ce3" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7744">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity7c915ef1edd24ea6a87075b9ae800ce3" name="act7c915ef1edd24ea6a87075b9ae800ce3" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7750">
                                                                                                        <label for="activitybafc116c0eda4abd8g68155b2f90dbb0" style="padding-left:25px;width:225px;" class="x-form-item-label">...Edit:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activitybafc116c0eda4abd8g68155b2f90dbb0" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7751">
                                                                                                                <input type="checkbox" autocomplete="off" id="activitybafc116c0eda4abd8g68155b2f90dbb0" name="actbafc116c0eda4abd8g68155b2f90dbb0" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7757">
                                                                                                        <label for="activity82909459cdaa44b3g2777229ff7540ac" style="padding-left:25px;width:225px;" class="x-form-item-label">...Delete:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity82909459cdaa44b3g2777229ff7540ac" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7758">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity82909459cdaa44b3g2777229ff7540ac" name="act82909459cdaa44b3g2777229ff7540ac" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7764">
                                                                                                        <label for="activity84c8cee2d8e0429254b1ee2df6ad83f0" style="padding-left:25px;width:225px;" class="x-form-item-label">...Export:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity84c8cee2d8e0429254b1ee2df6ad83f0" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7765">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity84c8cee2d8e0429254b1ee2df6ad83f0" name="act84c8cee2d8e0429254b1ee2df6ad83f0" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7771">
                                                                                                        <label for="activity1a121fdfc0e848bj93da6e62e18608b0" style="padding-left:25px;width:225px;" class="x-form-item-label">...Print:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity1a121fdfc0e848bj93da6e62e18608b0" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7772">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity1a121fdfc0e848bj93da6e62e18608b0" name="act1a121fdfc0e848bj93da6e62e18608b0" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7778">
                                                                                                        <label for="activityadd0fe3240d311jha22tc03fd5632a48" style="padding-left:25px;width:225px;" class="x-form-item-label">...Copy:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityadd0fe3240d311jha22tc03fd5632a48" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7779">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityadd0fe3240d311jha22tc03fd5632a48" name="actadd0fe3240d311jha22tc03fd5632a48" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                        <fieldset id="feature5f92f9615e374a50a7g1c8c6a51yeg22" class=" x-fieldset x-panel-collapsed" style="margin: 10px;">
                                                                                            <legend class="x-fieldset-header x-unselectable" id="wtf-gen5713">
                                                                                                <div class="x-tool x-tool-toggle" id="wtf-gen5717">&nbsp;</div><span class="x-fieldset-header-text" id="wtf-gen5721">Delivery Planner</span></legend>
                                                                                            <div class="x-fieldset-bwrap" id="wtf-gen5714">
                                                                                                <div class="x-fieldset-body" id="wtf-gen5715">
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7785">
                                                                                                        <label for="activity67f013889bb711e4b5cbdta86bft8e9d" style="width:250px; font-weight:bold;" class="x-form-item-label">View Delivery Planner:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity67f013889bb711e4b5cbdta86bft8e9d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7786">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity67f013889bb711e4b5cbdta86bft8e9d" name="act67f013889bb711e4b5cbdta86bft8e9d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7792">
                                                                                                        <label for="activity67f013889bb711e4b5cbdta86bft9e9d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Delete:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity67f013889bb711e4b5cbdta86bft9e9d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7793">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity67f013889bb711e4b5cbdta86bft9e9d" name="act67f013889bb711e4b5cbdta86bft9e9d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                        <fieldset id="featuree092295a9bd711e4trfeoca86bff8e7d" class=" x-fieldset x-panel-collapsed" style="margin: 10px;">
                                                                                            <legend class="x-fieldset-header x-unselectable" id="wtf-gen5722">
                                                                                                <div class="x-tool x-tool-toggle" id="wtf-gen5726">&nbsp;</div><span class="x-fieldset-header-text" id="wtf-gen5730">Asset Sales Return</span></legend>
                                                                                            <div class="x-fieldset-bwrap" id="wtf-gen5723">
                                                                                                <div class="x-fieldset-body" id="wtf-gen5724">
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7799">
                                                                                                        <label for="activity41dc91509bd8tre4bbfeeca86bff8e7d" style="width:250px; font-weight:bold;" class="x-form-item-label">Create Asset Sales Return:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity41dc91509bd8tre4bbfeeca86bff8e7d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7800">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity41dc91509bd8tre4bbfeeca86bff8e7d" name="act41dc91509bd8tre4bbfeeca86bff8e7d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7806">
                                                                                                        <label for="activity4a888d049bd8uye4bbfeeca86bff8e7d" style="width:250px; font-weight:bold;" class="x-form-item-label">View Asset Sales Return:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity4a888d049bd8uye4bbfeeca86bff8e7d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7807">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity4a888d049bd8uye4bbfeeca86bff8e7d" name="act4a888d049bd8uye4bbfeeca86bff8e7d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7813">
                                                                                                        <label for="activity533ea9389bd8ase4bbfeeca86bff8e7d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Edit:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity533ea9389bd8ase4bbfeeca86bff8e7d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7814">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity533ea9389bd8ase4bbfeeca86bff8e7d" name="act533ea9389bd8ase4bbfeeca86bff8e7d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7820">
                                                                                                        <label for="activity5b971eb29bd8uye4bbfeeca86bff8e7d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Delete:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity5b971eb29bd8uye4bbfeeca86bff8e7d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7821">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity5b971eb29bd8uye4bbfeeca86bff8e7d" name="act5b971eb29bd8uye4bbfeeca86bff8e7d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7827">
                                                                                                        <label for="activity6437e4fc9bd8kje4bbfeeca86bff8e7d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Export:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity6437e4fc9bd8kje4bbfeeca86bff8e7d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7828">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity6437e4fc9bd8kje4bbfeeca86bff8e7d" name="act6437e4fc9bd8kje4bbfeeca86bff8e7d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7834">
                                                                                                        <label for="activity6d6eef169bd8dse4bbfeeca86bff8e7d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Print:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity6d6eef169bd8dse4bbfeeca86bff8e7d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7835">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity6d6eef169bd8dse4bbfeeca86bff8e7d" name="act6d6eef169bd8dse4bbfeeca86bff8e7d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                        <fieldset id="feature2a0cb967a6c14c78603391cce1712905" class=" x-fieldset x-panel-collapsed" style="margin: 10px;">
                                                                                            <legend class="x-fieldset-header x-unselectable" id="wtf-gen5731">
                                                                                                <div class="x-tool x-tool-toggle" id="wtf-gen5735">&nbsp;</div><span class="x-fieldset-header-text" id="wtf-gen5739">Write Off and Recover Receipts</span></legend>
                                                                                            <div class="x-fieldset-bwrap" id="wtf-gen5732">
                                                                                                <div class="x-fieldset-body" id="wtf-gen5733">
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7841">
                                                                                                        <label for="activity936ce31231712bce96f5fc72e7092011" style="width:250px; font-weight:bold;" class="x-form-item-label">Write Off Receipts:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity936ce31231712bce96f5fc72e7092011" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7842">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity936ce31231712bce96f5fc72e7092011" name="act936ce31231712bce96f5fc72e7092011" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7848">
                                                                                                        <label for="activityc29da636c1715fcabda451e24aa32012" style="width:250px; font-weight:bold;" class="x-form-item-label">View Written Off Receipts:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityc29da636c1715fcabda451e24aa32012" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7849">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityc29da636c1715fcabda451e24aa32012" name="actc29da636c1715fcabda451e24aa32012" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7855">
                                                                                                        <label for="activityc29da636c1714fcabda451e24aa32013" style="padding-left:25px;width:225px;" class="x-form-item-label">...Recover Receipts:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityc29da636c1714fcabda451e24aa32013" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7856">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityc29da636c1714fcabda451e24aa32013" name="actc29da636c1714fcabda451e24aa32013" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                        <fieldset id="feature1a702a484c9c11e6beb89e71128cae77" class=" x-fieldset x-panel-collapsed" style="margin: 10px;">
                                                                                            <legend class="x-fieldset-header x-unselectable" id="wtf-gen5740">
                                                                                                <div class="x-tool x-tool-toggle" id="wtf-gen5744">&nbsp;</div><span class="x-fieldset-header-text" id="wtf-gen5748">Labour Master</span></legend>
                                                                                            <div class="x-fieldset-bwrap" id="wtf-gen5741">
                                                                                                <div class="x-fieldset-body" id="wtf-gen5742">
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7862">
                                                                                                        <label for="activity905aa5f24ca211e6beb89e71128cae77" style="width:250px; font-weight:bold;" class="x-form-item-label">Create :</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity905aa5f24ca211e6beb89e71128cae77" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7863">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity905aa5f24ca211e6beb89e71128cae77" name="act905aa5f24ca211e6beb89e71128cae77" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7869">
                                                                                                        <label for="activityc60317928cb84227bc58d18e0016179f" style="width:250px; font-weight:bold;" class="x-form-item-label">View :</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityc60317928cb84227bc58d18e0016179f" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7870">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityc60317928cb84227bc58d18e0016179f" name="actc60317928cb84227bc58d18e0016179f" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7876">
                                                                                                        <label for="activity905a9b024ca211e6beb89e71128cae77" style="padding-left:25px;width:225px;" class="x-form-item-label">...Modify :</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity905a9b024ca211e6beb89e71128cae77" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7877">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity905a9b024ca211e6beb89e71128cae77" name="act905a9b024ca211e6beb89e71128cae77" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7883">
                                                                                                        <label for="activityb6b7b8ba4cad11e6beb89e71128cae77" style="padding-left:25px;width:225px;" class="x-form-item-label">...Delete:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityb6b7b8ba4cad11e6beb89e71128cae77" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7884">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityb6b7b8ba4cad11e6beb89e71128cae77" name="actb6b7b8ba4cad11e6beb89e71128cae77" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7890">
                                                                                                        <label for="activityc35c49d49b014a1e888fbb29d4d76d00" style="padding-left:25px;width:225px;" class="x-form-item-label">...Export:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityc35c49d49b014a1e888fbb29d4d76d00" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7891">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityc35c49d49b014a1e888fbb29d4d76d00" name="actc35c49d49b014a1e888fbb29d4d76d00" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                        <fieldset id="featurefc31be704cd711e6beb89e71128cae77" class=" x-fieldset x-panel-collapsed" style="margin: 10px;">
                                                                                            <legend class="x-fieldset-header x-unselectable" id="wtf-gen5749">
                                                                                                <div class="x-tool x-tool-toggle" id="wtf-gen5753">&nbsp;</div><span class="x-fieldset-header-text" id="wtf-gen5757">Work Centre Master</span></legend>
                                                                                            <div class="x-fieldset-bwrap" id="wtf-gen5750">
                                                                                                <div class="x-fieldset-body" id="wtf-gen5751">
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7897">
                                                                                                        <label for="activityfc31c0e64cd711e6beb89e71128cae77" style="width:250px; font-weight:bold;" class="x-form-item-label">Create :</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityfc31c0e64cd711e6beb89e71128cae77" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7898">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityfc31c0e64cd711e6beb89e71128cae77" name="actfc31c0e64cd711e6beb89e71128cae77" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7904">
                                                                                                        <label for="activityfc31c33e4cd711e6beb89e71128cae77" style="width:250px; font-weight:bold;" class="x-form-item-label">View :</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityfc31c33e4cd711e6beb89e71128cae77" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7905">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityfc31c33e4cd711e6beb89e71128cae77" name="actfc31c33e4cd711e6beb89e71128cae77" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7911">
                                                                                                        <label for="activityfc31c6904cd711e6beb89e71128cae77" style="padding-left:25px;width:225px;" class="x-form-item-label">...Modify :</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityfc31c6904cd711e6beb89e71128cae77" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7912">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityfc31c6904cd711e6beb89e71128cae77" name="actfc31c6904cd711e6beb89e71128cae77" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7918">
                                                                                                        <label for="activity672a30f64cea11e6beb89e71128cae77" style="padding-left:25px;width:225px;" class="x-form-item-label">...Clone :</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity672a30f64cea11e6beb89e71128cae77" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7919">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity672a30f64cea11e6beb89e71128cae77" name="act672a30f64cea11e6beb89e71128cae77" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7925">
                                                                                                        <label for="activityfc31c7804cd711e6beb89e71128cae77" style="padding-left:25px;width:225px;" class="x-form-item-label">...Delete:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityfc31c7804cd711e6beb89e71128cae77" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7926">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityfc31c7804cd711e6beb89e71128cae77" name="actfc31c7804cd711e6beb89e71128cae77" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7932">
                                                                                                        <label for="activityfc31c8664cd711e6beb89e71128cae77" style="padding-left:25px;width:225px;" class="x-form-item-label">...Export:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityfc31c8664cd711e6beb89e71128cae77" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7933">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityfc31c8664cd711e6beb89e71128cae77" name="actfc31c8664cd711e6beb89e71128cae77" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                        <fieldset id="feature888795fc83ad4c90875768a661ea2384" class=" x-fieldset x-panel-collapsed" style="margin: 10px;">
                                                                                            <legend class="x-fieldset-header x-unselectable" id="wtf-gen5758">
                                                                                                <div class="x-tool x-tool-toggle" id="wtf-gen5762">&nbsp;</div><span class="x-fieldset-header-text" id="wtf-gen5766">Master Contract </span></legend>
                                                                                            <div class="x-fieldset-bwrap" id="wtf-gen5759">
                                                                                                <div class="x-fieldset-body" id="wtf-gen5760">
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7939">
                                                                                                        <label for="activity651212e602644c24bdb2082393d581e3" style="width:250px; font-weight:bold;" class="x-form-item-label">Create :</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity651212e602644c24bdb2082393d581e3" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7940">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity651212e602644c24bdb2082393d581e3" name="act651212e602644c24bdb2082393d581e3" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7946">
                                                                                                        <label for="activityeab4ba2ed43a4e51ab3634c266156744" style="width:250px; font-weight:bold;" class="x-form-item-label">View :</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityeab4ba2ed43a4e51ab3634c266156744" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7947">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityeab4ba2ed43a4e51ab3634c266156744" name="acteab4ba2ed43a4e51ab3634c266156744" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7953">
                                                                                                        <label for="activityd0a7a1fe1a54412795f5a55fd2df8aec" style="padding-left:25px;width:225px;" class="x-form-item-label">...Modify :</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityd0a7a1fe1a54412795f5a55fd2df8aec" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7954">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityd0a7a1fe1a54412795f5a55fd2df8aec" name="actd0a7a1fe1a54412795f5a55fd2df8aec" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7960">
                                                                                                        <label for="activitybf0cd29c9cbe41d3bd5e9bf694d9ba74" style="padding-left:25px;width:225px;" class="x-form-item-label">...Delete:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activitybf0cd29c9cbe41d3bd5e9bf694d9ba74" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7961">
                                                                                                                <input type="checkbox" autocomplete="off" id="activitybf0cd29c9cbe41d3bd5e9bf694d9ba74" name="actbf0cd29c9cbe41d3bd5e9bf694d9ba74" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7967">
                                                                                                        <label for="activity6e9f854ae3944d2db7956916d6e2ec5d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Export:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity6e9f854ae3944d2db7956916d6e2ec5d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7968">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity6e9f854ae3944d2db7956916d6e2ec5d" name="act6e9f854ae3944d2db7956916d6e2ec5d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                        <fieldset id="feature233cc888aa3011e6ab4c14dda9792840" class=" x-fieldset x-panel-collapsed" style="margin: 10px;">
                                                                                            <legend class="x-fieldset-header x-unselectable" id="wtf-gen5767">
                                                                                                <div class="x-tool x-tool-toggle" id="wtf-gen5771">&nbsp;</div><span class="x-fieldset-header-text" id="wtf-gen5775">Dishonoured Cheque </span></legend>
                                                                                            <div class="x-fieldset-bwrap" id="wtf-gen5768">
                                                                                                <div class="x-fieldset-body" id="wtf-gen5769">
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7974">
                                                                                                        <label for="activityd259559caa3111e6ab4c14dda9792840" style="width:250px; font-weight:bold;" class="x-form-item-label">View:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityd259559caa3111e6ab4c14dda9792840" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7975">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityd259559caa3111e6ab4c14dda9792840" name="actd259559caa3111e6ab4c14dda9792840" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7981">
                                                                                                        <label for="activity51d2fc24aa3211e6ab4c14dda9792840" style="padding-left:25px;width:225px;" class="x-form-item-label">...Mark/Revert Dishonoured Cheque:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity51d2fc24aa3211e6ab4c14dda9792840" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7982">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity51d2fc24aa3211e6ab4c14dda9792840" name="act51d2fc24aa3211e6ab4c14dda9792840" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                        <fieldset id="featured577b5b0412c11e7897014dda9792823" class=" x-fieldset x-panel-collapsed" style="margin: 10px;">
                                                                                            <legend class="x-fieldset-header x-unselectable" id="wtf-gen5776">
                                                                                                <div class="x-tool x-tool-toggle" id="wtf-gen5780">&nbsp;</div><span class="x-fieldset-header-text" id="wtf-gen5784">Custom Field/Dimension</span></legend>
                                                                                            <div class="x-fieldset-bwrap" id="wtf-gen5777">
                                                                                                <div class="x-fieldset-body" id="wtf-gen5778">
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7988">
                                                                                                        <label for="activitybc119018412d11e7897014dda9792823" style="width:250px; font-weight:bold;" class="x-form-item-label">Master Item Menu:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activitybc119018412d11e7897014dda9792823" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7989">
                                                                                                                <input type="checkbox" autocomplete="off" id="activitybc119018412d11e7897014dda9792823" name="actbc119018412d11e7897014dda9792823" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen7995">
                                                                                                        <label for="activityc7fcec88412d11e7897014dda9792823" style="padding-left:25px;width:225px;" class="x-form-item-label">...Add Master Item:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityc7fcec88412d11e7897014dda9792823" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen7996">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityc7fcec88412d11e7897014dda9792823" name="actc7fcec88412d11e7897014dda9792823" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                        <fieldset id="featured7c84854c3c911e8822d4ccc6a2d6a4d" class=" x-fieldset x-panel-collapsed" style="margin: 10px;">
                                                                                            <legend class="x-fieldset-header x-unselectable" id="wtf-gen5785">
                                                                                                <div class="x-tool x-tool-toggle" id="wtf-gen5789">&nbsp;</div><span class="x-fieldset-header-text" id="wtf-gen5793">Export Log</span></legend>
                                                                                            <div class="x-fieldset-bwrap" id="wtf-gen5786">
                                                                                                <div class="x-fieldset-body" id="wtf-gen5787">
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8002">
                                                                                                        <label for="activityf4efae27c3c911e8822d4ccc6a2d6a4d" style="width:250px; font-weight:bold;" class="x-form-item-label">View :</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityf4efae27c3c911e8822d4ccc6a2d6a4d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8003">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityf4efae27c3c911e8822d4ccc6a2d6a4d" name="actf4efae27c3c911e8822d4ccc6a2d6a4d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div id="AP-col1" class="x-panel x-column x-panel-noborder x-form-label-left" style="width: 322px;">
                                                                                <div class="x-panel-bwrap" id="wtf-gen933">
                                                                                    <div class="x-panel-body x-panel-body-noheader x-panel-body-noborder" id="wtf-gen934" style="width: 322px;">
                                                                                        <fieldset id="featureff80808122f3cb640122f44c528e0011" class=" x-fieldset x-panel-collapsed" style="margin: 10px;">
                                                                                            <legend class="x-fieldset-header x-unselectable" id="wtf-gen5794">
                                                                                                <div class="x-tool x-tool-toggle" id="wtf-gen5798">&nbsp;</div><span class="x-fieldset-header-text" id="wtf-gen5802">Account Management and Journal Entry</span></legend>
                                                                                            <div class="x-fieldset-bwrap" id="wtf-gen5795">
                                                                                                <div class="x-fieldset-body" id="wtf-gen5796">
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8004">
                                                                                                        <label for="activityff80808122f3cb640122f45dd370003b" style="width:250px; font-weight:bold;" class="x-form-item-label">Create COA:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f3cb640122f45dd370003b" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8005">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f3cb640122f45dd370003b" name="actff80808122f3cb640122f45dd370003b" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8011">
                                                                                                        <label for="activityff80808122f3cb640122f457015b0026" style="width:250px; font-weight:bold;" class="x-form-item-label">View COA:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f3cb640122f457015b0026" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8012">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f3cb640122f457015b0026" name="actff80808122f3cb640122f457015b0026" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8018">
                                                                                                        <label for="activityff80808122f3cb640122f4606f480042" style="padding-left:25px;width:225px;" class="x-form-item-label">...Modify:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f3cb640122f4606f480042" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8019">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f3cb640122f4606f480042" name="actff80808122f3cb640122f4606f480042" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8025">
                                                                                                        <label for="activityff80808122f3cb640122f460fa310043" style="padding-left:25px;width:225px;" class="x-form-item-label">...Delete:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f3cb640122f460fa310043" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8026">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f3cb640122f460fa310043" name="actff80808122f3cb640122f460fa310043" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8032">
                                                                                                        <label for="activityff80808122f9dba90122fa4888cf00238" style="padding-left:25px;width:225px;" class="x-form-item-label">...Export Data:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba90122fa4888cf00238" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8033">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba90122fa4888cf00238" name="actff80808122f9dba90122fa4888cf00238" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8039">
                                                                                                        <label for="activityff80808122f9dba90122fa4888cf00239" style="padding-left:25px;width:225px;" class="x-form-item-label">...Import Data:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba90122fa4888cf00239" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8040">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba90122fa4888cf00239" name="actff80808122f9dba90122fa4888cf00239" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8046">
                                                                                                        <label for="activityff80808122f9dba90122fa4888cf00240" style="padding-left:25px;width:225px;" class="x-form-item-label">...Print:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba90122fa4888cf00240" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8047">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba90122fa4888cf00240" name="actff80808122f9dba90122fa4888cf00240" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8053">
                                                                                                        <label for="activityff80808122f3cb640122f45f3a73003f" style="width:250px; font-weight:bold;" class="x-form-item-label">Create Journal Entry:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f3cb640122f45f3a73003f" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8054">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f3cb640122f45f3a73003f" name="actff80808122f3cb640122f45f3a73003f" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8060">
                                                                                                        <label for="activityff80808122f9dba90122fa4888cf00276" style="width:250px; font-weight:bold;" class="x-form-item-label">View Journal Entry Report:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba90122fa4888cf00276" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8061">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba90122fa4888cf00276" name="actff80808122f9dba90122fa4888cf00276" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8067">
                                                                                                        <label for="activityff80808122f9dba90122fa4888cf00202" style="padding-left:25px;width:225px;" class="x-form-item-label">...Export Data:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba90122fa4888cf00202" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8068">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba90122fa4888cf00202" name="actff80808122f9dba90122fa4888cf00202" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8074">
                                                                                                        <label for="activityff80808122f9dba90122fa4888cf00203" style="padding-left:25px;width:225px;" class="x-form-item-label">...Print:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba90122fa4888cf00203" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8075">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba90122fa4888cf00203" name="actff80808122f9dba90122fa4888cf00203" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8081">
                                                                                                        <label for="activityff80808122f9dba90122fa4888cf00204" style="padding-left:25px;width:225px;" class="x-form-item-label">...Delete:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba90122fa4888cf00204" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8082">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba90122fa4888cf00204" name="actff80808122f9dba90122fa4888cf00204" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8088">
                                                                                                        <label for="activity47214416425511e59e71c03fd5632a48" style="padding-left:25px;width:225px;" class="x-form-item-label">...Copy:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity47214416425511e59e71c03fd5632a48" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8089">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity47214416425511e59e71c03fd5632a48" name="act47214416425511e59e71c03fd5632a48" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8095">
                                                                                                        <label for="activity67f013889bb711e4b5cbeca8ewrwfp8e9d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Edit:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity67f013889bb711e4b5cbeca8ewrwfp8e9d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8096">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity67f013889bb711e4b5cbeca8ewrwfp8e9d" name="act67f013889bb711e4b5cbeca8ewrwfp8e9d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8102">
                                                                                                        <label for="activity7b45ddbe9bb711e4b5cbeca86bpsdws8e9d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Import:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity7b45ddbe9bb711e4b5cbeca86bpsdws8e9d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8103">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity7b45ddbe9bb711e4b5cbeca86bpsdws8e9d" name="act7b45ddbe9bb711e4b5cbeca86bpsdws8e9d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                        <fieldset id="featureff80808122f3cb640122f44c10f80010" class=" x-fieldset x-panel-collapsed" style="margin: 10px;">
                                                                                            <legend class="x-fieldset-header x-unselectable" id="wtf-gen5803">
                                                                                                <div class="x-tool x-tool-toggle" id="wtf-gen5807">&nbsp;</div><span class="x-fieldset-header-text" id="wtf-gen5811">Vendor</span></legend>
                                                                                            <div class="x-fieldset-bwrap" id="wtf-gen5804">
                                                                                                <div class="x-fieldset-body" id="wtf-gen5805">
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8109">
                                                                                                        <label for="activityff80808122f3cb640122f45d72e8003a" style="width:250px; font-weight:bold;" class="x-form-item-label">Create:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f3cb640122f45d72e8003a" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8110">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f3cb640122f45d72e8003a" name="actff80808122f3cb640122f45d72e8003a" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8116">
                                                                                                        <label for="activityff80808122f3cb640122f456b7530025" style="width:250px; font-weight:bold;" class="x-form-item-label">View :</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f3cb640122f456b7530025" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8117">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f3cb640122f456b7530025" name="actff80808122f3cb640122f456b7530025" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8123">
                                                                                                        <label for="activityff80808122f3cb640122f4616fca0044" style="padding-left:25px;width:225px;" class="x-form-item-label">...Modify:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f3cb640122f4616fca0044" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8124">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f3cb640122f4616fca0044" name="actff80808122f3cb640122f4616fca0044" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8130">
                                                                                                        <label for="activityff80808122f9dba90122fa4888cf00218" style="padding-left:25px;width:225px;" class="x-form-item-label">...Delete:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba90122fa4888cf00218" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8131">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba90122fa4888cf00218" name="actff80808122f9dba90122fa4888cf00218" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8137">
                                                                                                        <label for="activityff80808122f9dba90122fa4888cf00213" style="padding-left:25px;width:225px;" class="x-form-item-label">...Chart:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba90122fa4888cf00213" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8138">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba90122fa4888cf00213" name="actff80808122f9dba90122fa4888cf00213" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8144">
                                                                                                        <label for="activityff80808122f9dba90122fa4888cf00214" style="padding-left:25px;width:225px;" class="x-form-item-label">...Import Data:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba90122fa4888cf00214" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8145">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba90122fa4888cf00214" name="actff80808122f9dba90122fa4888cf00214" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8151">
                                                                                                        <label for="activityff80808122f9dba90122fa4888cf00215" style="padding-left:25px;width:225px;" class="x-form-item-label">...Export Data:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba90122fa4888cf00215" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8152">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba90122fa4888cf00215" name="actff80808122f9dba90122fa4888cf00215" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8158">
                                                                                                        <label for="activityff80808122f9dba90122fa4888cf00216" style="padding-left:25px;width:225px;" class="x-form-item-label">...Print:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba90122fa4888cf00216" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8159">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba90122fa4888cf00216" name="actff80808122f9dba90122fa4888cf00216" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8165">
                                                                                                        <label for="activity4e6f1f3d6cb811e5991d14dda97926b6" style="padding-left:25px;width:225px;" class="x-form-item-label">...View All:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity4e6f1f3d6cb811e5991d14dda97926b6" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8166">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity4e6f1f3d6cb811e5991d14dda97926b6" name="act4e6f1f3d6cb811e5991d14dda97926b6" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8172">
                                                                                                        <label for="activity1130570eb25411e7abc4cec278b6b50a" style="padding-left:25px;width:225px;" class="x-form-item-label">...Opening Balance:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity1130570eb25411e7abc4cec278b6b50a" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8173">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity1130570eb25411e7abc4cec278b6b50a" name="act1130570eb25411e7abc4cec278b6b50a" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8179">
                                                                                                        <label for="activityf1635309377e4c87a3815efd932ca350" style="padding-left:25px;width:225px;" class="x-form-item-label">...View IBG Details:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityf1635309377e4c87a3815efd932ca350" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8180">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityf1635309377e4c87a3815efd932ca350" name="actf1635309377e4c87a3815efd932ca350" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8186">
                                                                                                        <label for="activityf35b8d141e454123ae50c9202572719b" style="padding-left:25px;width:225px;" class="x-form-item-label">...Edit IBG Details:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityf35b8d141e454123ae50c9202572719b" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8187">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityf35b8d141e454123ae50c9202572719b" name="actf35b8d141e454123ae50c9202572719b" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8193">
                                                                                                        <label for="activity0742188a67cc11e89f1f4ccc6a2d6a4d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Copy:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity0742188a67cc11e89f1f4ccc6a2d6a4d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8194">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity0742188a67cc11e89f1f4ccc6a2d6a4d" name="act0742188a67cc11e89f1f4ccc6a2d6a4d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                        <fieldset id="featureff80808122f3cb640122f4521014001a" class=" x-fieldset x-panel-collapsed" style="margin: 10px;">
                                                                                            <legend class="x-fieldset-header x-unselectable" id="wtf-gen5812">
                                                                                                <div class="x-tool x-tool-toggle " id="wtf-gen5816">&nbsp;</div><span class="x-fieldset-header-text" id="wtf-gen5820">Financial Statements</span></legend>
                                                                                            <div class="x-fieldset-bwrap" id="wtf-gen5813">
                                                                                                <div class="x-fieldset-body" id="wtf-gen5814" style="height: auto;">
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8200">
                                                                                                        <label for="activityff80808122f3cb640122f458b0b1002c" style="width:250px; font-weight:bold;" class="x-form-item-label">View Trial Balance:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f3cb640122f458b0b1002c" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8201">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f3cb640122f458b0b1002c" name="actff80808122f3cb640122f458b0b1002c" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8207">
                                                                                                        <label for="activityff80808122f9dba90122fa4888cf00242" style="padding-left:25px;width:225px;" class="x-form-item-label">...Export Data:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba90122fa4888cf00242" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8208">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba90122fa4888cf00242" name="actff80808122f9dba90122fa4888cf00242" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8214">
                                                                                                        <label for="activityff80808122f9dba90122fa4888cf00243" style="padding-left:25px;width:225px;" class="x-form-item-label">...Print:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba90122fa4888cf00243" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8215">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba90122fa4888cf00243" name="actff80808122f9dba90122fa4888cf00243" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item  x-hide-label" tabindex="-1" id="wtf-gen8221">
                                                                                                        <label for="activityff80808122f3cb640122f4585b50002b" style="width:250px; font-weight:bold;" class="x-form-item-label">View Ledger:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f3cb640122f4585b50002b" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8222">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f3cb640122f4585b50002b" name="actff80808122f3cb640122f4585b50002b" class=" x-form-checkbox x-form-field x-hide-display">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item  x-hide-label" tabindex="-1" id="wtf-gen8228">
                                                                                                        <label for="activityff80808122f9dba90122fa4888cf00256" style="padding-left:25px;width:225px;" class="x-form-item-label">...Export Data:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba90122fa4888cf00256" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8229">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba90122fa4888cf00256" name="actff80808122f9dba90122fa4888cf00256" class=" x-form-checkbox x-form-field x-hide-display">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item  x-hide-label" tabindex="-1" id="wtf-gen8235">
                                                                                                        <label for="activityff80808122f9dba90122fa4888cf00257" style="padding-left:25px;width:225px;" class="x-form-item-label">...Print:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba90122fa4888cf00257" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8236">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba90122fa4888cf00257" name="actff80808122f9dba90122fa4888cf00257" class=" x-form-checkbox x-form-field x-hide-display">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8242">
                                                                                                        <label for="activityff80808122f9dba90122fa4888cf00244" style="width:250px; font-weight:bold;" class="x-form-item-label">View Trading and P&amp;L:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba90122fa4888cf00244" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8243">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba90122fa4888cf00244" name="actff80808122f9dba90122fa4888cf00244" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8249">
                                                                                                        <label for="activityff80808122f9dba90122fa4888cf00245" style="padding-left:25px;width:225px;" class="x-form-item-label">...Export Data:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba90122fa4888cf00245" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8250">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba90122fa4888cf00245" name="actff80808122f9dba90122fa4888cf00245" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8256">
                                                                                                        <label for="activityff80808122f9dba90122fa4888cf00246" style="padding-left:25px;width:225px;" class="x-form-item-label">...Print:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba90122fa4888cf00246" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8257">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba90122fa4888cf00246" name="actff80808122f9dba90122fa4888cf00246" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8263">
                                                                                                        <label for="activityff80808122f3cb640122f459a6eb002f" style="width:250px; font-weight:bold;" class="x-form-item-label">View Balance Sheet:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f3cb640122f459a6eb002f" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8264">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f3cb640122f459a6eb002f" name="actff80808122f3cb640122f459a6eb002f" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8270">
                                                                                                        <label for="activityff80808122f9dba90122fa4888cf00248" style="padding-left:25px;width:225px;" class="x-form-item-label">...Export Data:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba90122fa4888cf00248" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8271">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba90122fa4888cf00248" name="actff80808122f9dba90122fa4888cf00248" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8277">
                                                                                                        <label for="activityff80808122f9dba90122fa4888cf00249" style="padding-left:25px;width:225px;" class="x-form-item-label">...Print:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba90122fa4888cf00249" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8278">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba90122fa4888cf00249" name="actff80808122f9dba90122fa4888cf00249" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8284">
                                                                                                        <label for="activityff80808122f3cb640122f45a23a10030" style="width:250px; font-weight:bold;" class="x-form-item-label">View Cash Book:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f3cb640122f45a23a10030" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8285">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f3cb640122f45a23a10030" name="actff80808122f3cb640122f45a23a10030" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8291">
                                                                                                        <label for="activityff80808122f9dba90122fa4888cf00205" style="padding-left:25px;width:225px;" class="x-form-item-label">...Export Data:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba90122fa4888cf00205" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8292">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba90122fa4888cf00205" name="actff80808122f9dba90122fa4888cf00205" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8298">
                                                                                                        <label for="activityff80808122f9dba90122fa4888cf00206" style="padding-left:25px;width:225px;" class="x-form-item-label">...Print:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba90122fa4888cf00206" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8299">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba90122fa4888cf00206" name="actff80808122f9dba90122fa4888cf00206" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8305">
                                                                                                        <label for="activityff80808122f3cb640122f45a64c10031" style="width:250px; font-weight:bold;" class="x-form-item-label">View Bank Book:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f3cb640122f45a64c10031" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8306">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f3cb640122f45a64c10031" name="actff80808122f3cb640122f45a64c10031" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8312">
                                                                                                        <label for="activityff80808122f9dba90122fa4888cf00207" style="padding-left:25px;width:225px;" class="x-form-item-label">...Export Data:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba90122fa4888cf00207" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8313">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba90122fa4888cf00207" name="actff80808122f9dba90122fa4888cf00207" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8319">
                                                                                                        <label for="activityff80808122f9dba90122fa4888cf00208" style="padding-left:25px;width:225px;" class="x-form-item-label">...Print:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba90122fa4888cf00208" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8320">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba90122fa4888cf00208" name="actff80808122f9dba90122fa4888cf00208" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                        <fieldset id="featureff80808122f9dba90122fa4888cf0054" class=" x-fieldset x-panel-collapsed" style="margin: 10px;">
                                                                                            <legend class="x-fieldset-header x-unselectable" id="wtf-gen5821">
                                                                                                <div class="x-tool x-tool-toggle " id="wtf-gen5825">&nbsp;</div><span class="x-fieldset-header-text" id="wtf-gen5829">Purchase Management</span></legend>
                                                                                            <div class="x-fieldset-bwrap" id="wtf-gen5822">
                                                                                                <div class="x-fieldset-body" id="wtf-gen5823">
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8326">
                                                                                                        <label for="activity84499f72a2ce11e4adaceca86bff8e7d" style="width:250px; font-weight:bold;" class="x-form-item-label">Create Vendor Quotation:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity84499f72a2ce11e4adaceca86bff8e7d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8327">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity84499f72a2ce11e4adaceca86bff8e7d" name="act84499f72a2ce11e4adaceca86bff8e7d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8333">
                                                                                                        <label for="activity906b2334a2ce11e4adaceca86bff8e7d" style="width:250px; font-weight:bold;" class="x-form-item-label">View Vendor Quotation:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity906b2334a2ce11e4adaceca86bff8e7d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8334">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity906b2334a2ce11e4adaceca86bff8e7d" name="act906b2334a2ce11e4adaceca86bff8e7d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8340">
                                                                                                        <label for="activitya4495344a2ce11e4adaceca86bff8e7d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Edit:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activitya4495344a2ce11e4adaceca86bff8e7d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8341">
                                                                                                                <input type="checkbox" autocomplete="off" id="activitya4495344a2ce11e4adaceca86bff8e7d" name="acta4495344a2ce11e4adaceca86bff8e7d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8347">
                                                                                                        <label for="activityb0130314a2ce11e4adaceca86bff8e7d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Delete:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityb0130314a2ce11e4adaceca86bff8e7d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8348">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityb0130314a2ce11e4adaceca86bff8e7d" name="actb0130314a2ce11e4adaceca86bff8e7d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8354">
                                                                                                        <label for="activitybc732742a2ce11e4adaceca86bff8e7d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Export:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activitybc732742a2ce11e4adaceca86bff8e7d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8355">
                                                                                                                <input type="checkbox" autocomplete="off" id="activitybc732742a2ce11e4adaceca86bff8e7d" name="actbc732742a2ce11e4adaceca86bff8e7d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8361">
                                                                                                        <label for="activityc891c0d8a2ce11e4adaceca86bff8e7d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Print:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityc891c0d8a2ce11e4adaceca86bff8e7d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8362">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityc891c0d8a2ce11e4adaceca86bff8e7d" name="actc891c0d8a2ce11e4adaceca86bff8e7d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8368">
                                                                                                        <label for="activity3846576f47ad41c7a7b5c1e8d7f7et93" style="padding-left:25px;width:225px;" class="x-form-item-label">...Copy:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity3846576f47ad41c7a7b5c1e8d7f7et93" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8369">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity3846576f47ad41c7a7b5c1e8d7f7et93" name="act3846576f47ad41c7a7b5c1e8d7f7et93" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8375">
                                                                                                        <label for="activity2ecb0fee62b911e5b942eca86bfcd415" style="padding-left:25px;width:225px;" class="x-form-item-label">...Unlink:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity2ecb0fee62b911e5b942eca86bfcd415" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8376">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity2ecb0fee62b911e5b942eca86bfcd415" name="act2ecb0fee62b911e5b942eca86bfcd415" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8382">
                                                                                                        <label for="activity8122f9dba90122fa4888cf0069" style="width:250px; font-weight:bold;" class="x-form-item-label">Create Purchase Order:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity8122f9dba90122fa4888cf0069" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8383">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity8122f9dba90122fa4888cf0069" name="act8122f9dba90122fa4888cf0069" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8389">
                                                                                                        <label for="activityff80808122f9dba90122fa4888cf00106" style="width:250px; font-weight:bold;" class="x-form-item-label">View Purchase Order Report:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba90122fa4888cf00106" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8390">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba90122fa4888cf00106" name="actff80808122f9dba90122fa4888cf00106" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8396">
                                                                                                        <label for="activityff80808122f9dba90122fa4888cf0070" style="padding-left:25px;width:225px;" class="x-form-item-label">...Edit:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba90122fa4888cf0070" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8397">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba90122fa4888cf0070" name="actff80808122f9dba90122fa4888cf0070" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8403">
                                                                                                        <label for="activityff80808122f9dba90122fa4888cf0071" style="padding-left:25px;width:225px;" class="x-form-item-label">...Delete:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba90122fa4888cf0071" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8404">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba90122fa4888cf0071" name="actff80808122f9dba90122fa4888cf0071" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8410">
                                                                                                        <label for="activityff80808122f9dba90122fa4888cf00104" style="padding-left:25px;width:225px;" class="x-form-item-label">...Export Data:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba90122fa4888cf00104" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8411">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba90122fa4888cf00104" name="actff80808122f9dba90122fa4888cf00104" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8417">
                                                                                                        <label for="activityff80808122f9dba90122fa4888cf00200" style="padding-left:25px;width:225px;" class="x-form-item-label">...Print:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba90122fa4888cf00200" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8418">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba90122fa4888cf00200" name="actff80808122f9dba90122fa4888cf00200" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8424">
                                                                                                        <label for="activity3846576f47ad41c7a7b5c1e8d7f7et95" style="padding-left:25px;width:225px;" class="x-form-item-label">...Copy:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity3846576f47ad41c7a7b5c1e8d7f7et95" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8425">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity3846576f47ad41c7a7b5c1e8d7f7et95" name="act3846576f47ad41c7a7b5c1e8d7f7et95" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8431">
                                                                                                        <label for="activity6ec56a94635511e5a11beca86bfcd415" style="padding-left:25px;width:225px;" class="x-form-item-label">...Unlink:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity6ec56a94635511e5a11beca86bfcd415" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8432">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity6ec56a94635511e5a11beca86bfcd415" name="act6ec56a94635511e5a11beca86bfcd415" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8438">
                                                                                                        <label for="activityd88fd4fea2cc11e4adaceca86bff8e7d" style="width:250px; font-weight:bold;" class="x-form-item-label">Import Purchase Invoices:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityd88fd4fea2cc11e4adaceca86bff8e7d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8439">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityd88fd4fea2cc11e4adaceca86bff8e7d" name="actd88fd4fea2cc11e4adaceca86bff8e7d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8445">
                                                                                                        <label for="activityff80808122f9dba90122fa4888cf00267" style="width:250px; font-weight:bold;" class="x-form-item-label">Create Cash Purchase:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba90122fa4888cf00267" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8446">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba90122fa4888cf00267" name="actff80808122f9dba90122fa4888cf00267" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8452">
                                                                                                        <label for="activityff80808122f9dba90122fa4888cf0075" style="width:250px; font-weight:bold;" class="x-form-item-label">Create Purchase Invoice:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba90122fa4888cf0075" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8453">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba90122fa4888cf0075" name="actff80808122f9dba90122fa4888cf0075" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8459">
                                                                                                        <label for="activityff80808122f9dba90122fa4888cf00101" style="width:250px; font-weight:bold;" class="x-form-item-label">View Purchase Invoice and Cash Purchase Report:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba90122fa4888cf00101" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8460">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba90122fa4888cf00101" name="actff80808122f9dba90122fa4888cf00101" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8466">
                                                                                                        <label for="activityff80808122f9dba90122fa4888cf0076" style="padding-left:25px;width:225px;" class="x-form-item-label">...Edit:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba90122fa4888cf0076" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8467">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba90122fa4888cf0076" name="actff80808122f9dba90122fa4888cf0076" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8473">
                                                                                                        <label for="activityff80808122f9dba90122fa4888cf0078" style="padding-left:25px;width:225px;" class="x-form-item-label">...Copy:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba90122fa4888cf0078" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8474">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba90122fa4888cf0078" name="actff80808122f9dba90122fa4888cf0078" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8480">
                                                                                                        <label for="activityff80808122f9dba90122fa4888cf0077" style="padding-left:25px;width:225px;" class="x-form-item-label">...Delete:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba90122fa4888cf0077" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8481">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba90122fa4888cf0077" name="actff80808122f9dba90122fa4888cf0077" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8487">
                                                                                                        <label for="activityff80808122f9dba90122fa4888cf0092" style="padding-left:25px;width:225px;" class="x-form-item-label">...Email:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba90122fa4888cf0092" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8488">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba90122fa4888cf0092" name="actff80808122f9dba90122fa4888cf0092" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8494">
                                                                                                        <label for="activityff80808122f9dba90122fa4888cf0099" style="padding-left:25px;width:225px;" class="x-form-item-label">...Export Data:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba90122fa4888cf0099" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8495">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba90122fa4888cf0099" name="actff80808122f9dba90122fa4888cf0099" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8501">
                                                                                                        <label for="activityff80808122f9dba90122fa4888cf00100" style="padding-left:25px;width:225px;" class="x-form-item-label">...Print:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba90122fa4888cf00100" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8502">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba90122fa4888cf00100" name="actff80808122f9dba90122fa4888cf00100" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8508">
                                                                                                        <label for="activity67f0138tebbwe4b5cbeca8ewrwfp8e9d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Recurring Vendor Invoice:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity67f0138tebbwe4b5cbeca8ewrwfp8e9d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8509">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity67f0138tebbwe4b5cbeca8ewrwfp8e9d" name="act67f0138tebbwe4b5cbeca8ewrwfp8e9d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8515">
                                                                                                        <label for="activity2972908e629c11e5b942eca86bfcd415" style="padding-left:25px;width:225px;" class="x-form-item-label">...Unlink:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity2972908e629c11e5b942eca86bfcd415" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8516">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity2972908e629c11e5b942eca86bfcd415" name="act2972908e629c11e5b942eca86bfcd415" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                        <fieldset id="featureff80808122f9dba90122fa47e6e0002f" class=" x-fieldset x-panel-collapsed" style="margin: 10px;">
                                                                                            <legend class="x-fieldset-header x-unselectable" id="wtf-gen5830">
                                                                                                <div class="x-tool x-tool-toggle " id="wtf-gen5834">&nbsp;</div><span class="x-fieldset-header-text" id="wtf-gen5838">Account Type</span></legend>
                                                                                            <div class="x-fieldset-bwrap" id="wtf-gen5831">
                                                                                                <div class="x-fieldset-body" id="wtf-gen5832">
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8522">
                                                                                                        <label for="activityff80808122f9dba90122fa4b37570034" style="width:250px; font-weight:bold;" class="x-form-item-label">Create:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba90122fa4b37570034" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8523">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba90122fa4b37570034" name="actff80808122f9dba90122fa4b37570034" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8529">
                                                                                                        <label for="activityff80808122f9dba90122fa4b77be0035" style="padding-left:25px;width:225px;" class="x-form-item-label">...View :</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba90122fa4b77be0035" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8530">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba90122fa4b77be0035" name="actff80808122f9dba90122fa4b77be0035" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                        <fieldset id="featureff80808122f3cb640122f44a6cca000c" class=" x-fieldset x-panel-collapsed" style="margin: 10px;">
                                                                                            <legend class="x-fieldset-header x-unselectable" id="wtf-gen5839">
                                                                                                <div class="x-tool x-tool-toggle" id="wtf-gen5843">&nbsp;</div><span class="x-fieldset-header-text" id="wtf-gen5847">Payment Method</span></legend>
                                                                                            <div class="x-fieldset-bwrap" id="wtf-gen5840">
                                                                                                <div class="x-fieldset-body" id="wtf-gen5841">
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8536">
                                                                                                        <label for="activityff80808122f3cb640122f45479e80021" style="width:250px; font-weight:bold;" class="x-form-item-label">View :</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f3cb640122f45479e80021" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8537">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f3cb640122f45479e80021" name="actff80808122f3cb640122f45479e80021" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8543">
                                                                                                        <label for="activityff80808122f3cb640122f462a6ad0046" style="padding-left:25px;width:225px;" class="x-form-item-label">...Modify:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f3cb640122f462a6ad0046" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8544">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f3cb640122f462a6ad0046" name="actff80808122f3cb640122f462a6ad0046" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8550">
                                                                                                        <label for="activityff80808122f9dba902012d9265080023" style="width:250px; font-weight:bold;" class="x-form-item-label">View Bank Type Account Balance:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba902012d9265080023" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8551">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba902012d9265080023" name="actff80808122f9dba902012d9265080023" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8557">
                                                                                                        <label for="activityff80808122f9dba902012d92d4b30024" style="width:250px; font-weight:bold;" class="x-form-item-label">View Cash Type Account Balance:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba902012d92d4b30024" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8558">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba902012d92d4b30024" name="actff80808122f9dba902012d92d4b30024" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                        <fieldset id="featureff80808122f9dba90122fa2bcbcf0021" class=" x-fieldset x-panel-collapsed" style="margin: 10px;">
                                                                                            <legend class="x-fieldset-header x-unselectable" id="wtf-gen5848">
                                                                                                <div class="x-tool x-tool-toggle" id="wtf-gen5852">&nbsp;</div><span class="x-fieldset-header-text" id="wtf-gen5856">User Administration</span></legend>
                                                                                            <div class="x-fieldset-bwrap" id="wtf-gen5849">
                                                                                                <div class="x-fieldset-body" id="wtf-gen5850">
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8564">
                                                                                                        <label for="activityff80808122f9dba90122fa2f45a50025" style="width:250px; font-weight:bold;" class="x-form-item-label">View :</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba90122fa2f45a50025" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8565">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba90122fa2f45a50025" name="actff80808122f9dba90122fa2f45a50025" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8571">
                                                                                                        <label for="activityff80808122f9dba90122fa34534e002b" style="width:250px; font-weight:bold;" class="x-form-item-label">Assign Permissions:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba90122fa34534e002b" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8572">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba90122fa34534e002b" name="actff80808122f9dba90122fa34534e002b" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                        <fieldset id="featureff80808122f3cb640122f452dbc9001d" class=" x-fieldset x-panel-collapsed" style="margin: 10px;">
                                                                                            <legend class="x-fieldset-header x-unselectable" id="wtf-gen5857">
                                                                                                <div class="x-tool x-tool-toggle" id="wtf-gen5861">&nbsp;</div><span class="x-fieldset-header-text" id="wtf-gen5865">Audit Trail</span></legend>
                                                                                            <div class="x-fieldset-bwrap" id="wtf-gen5858">
                                                                                                <div class="x-fieldset-body" id="wtf-gen5859">
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8578">
                                                                                                        <label for="activityff80808122f3cb640122f45a9c360032" style="width:250px; font-weight:bold;" class="x-form-item-label">View :</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f3cb640122f45a9c360032" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8579">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f3cb640122f45a9c360032" name="actff80808122f3cb640122f45a9c360032" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                        <fieldset id="featureff80808122f9dba90122fa4888cf0031" class=" x-fieldset x-panel-collapsed" style="margin: 10px;">
                                                                                            <legend class="x-fieldset-header x-unselectable" id="wtf-gen5866">
                                                                                                <div class="x-tool x-tool-toggle" id="wtf-gen5870">&nbsp;</div><span class="x-fieldset-header-text" id="wtf-gen5874">Unit of Measure</span></legend>
                                                                                            <div class="x-fieldset-bwrap" id="wtf-gen5867">
                                                                                                <div class="x-fieldset-body" id="wtf-gen5868">
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8585">
                                                                                                        <label for="activityff80808122f9dba90122fa4d305d003a" style="width:250px; font-weight:bold;" class="x-form-item-label">View :</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba90122fa4d305d003a" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8586">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba90122fa4d305d003a" name="actff80808122f9dba90122fa4d305d003a" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8592">
                                                                                                        <label for="activityff80808122f9dba90122fa4888cf00264" style="padding-left:25px;width:225px;" class="x-form-item-label">...Modify:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba90122fa4888cf00264" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8593">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba90122fa4888cf00264" name="actff80808122f9dba90122fa4888cf00264" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8599">
                                                                                                        <label for="activity77f013889bb711u4b5dbeda8765fu8e9d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Import:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity77f013889bb711u4b5dbeda8765fu8e9d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8600">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity77f013889bb711u4b5dbeda8765fu8e9d" name="act77f013889bb711u4b5dbeda8765fu8e9d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                        <fieldset id="featureff80808122f9dba90122fa4888cf0067" class=" x-fieldset x-panel-collapsed" style="margin: 10px;">
                                                                                            <legend class="x-fieldset-header x-unselectable" id="wtf-gen5875">
                                                                                                <div class="x-tool x-tool-toggle" id="wtf-gen5879">&nbsp;</div><span class="x-fieldset-header-text" id="wtf-gen5883">Approvals</span></legend>
                                                                                            <div class="x-fieldset-bwrap" id="wtf-gen5876">
                                                                                                <div class="x-fieldset-body" id="wtf-gen5877">
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8606">
                                                                                                        <label for="activityeb214daaa2cc11e4adaceca86bxf8e9d" style="width:250px; font-weight:bold;" class="x-form-item-label">View Approval Rule:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityeb214daaa2cc11e4adaceca86bxf8e9d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8607">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityeb214daaa2cc11e4adaceca86bxf8e9d" name="acteb214daaa2cc11e4adaceca86bxf8e9d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                        <fieldset id="feature4d5cb414b35411e3abe3001cc066e9f0" class=" x-fieldset x-panel-collapsed" style="margin: 10px;">
                                                                                            <legend class="x-fieldset-header x-unselectable" id="wtf-gen5884">
                                                                                                <div class="x-tool x-tool-toggle" id="wtf-gen5888">&nbsp;</div><span class="x-fieldset-header-text" id="wtf-gen5892">Goods Receipt </span></legend>
                                                                                            <div class="x-fieldset-bwrap" id="wtf-gen5885">
                                                                                                <div class="x-fieldset-body" id="wtf-gen5886">
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8613">
                                                                                                        <label for="activity9cf983c8b35711e3abe3001cc066e9f0" style="width:250px; font-weight:bold;" class="x-form-item-label">Create:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity9cf983c8b35711e3abe3001cc066e9f0" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8614">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity9cf983c8b35711e3abe3001cc066e9f0" name="act9cf983c8b35711e3abe3001cc066e9f0" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8620">
                                                                                                        <label for="activity408a4e1eb35811e3abe3001cc066e9f0" style="width:250px; font-weight:bold;" class="x-form-item-label">View:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity408a4e1eb35811e3abe3001cc066e9f0" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8621">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity408a4e1eb35811e3abe3001cc066e9f0" name="act408a4e1eb35811e3abe3001cc066e9f0" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8627">
                                                                                                        <label for="activity8d7e75d6b35a11e39a00001cc066e9f0" style="padding-left:25px;width:225px;" class="x-form-item-label">...Modify:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity8d7e75d6b35a11e39a00001cc066e9f0" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8628">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity8d7e75d6b35a11e39a00001cc066e9f0" name="act8d7e75d6b35a11e39a00001cc066e9f0" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8634">
                                                                                                        <label for="activityba29c95ab35a11e39a00001cc066e9f0" style="padding-left:25px;width:225px;" class="x-form-item-label">...Delete:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityba29c95ab35a11e39a00001cc066e9f0" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8635">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityba29c95ab35a11e39a00001cc066e9f0" name="actba29c95ab35a11e39a00001cc066e9f0" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8641">
                                                                                                        <label for="activityc64c2214b35a11e39a00001cc066e9f0" style="padding-left:25px;width:225px;" class="x-form-item-label">...Export:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityc64c2214b35a11e39a00001cc066e9f0" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8642">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityc64c2214b35a11e39a00001cc066e9f0" name="actc64c2214b35a11e39a00001cc066e9f0" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8648">
                                                                                                        <label for="activityd62caafab35a11e39a00001cc066e9f0" style="padding-left:25px;width:225px;" class="x-form-item-label">...Print:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityd62caafab35a11e39a00001cc066e9f0" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8649">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityd62caafab35a11e39a00001cc066e9f0" name="actd62caafab35a11e39a00001cc066e9f0" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8655">
                                                                                                        <label for="activity3846576f47ad41c7a7b5c1e8d7f7ee93" style="padding-left:25px;width:225px;" class="x-form-item-label">...Copy:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity3846576f47ad41c7a7b5c1e8d7f7ee93" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8656">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity3846576f47ad41c7a7b5c1e8d7f7ee93" name="act3846576f47ad41c7a7b5c1e8d7f7ee93" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8662">
                                                                                                        <label for="activity2b13fc82637f11e5a11beca86bfcd415" style="padding-left:25px;width:225px;" class="x-form-item-label">...Unlink:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity2b13fc82637f11e5a11beca86bfcd415" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8663">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity2b13fc82637f11e5a11beca86bfcd415" name="act2b13fc82637f11e5a11beca86bfcd415" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                        <fieldset id="feature1b1570e29bb411e4b5cbeca86bff8e7d" class=" x-fieldset x-panel-collapsed" style="margin: 10px;">
                                                                                            <legend class="x-fieldset-header x-unselectable" id="wtf-gen5893">
                                                                                                <div class="x-tool x-tool-toggle" id="wtf-gen5897">&nbsp;</div><span class="x-fieldset-header-text" id="wtf-gen5901">Asset</span></legend>
                                                                                            <div class="x-fieldset-bwrap" id="wtf-gen5894">
                                                                                                <div class="x-fieldset-body" id="wtf-gen5895">
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8669">
                                                                                                        <label for="activitye8923f209bb711e48d2eeca86bff8e7d" style="width:250px; font-weight:bold;" class="x-form-item-label">View Asset Groups:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activitye8923f209bb711e48d2eeca86bff8e7d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8670">
                                                                                                                <input type="checkbox" autocomplete="off" id="activitye8923f209bb711e48d2eeca86bff8e7d" name="acte8923f209bb711e48d2eeca86bff8e7d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8676">
                                                                                                        <label for="activityf25519889bb711e48d2eeca86bff8e7d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Create:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityf25519889bb711e48d2eeca86bff8e7d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8677">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityf25519889bb711e48d2eeca86bff8e7d" name="actf25519889bb711e48d2eeca86bff8e7d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8683">
                                                                                                        <label for="activityfc021cb09bb711e48d2eeca86bff8e7d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Edit:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityfc021cb09bb711e48d2eeca86bff8e7d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8684">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityfc021cb09bb711e48d2eeca86bff8e7d" name="actfc021cb09bb711e48d2eeca86bff8e7d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8690">
                                                                                                        <label for="activity03125e2a9bb811e48d2eeca86bff8e7d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Delete:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity03125e2a9bb811e48d2eeca86bff8e7d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8691">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity03125e2a9bb811e48d2eeca86bff8e7d" name="act03125e2a9bb811e48d2eeca86bff8e7d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8697">
                                                                                                        <label for="activity88fc61029bb811e48d2eeca86bff8e7d" style="width:250px; font-weight:bold;" class="x-form-item-label">Generate Asset Depreciation:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity88fc61029bb811e48d2eeca86bff8e7d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8698">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity88fc61029bb811e48d2eeca86bff8e7d" name="act88fc61029bb811e48d2eeca86bff8e7d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8704">
                                                                                                        <label for="activityf25519889bb711e48d3eyca86bff8e7d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Post:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityf25519889bb711e48d3eyca86bff8e7d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8705">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityf25519889bb711e48d3eyca86bff8e7d" name="actf25519889bb711e48d3eyca86bff8e7d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8711">
                                                                                                        <label for="activityd5d0a44e9bb711e48d3eeca86bff8e8d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Export:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityd5d0a44e9bb711e48d3eeca86bff8e8d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8712">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityd5d0a44e9bb711e48d3eeca86bff8e8d" name="actd5d0a44e9bb711e48d3eeca86bff8e8d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8718">
                                                                                                        <label for="activityded60e769bb711e48d4eeca86bff8e8d" style="padding-left:25px;width:225px;" class="x-form-item-label">...print:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityded60e769bb711e48d4eeca86bff8e8d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8719">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityded60e769bb711e48d4eeca86bff8e8d" name="actded60e769bb711e48d4eeca86bff8e8d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8725">
                                                                                                        <label for="activity88fc61029bv911e49d2feca86bff8e7d" style="width:250px; font-weight:bold;" class="x-form-item-label">Unpost Asset Depreciation:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity88fc61029bv911e49d2feca86bff8e7d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8726">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity88fc61029bv911e49d2feca86bff8e7d" name="act88fc61029bv911e49d2feca86bff8e7d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8732">
                                                                                                        <label for="activityf25519889bb711e48d3fyca86bff8e7d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Unpost:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityf25519889bb711e48d3fyca86bff8e7d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8733">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityf25519889bb711e48d3fyca86bff8e7d" name="actf25519889bb711e48d3fyca86bff8e7d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8739">
                                                                                                        <label for="activitya10a9b609bb811e48d2feca86bff8e7d" style="width:250px; font-weight:bold;" class="x-form-item-label">View Asset Maintenance Schedule:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activitya10a9b609bb811e48d2feca86bff8e7d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8740">
                                                                                                                <input type="checkbox" autocomplete="off" id="activitya10a9b609bb811e48d2feca86bff8e7d" name="acta10a9b609bb811e48d2feca86bff8e7d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8746">
                                                                                                        <label for="activity90e752be9bb811e58d2feca86bff8e7d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Create:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity90e752be9bb811e58d2feca86bff8e7d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8747">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity90e752be9bb811e58d2feca86bff8e7d" name="act90e752be9bb811e58d2feca86bff8e7d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8753">
                                                                                                        <label for="activity03125e2a9bb811e68d2feca86bff8e7d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Delete:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity03125e2a9bb811e68d2feca86bff8e7d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8754">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity03125e2a9bb811e68d2feca86bff8e7d" name="act03125e2a9bb811e68d2feca86bff8e7d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8760">
                                                                                                        <label for="activity98623ac29bb811e48d6feca83bfz8e7d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Edit:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity98623ac29bb811e48d6feca83bfz8e7d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8761">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity98623ac29bb811e48d6feca83bfz8e7d" name="act98623ac29bb811e48d6feca83bfz8e7d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8767">
                                                                                                        <label for="activitya10a9b609bb811e48d2eeca86bftre7d" style="width:250px; font-weight:bold;" class="x-form-item-label">View Asset Report:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activitya10a9b609bb811e48d2eeca86bftre7d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8768">
                                                                                                                <input type="checkbox" autocomplete="off" id="activitya10a9b609bb811e48d2eeca86bftre7d" name="acta10a9b609bb811e48d2eeca86bftre7d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8774">
                                                                                                        <label for="activity03126e2a9bb811e68d2eeca86brf8e7d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Export:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity03126e2a9bb811e68d2eeca86brf8e7d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8775">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity03126e2a9bb811e68d2eeca86brf8e7d" name="act03126e2a9bb811e68d2eeca86brf8e7d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8781">
                                                                                                        <label for="activity06126e2a9bb811e68d2eeca86brf8e7d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Print:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity06126e2a9bb811e68d2eeca86brf8e7d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8782">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity06126e2a9bb811e68d2eeca86brf8e7d" name="act06126e2a9bb811e68d2eeca86brf8e7d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8788">
                                                                                                        <label for="activityac409d229bb811e48d2eefa86bff8e7d" style="width:250px; font-weight:bold;" class="x-form-item-label">View Maintenance Work Order:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityac409d229bb811e48d2eefa86bff8e7d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8789">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityac409d229bb811e48d2eefa86bff8e7d" name="actac409d229bb811e48d2eefa86bff8e7d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8795">
                                                                                                        <label for="activity95e752be9bb811e58d2eefa86bft8e7d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Delete:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity95e752be9bb811e58d2eefa86bft8e7d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8796">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity95e752be9bb811e58d2eefa86bft8e7d" name="act95e752be9bb811e58d2eefa86bft8e7d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8802">
                                                                                                        <label for="activity03125e2a9bb811e68d2eefa86brf8e7d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Export:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity03125e2a9bb811e68d2eefa86brf8e7d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8803">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity03125e2a9bb811e68d2eefa86brf8e7d" name="act03125e2a9bb811e68d2eefa86brf8e7d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8809">
                                                                                                        <label for="activity05625e2a9bb811e68d2eefa86brf8e7d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Print:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity05625e2a9bb811e68d2eefa86brf8e7d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8810">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity05625e2a9bb811e68d2eefa86brf8e7d" name="act05625e2a9bb811e68d2eefa86brf8e7d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8816">
                                                                                                        <label for="activitya10a9b609bb811e48d2eeca86bhyre7d" style="width:250px; font-weight:bold;" class="x-form-item-label">View Asset Depreciation Details Report:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activitya10a9b609bb811e48d2eeca86bhyre7d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8817">
                                                                                                                <input type="checkbox" autocomplete="off" id="activitya10a9b609bb811e48d2eeca86bhyre7d" name="acta10a9b609bb811e48d2eeca86bhyre7d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8823">
                                                                                                        <label for="activity03126e2a9bb811e68d2eeca86brtf8e7d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Export:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity03126e2a9bb811e68d2eeca86brtf8e7d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8824">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity03126e2a9bb811e68d2eeca86brtf8e7d" name="act03126e2a9bb811e68d2eeca86brtf8e7d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8830">
                                                                                                        <label for="activity06126e2a9bb811e68d2eeca86dee8e7d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Print:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity06126e2a9bb811e68d2eeca86dee8e7d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8831">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity06126e2a9bb811e68d2eeca86dee8e7d" name="act06126e2a9bb811e68d2eeca86dee8e7d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8837">
                                                                                                        <label for="activity679813889bb711e4b5cbeca86bfp8e9d" style="width:250px; font-weight:bold;" class="x-form-item-label">Update Asset Maintenance Schedules:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity679813889bb711e4b5cbeca86bfp8e9d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8838">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity679813889bb711e4b5cbeca86bfp8e9d" name="act679813889bb711e4b5cbeca86bfp8e9d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8844">
                                                                                                        <label for="activity7b45diye9bb711e4b5cbeca86bpf8e9d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Update:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity7b45diye9bb711e4b5cbeca86bpf8e9d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8845">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity7b45diye9bb711e4b5cbeca86bpf8e9d" name="act7b45diye9bb711e4b5cbeca86bpf8e9d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8851">
                                                                                                        <label for="activity1e3ec204b25511e7abc4cec278b6b50a" style="width:250px; font-weight:bold;" class="x-form-item-label">Opening Balance:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity1e3ec204b25511e7abc4cec278b6b50a" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8852">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity1e3ec204b25511e7abc4cec278b6b50a" name="act1e3ec204b25511e7abc4cec278b6b50a" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                        <fieldset id="featuree092295a9bd711e4bbfeeca86bff8e7d" class=" x-fieldset x-panel-collapsed" style="margin: 10px;">
                                                                                            <legend class="x-fieldset-header x-unselectable" id="wtf-gen5902">
                                                                                                <div class="x-tool x-tool-toggle" id="wtf-gen5906">&nbsp;</div><span class="x-fieldset-header-text" id="wtf-gen5910">Sales Return</span></legend>
                                                                                            <div class="x-fieldset-bwrap" id="wtf-gen5903">
                                                                                                <div class="x-fieldset-body" id="wtf-gen5904">
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8858">
                                                                                                        <label for="activity41dc91509bd811e4bbfeeca86bff8e7d" style="width:250px; font-weight:bold;" class="x-form-item-label">Create Sales Return:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity41dc91509bd811e4bbfeeca86bff8e7d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8859">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity41dc91509bd811e4bbfeeca86bff8e7d" name="act41dc91509bd811e4bbfeeca86bff8e7d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8865">
                                                                                                        <label for="activity4a888d049bd811e4bbfeeca86bff8e7d" style="width:250px; font-weight:bold;" class="x-form-item-label">View Sales Return:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity4a888d049bd811e4bbfeeca86bff8e7d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8866">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity4a888d049bd811e4bbfeeca86bff8e7d" name="act4a888d049bd811e4bbfeeca86bff8e7d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8872">
                                                                                                        <label for="activity533ea9389bd811e4bbfeeca86bff8e7d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Edit:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity533ea9389bd811e4bbfeeca86bff8e7d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8873">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity533ea9389bd811e4bbfeeca86bff8e7d" name="act533ea9389bd811e4bbfeeca86bff8e7d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8879">
                                                                                                        <label for="activity5b971eb29bd811e4bbfeeca86bff8e7d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Delete:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity5b971eb29bd811e4bbfeeca86bff8e7d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8880">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity5b971eb29bd811e4bbfeeca86bff8e7d" name="act5b971eb29bd811e4bbfeeca86bff8e7d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8886">
                                                                                                        <label for="activity6437e4fc9bd811e4bbfeeca86bff8e7d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Export:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity6437e4fc9bd811e4bbfeeca86bff8e7d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8887">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity6437e4fc9bd811e4bbfeeca86bff8e7d" name="act6437e4fc9bd811e4bbfeeca86bff8e7d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8893">
                                                                                                        <label for="activity6d6eef169bd811e4bbfeeca86bff8e7d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Print:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity6d6eef169bd811e4bbfeeca86bff8e7d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8894">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity6d6eef169bd811e4bbfeeca86bff8e7d" name="act6d6eef169bd811e4bbfeeca86bff8e7d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8900">
                                                                                                        <label for="activity3346576f47ad41c7a7b5c1e8d7f7ee97" style="padding-left:25px;width:225px;" class="x-form-item-label">...Copy:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity3346576f47ad41c7a7b5c1e8d7f7ee97" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8901">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity3346576f47ad41c7a7b5c1e8d7f7ee97" name="act3346576f47ad41c7a7b5c1e8d7f7ee97" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8907">
                                                                                                        <label for="activity640fc0ee641411e58e15eca86bfcd415" style="padding-left:25px;width:225px;" class="x-form-item-label">...Unlink:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity640fc0ee641411e58e15eca86bfcd415" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8908">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity640fc0ee641411e58e15eca86bfcd415" name="act640fc0ee641411e58e15eca86bfcd415" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                        <fieldset id="featuree71503d6a2f011e4adaceca86bff8e7d" class=" x-fieldset x-panel-collapsed" style="margin: 10px;">
                                                                                            <legend class="x-fieldset-header x-unselectable" id="wtf-gen5911">
                                                                                                <div class="x-tool x-tool-toggle" id="wtf-gen5915">&nbsp;</div><span class="x-fieldset-header-text" id="wtf-gen5919">Aged Payable</span></legend>
                                                                                            <div class="x-fieldset-bwrap" id="wtf-gen5912">
                                                                                                <div class="x-fieldset-body" id="wtf-gen5913">
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8914">
                                                                                                        <label for="activity1b64fb0ea2f211e4adaceca86bff8e7d" style="width:250px; font-weight:bold;" class="x-form-item-label">View Aged payable Report:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity1b64fb0ea2f211e4adaceca86bff8e7d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8915">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity1b64fb0ea2f211e4adaceca86bff8e7d" name="act1b64fb0ea2f211e4adaceca86bff8e7d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8921">
                                                                                                        <label for="activity317e3388a2f211e4adaceca86bff8e7d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Chart:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity317e3388a2f211e4adaceca86bff8e7d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8922">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity317e3388a2f211e4adaceca86bff8e7d" name="act317e3388a2f211e4adaceca86bff8e7d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8928">
                                                                                                        <label for="activity3f5577a0a2f211e4adaceca86bff8e7d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Export Data:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity3f5577a0a2f211e4adaceca86bff8e7d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8929">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity3f5577a0a2f211e4adaceca86bff8e7d" name="act3f5577a0a2f211e4adaceca86bff8e7d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8935">
                                                                                                        <label for="activity4999124ea2f211e4adaceca86bff8e7d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Print:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity4999124ea2f211e4adaceca86bff8e7d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8936">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity4999124ea2f211e4adaceca86bff8e7d" name="act4999124ea2f211e4adaceca86bff8e7d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                        <fieldset id="feature485b1f96a2f511e4adaceca86bff8e7d" class=" x-fieldset x-panel-collapsed" style="margin: 10px;">
                                                                                            <legend class="x-fieldset-header x-unselectable" id="wtf-gen5920">
                                                                                                <div class="x-tool x-tool-toggle" id="wtf-gen5924">&nbsp;</div><span class="x-fieldset-header-text" id="wtf-gen5928">Debit Note</span></legend>
                                                                                            <div class="x-fieldset-bwrap" id="wtf-gen5921">
                                                                                                <div class="x-fieldset-body" id="wtf-gen5922">
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8942">
                                                                                                        <label for="activity6849e5a8a2f511e4adaceca86bff8e7d" style="width:250px; font-weight:bold;" class="x-form-item-label">Import Debit Note:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity6849e5a8a2f511e4adaceca86bff8e7d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8943">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity6849e5a8a2f511e4adaceca86bff8e7d" name="act6849e5a8a2f511e4adaceca86bff8e7d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8949">
                                                                                                        <label for="activity72f5ef60a2f511e4adaceca86bff8e7d" style="width:250px; font-weight:bold;" class="x-form-item-label">Create Debit Note:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity72f5ef60a2f511e4adaceca86bff8e7d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8950">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity72f5ef60a2f511e4adaceca86bff8e7d" name="act72f5ef60a2f511e4adaceca86bff8e7d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8956">
                                                                                                        <label for="activity80cd4ad4a2f511e4adaceca86bff8e7d" style="width:250px; font-weight:bold;" class="x-form-item-label">View Debit Note Report:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity80cd4ad4a2f511e4adaceca86bff8e7d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8957">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity80cd4ad4a2f511e4adaceca86bff8e7d" name="act80cd4ad4a2f511e4adaceca86bff8e7d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8963">
                                                                                                        <label for="activity72d50938a2f711e4adaceca86bff8e7d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Edit:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity72d50938a2f711e4adaceca86bff8e7d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8964">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity72d50938a2f711e4adaceca86bff8e7d" name="act72d50938a2f711e4adaceca86bff8e7d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8970">
                                                                                                        <label for="activity8431d080a2f711e4adaceca86bff8e7d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Delete:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity8431d080a2f711e4adaceca86bff8e7d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8971">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity8431d080a2f711e4adaceca86bff8e7d" name="act8431d080a2f711e4adaceca86bff8e7d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8977">
                                                                                                        <label for="activity8fe6e7a8a2f711e4adaceca86bff8e7d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Export Data:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity8fe6e7a8a2f711e4adaceca86bff8e7d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8978">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity8fe6e7a8a2f711e4adaceca86bff8e7d" name="act8fe6e7a8a2f711e4adaceca86bff8e7d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8984">
                                                                                                        <label for="activity9db0390ca2f711e4adaceca86bff8e7d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Print:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity9db0390ca2f711e4adaceca86bff8e7d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8985">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity9db0390ca2f711e4adaceca86bff8e7d" name="act9db0390ca2f711e4adaceca86bff8e7d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8991">
                                                                                                        <label for="activity3346576f47ad41c7g7b5c1e8d7f7ee95" style="padding-left:25px;width:225px;" class="x-form-item-label">...Copy:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity3346576f47ad41c7g7b5c1e8d7f7ee95" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8992">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity3346576f47ad41c7g7b5c1e8d7f7ee95" name="act3346576f47ad41c7g7b5c1e8d7f7ee95" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                        <fieldset id="feature2d428a08f31f11e48635eca86bff9ae2" class=" x-fieldset x-panel-collapsed" style="margin: 10px;">
                                                                                            <legend class="x-fieldset-header x-unselectable" id="wtf-gen5929">
                                                                                                <div class="x-tool x-tool-toggle" id="wtf-gen5933">&nbsp;</div><span class="x-fieldset-header-text" id="wtf-gen5937">Consignment Stock - Purchase</span></legend>
                                                                                            <div class="x-fieldset-bwrap" id="wtf-gen5930">
                                                                                                <div class="x-fieldset-body" id="wtf-gen5931">
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen8998">
                                                                                                        <label for="activity2d428a08f31f11e48635eca86bff9101" style="width:250px; font-weight:bold;" class="x-form-item-label">Create Vendor Consignment Request:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity2d428a08f31f11e48635eca86bff9101" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen8999">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity2d428a08f31f11e48635eca86bff9101" name="act2d428a08f31f11e48635eca86bff9101" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9005">
                                                                                                        <label for="activity2d428a08f31f11e48635eca86bff9102" style="width:250px; font-weight:bold;" class="x-form-item-label">View Vendor Consignment Request:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity2d428a08f31f11e48635eca86bff9102" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9006">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity2d428a08f31f11e48635eca86bff9102" name="act2d428a08f31f11e48635eca86bff9102" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9012">
                                                                                                        <label for="activity2d428a08f31f11e48635eca86bff9103" style="padding-left:25px;width:225px;" class="x-form-item-label">...Modify:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity2d428a08f31f11e48635eca86bff9103" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9013">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity2d428a08f31f11e48635eca86bff9103" name="act2d428a08f31f11e48635eca86bff9103" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9019">
                                                                                                        <label for="activity2d428a08f31f11e48635eca86bff9104" style="padding-left:25px;width:225px;" class="x-form-item-label">...Delete:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity2d428a08f31f11e48635eca86bff9104" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9020">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity2d428a08f31f11e48635eca86bff9104" name="act2d428a08f31f11e48635eca86bff9104" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9026">
                                                                                                        <label for="activity2d428a08f31f11e48635eca86bff9105" style="padding-left:25px;width:225px;" class="x-form-item-label">...Export Data:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity2d428a08f31f11e48635eca86bff9105" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9027">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity2d428a08f31f11e48635eca86bff9105" name="act2d428a08f31f11e48635eca86bff9105" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9033">
                                                                                                        <label for="activity2d428a08f31f11e48635eca86bff9106" style="padding-left:25px;width:225px;" class="x-form-item-label">...Print:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity2d428a08f31f11e48635eca86bff9106" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9034">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity2d428a08f31f11e48635eca86bff9106" name="act2d428a08f31f11e48635eca86bff9106" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9040">
                                                                                                        <label for="activity2d428a08f31f11e48635eca86bff9107" style="width:250px; font-weight:bold;" class="x-form-item-label">Create Consignment Goods Receipt Order:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity2d428a08f31f11e48635eca86bff9107" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9041">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity2d428a08f31f11e48635eca86bff9107" name="act2d428a08f31f11e48635eca86bff9107" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9047">
                                                                                                        <label for="activity2d428a08f31f11e48635eca86bff9108" style="width:250px; font-weight:bold;" class="x-form-item-label">View Consignment Goods Receipt Order:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity2d428a08f31f11e48635eca86bff9108" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9048">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity2d428a08f31f11e48635eca86bff9108" name="act2d428a08f31f11e48635eca86bff9108" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9054">
                                                                                                        <label for="activity2d428a08f31f11e48635eca86bff9109" style="padding-left:25px;width:225px;" class="x-form-item-label">...Modify:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity2d428a08f31f11e48635eca86bff9109" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9055">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity2d428a08f31f11e48635eca86bff9109" name="act2d428a08f31f11e48635eca86bff9109" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9061">
                                                                                                        <label for="activity2d428a08f31f11e48635eca86bff9110" style="padding-left:25px;width:225px;" class="x-form-item-label">...Delete:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity2d428a08f31f11e48635eca86bff9110" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9062">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity2d428a08f31f11e48635eca86bff9110" name="act2d428a08f31f11e48635eca86bff9110" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9068">
                                                                                                        <label for="activity2d428a08f31f11e48635eca86bff9111" style="padding-left:25px;width:225px;" class="x-form-item-label">...Export Data:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity2d428a08f31f11e48635eca86bff9111" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9069">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity2d428a08f31f11e48635eca86bff9111" name="act2d428a08f31f11e48635eca86bff9111" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9075">
                                                                                                        <label for="activity2d428a08f31f11e48635eca86bff9112" style="padding-left:25px;width:225px;" class="x-form-item-label">...Print:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity2d428a08f31f11e48635eca86bff9112" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9076">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity2d428a08f31f11e48635eca86bff9112" name="act2d428a08f31f11e48635eca86bff9112" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9082">
                                                                                                        <label for="activity2d428a08f31f11e48635eca86bff9113" style="width:250px; font-weight:bold;" class="x-form-item-label">Create Consignment Purchase Invoice:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity2d428a08f31f11e48635eca86bff9113" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9083">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity2d428a08f31f11e48635eca86bff9113" name="act2d428a08f31f11e48635eca86bff9113" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9089">
                                                                                                        <label for="activity2d428a08f31f11e48635eca86bff9114" style="width:250px; font-weight:bold;" class="x-form-item-label">View Consignment Purchase Invoice:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity2d428a08f31f11e48635eca86bff9114" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9090">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity2d428a08f31f11e48635eca86bff9114" name="act2d428a08f31f11e48635eca86bff9114" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9096">
                                                                                                        <label for="activity2d428a08f31f11e48635eca86bff9115" style="padding-left:25px;width:225px;" class="x-form-item-label">...Modify:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity2d428a08f31f11e48635eca86bff9115" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9097">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity2d428a08f31f11e48635eca86bff9115" name="act2d428a08f31f11e48635eca86bff9115" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9103">
                                                                                                        <label for="activity2d428a08f31f11e48635eca86bff9116" style="padding-left:25px;width:225px;" class="x-form-item-label">...Delete:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity2d428a08f31f11e48635eca86bff9116" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9104">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity2d428a08f31f11e48635eca86bff9116" name="act2d428a08f31f11e48635eca86bff9116" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9110">
                                                                                                        <label for="activity2d428a08f31f11e48635eca86bff9117" style="padding-left:25px;width:225px;" class="x-form-item-label">...Export Data:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity2d428a08f31f11e48635eca86bff9117" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9111">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity2d428a08f31f11e48635eca86bff9117" name="act2d428a08f31f11e48635eca86bff9117" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9117">
                                                                                                        <label for="activity2d428a08f31f11e48635eca86bff9118" style="padding-left:25px;width:225px;" class="x-form-item-label">...Print:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity2d428a08f31f11e48635eca86bff9118" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9118">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity2d428a08f31f11e48635eca86bff9118" name="act2d428a08f31f11e48635eca86bff9118" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9124">
                                                                                                        <label for="activity2d428a08f31f11e48635eca86bff9119" style="width:250px; font-weight:bold;" class="x-form-item-label">Create Consignment Purchase Return:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity2d428a08f31f11e48635eca86bff9119" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9125">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity2d428a08f31f11e48635eca86bff9119" name="act2d428a08f31f11e48635eca86bff9119" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9131">
                                                                                                        <label for="activity2d428a08f31f11e48635eca86bff9120" style="width:250px; font-weight:bold;" class="x-form-item-label">View Consignment Purchase Return:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity2d428a08f31f11e48635eca86bff9120" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9132">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity2d428a08f31f11e48635eca86bff9120" name="act2d428a08f31f11e48635eca86bff9120" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9138">
                                                                                                        <label for="activity2d428a08f31f11e48635eca86bff9121" style="padding-left:25px;width:225px;" class="x-form-item-label">...Modify:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity2d428a08f31f11e48635eca86bff9121" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9139">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity2d428a08f31f11e48635eca86bff9121" name="act2d428a08f31f11e48635eca86bff9121" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9145">
                                                                                                        <label for="activity2d428a08f31f11e48635eca86bff9122" style="padding-left:25px;width:225px;" class="x-form-item-label">...Delete:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity2d428a08f31f11e48635eca86bff9122" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9146">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity2d428a08f31f11e48635eca86bff9122" name="act2d428a08f31f11e48635eca86bff9122" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9152">
                                                                                                        <label for="activity2d428a08f31f11e48635eca86bff9123" style="padding-left:25px;width:225px;" class="x-form-item-label">...Export Data:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity2d428a08f31f11e48635eca86bff9123" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9153">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity2d428a08f31f11e48635eca86bff9123" name="act2d428a08f31f11e48635eca86bff9123" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9159">
                                                                                                        <label for="activity2d428a08f31f11e48635eca86bff9124" style="padding-left:25px;width:225px;" class="x-form-item-label">...Print:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity2d428a08f31f11e48635eca86bff9124" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9160">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity2d428a08f31f11e48635eca86bff9124" name="act2d428a08f31f11e48635eca86bff9124" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                        <fieldset id="feature394ca219569d412e92317a164be46321" class=" x-fieldset x-panel-collapsed" style="margin: 10px;">
                                                                                            <legend class="x-fieldset-header x-unselectable" id="wtf-gen5938">
                                                                                                <div class="x-tool x-tool-toggle" id="wtf-gen5942">&nbsp;</div><span class="x-fieldset-header-text" id="wtf-gen5946">Issue Note</span></legend>
                                                                                            <div class="x-fieldset-bwrap" id="wtf-gen5939">
                                                                                                <div class="x-fieldset-body" id="wtf-gen5940">
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9166">
                                                                                                        <label for="activity94648230c0af4c3bb22a3195a9d745cd" style="width:250px; font-weight:bold;" class="x-form-item-label">Create:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity94648230c0af4c3bb22a3195a9d745cd" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9167">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity94648230c0af4c3bb22a3195a9d745cd" name="act94648230c0af4c3bb22a3195a9d745cd" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                        <fieldset id="featuree0729e3ae07847cba2ee04d3823100dc" class=" x-fieldset x-panel-collapsed" style="margin: 10px;">
                                                                                            <legend class="x-fieldset-header x-unselectable" id="wtf-gen5947">
                                                                                                <div class="x-tool x-tool-toggle" id="wtf-gen5951">&nbsp;</div><span class="x-fieldset-header-text" id="wtf-gen5955">Inter Store Stock Transfer</span></legend>
                                                                                            <div class="x-fieldset-bwrap" id="wtf-gen5948">
                                                                                                <div class="x-fieldset-body" id="wtf-gen5949">
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9173">
                                                                                                        <label for="activity16b53b8f20054d1daff9dfdf7e6cc780" style="width:250px; font-weight:bold;" class="x-form-item-label">Create:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity16b53b8f20054d1daff9dfdf7e6cc780" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9174">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity16b53b8f20054d1daff9dfdf7e6cc780" name="act16b53b8f20054d1daff9dfdf7e6cc780" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9180">
                                                                                                        <label for="activityc952be57dfff48afa471a24a51a66490" style="width:250px; font-weight:bold;" class="x-form-item-label">View:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityc952be57dfff48afa471a24a51a66490" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9181">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityc952be57dfff48afa471a24a51a66490" name="actc952be57dfff48afa471a24a51a66490" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9187">
                                                                                                        <label for="activitybf2d588efdef4cbe98deab5d0781166f" style="padding-left:25px;width:225px;" class="x-form-item-label">...Accept / Reject Request:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activitybf2d588efdef4cbe98deab5d0781166f" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9188">
                                                                                                                <input type="checkbox" autocomplete="off" id="activitybf2d588efdef4cbe98deab5d0781166f" name="actbf2d588efdef4cbe98deab5d0781166f" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9194">
                                                                                                        <label for="activitye89a7854cd1245f09b59b0b2bd81fb3d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Print:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activitye89a7854cd1245f09b59b0b2bd81fb3d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9195">
                                                                                                                <input type="checkbox" autocomplete="off" id="activitye89a7854cd1245f09b59b0b2bd81fb3d" name="acte89a7854cd1245f09b59b0b2bd81fb3d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9201">
                                                                                                        <label for="activity8dc0aba1b9f043549365476cc65132b5" style="padding-left:25px;width:225px;" class="x-form-item-label">...Export:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity8dc0aba1b9f043549365476cc65132b5" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9202">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity8dc0aba1b9f043549365476cc65132b5" name="act8dc0aba1b9f043549365476cc65132b5" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                        <fieldset id="feature98c6d3ec64fb4dbb97dfa269e599ffb6" class=" x-fieldset x-panel-collapsed" style="margin: 10px;">
                                                                                            <legend class="x-fieldset-header x-unselectable" id="wtf-gen5956">
                                                                                                <div class="x-tool x-tool-toggle" id="wtf-gen5960">&nbsp;</div><span class="x-fieldset-header-text" id="wtf-gen5964">QA Approval</span></legend>
                                                                                            <div class="x-fieldset-bwrap" id="wtf-gen5957">
                                                                                                <div class="x-fieldset-body" id="wtf-gen5958">
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9208">
                                                                                                        <label for="activityc6480c495bf14e7aa5dd7f80608d6c61" style="width:250px; font-weight:bold;" class="x-form-item-label">View:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityc6480c495bf14e7aa5dd7f80608d6c61" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9209">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityc6480c495bf14e7aa5dd7f80608d6c61" name="actc6480c495bf14e7aa5dd7f80608d6c61" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9215">
                                                                                                        <label for="activity887ca58b95f44dbdafec1061e5d211d2" style="padding-left:25px;width:225px;" class="x-form-item-label">...Approve / Reject:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity887ca58b95f44dbdafec1061e5d211d2" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9216">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity887ca58b95f44dbdafec1061e5d211d2" name="act887ca58b95f44dbdafec1061e5d211d2" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                        <fieldset id="featuref8989a5ee8f11e59471eca86bff9ae1" class=" x-fieldset x-panel-collapsed" style="margin: 10px;">
                                                                                            <legend class="x-fieldset-header x-unselectable" id="wtf-gen5965">
                                                                                                <div class="x-tool x-tool-toggle" id="wtf-gen5969">&nbsp;</div><span class="x-fieldset-header-text" id="wtf-gen5973">Inventory Masters</span></legend>
                                                                                            <div class="x-fieldset-bwrap" id="wtf-gen5966">
                                                                                                <div class="x-fieldset-body" id="wtf-gen5967">
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9222">
                                                                                                        <label for="activity258e9cb00e9111e59471eca86bff9ae1" style="width:250px; font-weight:bold;" class="x-form-item-label">Store Master:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity258e9cb00e9111e59471eca86bff9ae1" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9223">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity258e9cb00e9111e59471eca86bff9ae1" name="act258e9cb00e9111e59471eca86bff9ae1" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9229">
                                                                                                        <label for="activity304870ea0e9111e59471eca86bff9ae1" style="width:250px; font-weight:bold;" class="x-form-item-label">Location Master:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity304870ea0e9111e59471eca86bff9ae1" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9230">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity304870ea0e9111e59471eca86bff9ae1" name="act304870ea0e9111e59471eca86bff9ae1" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9236">
                                                                                                        <label for="activityeb214daaa2cc11e4adaceca86bxf8e9e" style="width:250px; font-weight:bold;" class="x-form-item-label">Package Master:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityeb214daaa2cc11e4adaceca86bxf8e9e" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9237">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityeb214daaa2cc11e4adaceca86bxf8e9e" name="acteb214daaa2cc11e4adaceca86bxf8e9e" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9243">
                                                                                                        <label for="activityeb214daaa2cc11e4adaceca86bxf8e9f" style="width:250px; font-weight:bold;" class="x-form-item-label">Inventory Setup:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityeb214daaa2cc11e4adaceca86bxf8e9f" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9244">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityeb214daaa2cc11e4adaceca86bxf8e9f" name="acteb214daaa2cc11e4adaceca86bxf8e9f" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9250">
                                                                                                        <label for="activityeb214daaa2cc11e4adaceca86bxf8e9g" style="width:250px; font-weight:bold;" class="x-form-item-label">Customer Warehouse Master:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityeb214daaa2cc11e4adaceca86bxf8e9g" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9251">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityeb214daaa2cc11e4adaceca86bxf8e9g" name="acteb214daaa2cc11e4adaceca86bxf8e9g" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9257">
                                                                                                        <label for="activityeb214daaa2cc11e4adaceca86bxf8e10g" style="width:250px; font-weight:bold;" class="x-form-item-label">Budgeting:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityeb214daaa2cc11e4adaceca86bxf8e10g" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9258">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityeb214daaa2cc11e4adaceca86bxf8e10g" name="acteb214daaa2cc11e4adaceca86bxf8e10g" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9264">
                                                                                                        <label for="activityeb214daaa2cc11e4adaceca86bxf8e11g" style="width:250px; font-weight:bold;" class="x-form-item-label">Inspection Template:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityeb214daaa2cc11e4adaceca86bxf8e11g" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9265">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityeb214daaa2cc11e4adaceca86bxf8e11g" name="acteb214daaa2cc11e4adaceca86bxf8e11g" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                        <fieldset id="feature4f52f9615e344a50a7e1c8c6a51deg99" class=" x-fieldset x-panel-collapsed" style="margin: 10px;">
                                                                                            <legend class="x-fieldset-header x-unselectable" id="wtf-gen5974">
                                                                                                <div class="x-tool x-tool-toggle" id="wtf-gen5978">&nbsp;</div><span class="x-fieldset-header-text" id="wtf-gen5982">Make Payment</span></legend>
                                                                                            <div class="x-fieldset-bwrap" id="wtf-gen5975">
                                                                                                <div class="x-fieldset-body" id="wtf-gen5976">
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9271">
                                                                                                        <label for="activityeb214daaa2cc11e4adaceca86bxf8e7d" style="width:250px; font-weight:bold;" class="x-form-item-label">Import Make Payments:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityeb214daaa2cc11e4adaceca86bxf8e7d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9272">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityeb214daaa2cc11e4adaceca86bxf8e7d" name="acteb214daaa2cc11e4adaceca86bxf8e7d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9278">
                                                                                                        <label for="activity8122f9dba90122fa4888cfx085" style="width:250px; font-weight:bold;" class="x-form-item-label">Create Make Payment:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity8122f9dba90122fa4888cfx085" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9279">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity8122f9dba90122fa4888cfx085" name="act8122f9dba90122fa4888cfx085" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9285">
                                                                                                        <label for="activityff80808122f9dba90122fa4888cfx0274" style="width:250px; font-weight:bold;" class="x-form-item-label">View Payment Made Report:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba90122fa4888cfx0274" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9286">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba90122fa4888cfx0274" name="actff80808122f9dba90122fa4888cfx0274" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9292">
                                                                                                        <label for="activityff80808122f9dba90122fa4888cfx086" style="padding-left:25px;width:225px;" class="x-form-item-label">...Modify:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba90122fa4888cfx086" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9293">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba90122fa4888cfx086" name="actff80808122f9dba90122fa4888cfx086" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9299">
                                                                                                        <label for="activity3846576f47ad41c7a7b5c1e8d7fxet99" style="padding-left:25px;width:225px;" class="x-form-item-label">...Copy:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity3846576f47ad41c7a7b5c1e8d7fxet99" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9300">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity3846576f47ad41c7a7b5c1e8d7fxet99" name="act3846576f47ad41c7a7b5c1e8d7fxet99" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9306">
                                                                                                        <label for="activityff80808122f9dba90122fa4888xf0087" style="padding-left:25px;width:225px;" class="x-form-item-label">...Delete:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba90122fa4888xf0087" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9307">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba90122fa4888xf0087" name="actff80808122f9dba90122fa4888xf0087" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9313">
                                                                                                        <label for="activityff80808122f9dba90122fa4888xf00117" style="padding-left:25px;width:225px;" class="x-form-item-label">...Email:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba90122fa4888xf00117" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9314">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba90122fa4888xf00117" name="actff80808122f9dba90122fa4888xf00117" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9320">
                                                                                                        <label for="activityff80808122f9dba90122fa4888xf00118" style="padding-left:25px;width:225px;" class="x-form-item-label">...Export Data:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba90122fa4888xf00118" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9321">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba90122fa4888xf00118" name="actff80808122f9dba90122fa4888xf00118" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9327">
                                                                                                        <label for="activityff80808122f9dba90122fa4888xf00119" style="padding-left:25px;width:225px;" class="x-form-item-label">...Print:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityff80808122f9dba90122fa4888xf00119" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9328">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityff80808122f9dba90122fa4888xf00119" name="actff80808122f9dba90122fa4888xf00119" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                        <fieldset id="feature5f52f9615e374a50a7e1c8c6a51deg99" class=" x-fieldset x-panel-collapsed" style="margin: 10px;">
                                                                                            <legend class="x-fieldset-header x-unselectable" id="wtf-gen5983">
                                                                                                <div class="x-tool x-tool-toggle" id="wtf-gen5987">&nbsp;</div><span class="x-fieldset-header-text" id="wtf-gen5991">Asset Purchase Management</span></legend>
                                                                                            <div class="x-fieldset-bwrap" id="wtf-gen5984">
                                                                                                <div class="x-fieldset-body" id="wtf-gen5985">
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9334">
                                                                                                        <label for="activity0cf856b69bb811e48d2eeca86bff8e8d" style="width:250px; font-weight:bold;" class="x-form-item-label">Create Asset Goods Receipt:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity0cf856b69bb811e48d2eeca86bff8e8d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9335">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity0cf856b69bb811e48d2eeca86bff8e8d" name="act0cf856b69bb811e48d2eeca86bff8e8d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9341">
                                                                                                        <label for="activity177f2c309bb811e48d2eeca86bff8e8d" style="width:250px; font-weight:bold;" class="x-form-item-label">View Asset Goods Receipt:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity177f2c309bb811e48d2eeca86bff8e8d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9342">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity177f2c309bb811e48d2eeca86bff8e8d" name="act177f2c309bb811e48d2eeca86bff8e8d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9348">
                                                                                                        <label for="activity1f488cc29bb811e48d2eeca86bff8e8d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Edit:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity1f488cc29bb811e48d2eeca86bff8e8d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9349">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity1f488cc29bb811e48d2eeca86bff8e8d" name="act1f488cc29bb811e48d2eeca86bff8e8d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9355">
                                                                                                        <label for="activity26b311629bb811e48d2eeca86bff8e8d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Delete:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity26b311629bb811e48d2eeca86bff8e8d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9356">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity26b311629bb811e48d2eeca86bff8e8d" name="act26b311629bb811e48d2eeca86bff8e8d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9362">
                                                                                                        <label for="activity2f483f6e9bb811e48d2eeca86bff8e9d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Export:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity2f483f6e9bb811e48d2eeca86bff8e9d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9363">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity2f483f6e9bb811e48d2eeca86bff8e9d" name="act2f483f6e9bb811e48d2eeca86bff8e9d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9369">
                                                                                                        <label for="activity360ba9b29bb811e48d2eeca86bff8e8d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Print:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity360ba9b29bb811e48d2eeca86bff8e8d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9370">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity360ba9b29bb811e48d2eeca86bff8e8d" name="act360ba9b29bb811e48d2eeca86bff8e8d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9376">
                                                                                                        <label for="activity67f013889bb711e4b5cbeca86bff8e9d" style="width:250px; font-weight:bold;" class="x-form-item-label">Create Acquired Invoice:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity67f013889bb711e4b5cbeca86bff8e9d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9377">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity67f013889bb711e4b5cbeca86bff8e9d" name="act67f013889bb711e4b5cbeca86bff8e9d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9383">
                                                                                                        <label for="activity7b45ddbe9bb711e4b5cbeca86bff8e9d" style="width:250px; font-weight:bold;" class="x-form-item-label">View Acquired Invoice:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity7b45ddbe9bb711e4b5cbeca86bff8e9d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9384">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity7b45ddbe9bb711e4b5cbeca86bff8e9d" name="act7b45ddbe9bb711e4b5cbeca86bff8e9d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9390">
                                                                                                        <label for="activity8af321d69bb711e4b5cbeca86bff8e9d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Edit:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity8af321d69bb711e4b5cbeca86bff8e9d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9391">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity8af321d69bb711e4b5cbeca86bff8e9d" name="act8af321d69bb711e4b5cbeca86bff8e9d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9397">
                                                                                                        <label for="activity938481789bb711e4b5cbeca86bff8e9d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Delete:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity938481789bb711e4b5cbeca86bff8e9d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9398">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity938481789bb711e4b5cbeca86bff8e9d" name="act938481789bb711e4b5cbeca86bff8e9d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9404">
                                                                                                        <label for="activity9c99f7669bb711e4b5cbeca86bff8e9d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Export:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity9c99f7669bb711e4b5cbeca86bff8e9d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9405">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity9c99f7669bb711e4b5cbeca86bff8e9d" name="act9c99f7669bb711e4b5cbeca86bff8e9d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9411">
                                                                                                        <label for="activitya6ca0d2a9bb711e4b5cbeca86bff8e9d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Print:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activitya6ca0d2a9bb711e4b5cbeca86bff8e9d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9412">
                                                                                                                <input type="checkbox" autocomplete="off" id="activitya6ca0d2a9bb711e4b5cbeca86bff8e9d" name="acta6ca0d2a9bb711e4b5cbeca86bff8e9d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9418">
                                                                                                        <label for="activity69f013889bb711e4b5cbeca86bff8e9d" style="width:250px; font-weight:bold;" class="x-form-item-label">Create Asset Purchase Order:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity69f013889bb711e4b5cbeca86bff8e9d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9419">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity69f013889bb711e4b5cbeca86bff8e9d" name="act69f013889bb711e4b5cbeca86bff8e9d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9425">
                                                                                                        <label for="activity7b49ddbe9bb711e4b5cbeca86bff8e9d" style="width:250px; font-weight:bold;" class="x-form-item-label">View Asset Purchase Order:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity7b49ddbe9bb711e4b5cbeca86bff8e9d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9426">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity7b49ddbe9bb711e4b5cbeca86bff8e9d" name="act7b49ddbe9bb711e4b5cbeca86bff8e9d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9432">
                                                                                                        <label for="activity8af381d69bb711e4b5cbeca86bff8e9d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Edit:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity8af381d69bb711e4b5cbeca86bff8e9d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9433">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity8af381d69bb711e4b5cbeca86bff8e9d" name="act8af381d69bb711e4b5cbeca86bff8e9d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9439">
                                                                                                        <label for="activity938491789bb711e4b5cbeca86bff8e9d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Delete:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity938491789bb711e4b5cbeca86bff8e9d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9440">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity938491789bb711e4b5cbeca86bff8e9d" name="act938491789bb711e4b5cbeca86bff8e9d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9446">
                                                                                                        <label for="activity9c99k7669bb711e4b5cbeca86bff8e9d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Export:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity9c99k7669bb711e4b5cbeca86bff8e9d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9447">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity9c99k7669bb711e4b5cbeca86bff8e9d" name="act9c99k7669bb711e4b5cbeca86bff8e9d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9453">
                                                                                                        <label for="activitya6ci7d2a9bb711e4b5cbeca86bff8e9d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Print:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activitya6ci7d2a9bb711e4b5cbeca86bff8e9d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9454">
                                                                                                                <input type="checkbox" autocomplete="off" id="activitya6ci7d2a9bb711e4b5cbeca86bff8e9d" name="acta6ci7d2a9bb711e4b5cbeca86bff8e9d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9460">
                                                                                                        <label for="activity67f013889bb711e4b5cbeca86bmf8e9d" style="width:250px; font-weight:bold;" class="x-form-item-label">Create Asset Vendor Quotation:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity67f013889bb711e4b5cbeca86bmf8e9d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9461">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity67f013889bb711e4b5cbeca86bmf8e9d" name="act67f013889bb711e4b5cbeca86bmf8e9d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9467">
                                                                                                        <label for="activity7b45ddbe9bb711e4b5cbeca86bmf8e9d" style="width:250px; font-weight:bold;" class="x-form-item-label">View Asset Vendor Quotation:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity7b45ddbe9bb711e4b5cbeca86bmf8e9d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9468">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity7b45ddbe9bb711e4b5cbeca86bmf8e9d" name="act7b45ddbe9bb711e4b5cbeca86bmf8e9d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9474">
                                                                                                        <label for="activity8af321d69bb711e4b5cbeca86bmf8e9d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Edit:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity8af321d69bb711e4b5cbeca86bmf8e9d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9475">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity8af321d69bb711e4b5cbeca86bmf8e9d" name="act8af321d69bb711e4b5cbeca86bmf8e9d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9481">
                                                                                                        <label for="activity938481789bb711e4b5cbeca86bmf8e9d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Delete:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity938481789bb711e4b5cbeca86bmf8e9d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9482">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity938481789bb711e4b5cbeca86bmf8e9d" name="act938481789bb711e4b5cbeca86bmf8e9d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9488">
                                                                                                        <label for="activity9c99f7669bb711e4b5cbeca86bmf8e9d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Export:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity9c99f7669bb711e4b5cbeca86bmf8e9d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9489">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity9c99f7669bb711e4b5cbeca86bmf8e9d" name="act9c99f7669bb711e4b5cbeca86bmf8e9d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9495">
                                                                                                        <label for="activitya6ca0d2a9bb711e4b5cbeca86bmf8e9d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Print:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activitya6ca0d2a9bb711e4b5cbeca86bmf8e9d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9496">
                                                                                                                <input type="checkbox" autocomplete="off" id="activitya6ca0d2a9bb711e4b5cbeca86bmf8e9d" name="acta6ca0d2a9bb711e4b5cbeca86bmf8e9d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                        <fieldset id="feature5f52f9615e384a50a7e1c8c6a61deg99" class=" x-fieldset x-panel-collapsed" style="margin: 10px;">
                                                                                            <legend class="x-fieldset-header x-unselectable" id="wtf-gen5992">
                                                                                                <div class="x-tool x-tool-toggle" id="wtf-gen5996">&nbsp;</div><span class="x-fieldset-header-text" id="wtf-gen6000">Contract</span></legend>
                                                                                            <div class="x-fieldset-bwrap" id="wtf-gen5993">
                                                                                                <div class="x-fieldset-body" id="wtf-gen5994">
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9502">
                                                                                                        <label for="activity0cf856b69cb913e48d2eeca86bff8e8d" style="width:250px; font-weight:bold;" class="x-form-item-label">Create Lease Contract:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity0cf856b69cb913e48d2eeca86bff8e8d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9503">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity0cf856b69cb913e48d2eeca86bff8e8d" name="act0cf856b69cb913e48d2eeca86bff8e8d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9509">
                                                                                                        <label for="activity177f2c309cb914e48d2eeca86bff8e8d" style="width:250px; font-weight:bold;" class="x-form-item-label">View Lease Contract Register:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity177f2c309cb914e48d2eeca86bff8e8d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9510">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity177f2c309cb914e48d2eeca86bff8e8d" name="act177f2c309cb914e48d2eeca86bff8e8d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9516">
                                                                                                        <label for="activity1f488cc29cb914e48d2eeca86bff8e8d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Edit:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity1f488cc29cb914e48d2eeca86bff8e8d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9517">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity1f488cc29cb914e48d2eeca86bff8e8d" name="act1f488cc29cb914e48d2eeca86bff8e8d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9523">
                                                                                                        <label for="activity26b311629cb914e48d2eeca86bff8e8d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Terminate:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity26b311629cb914e48d2eeca86bff8e8d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9524">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity26b311629cb914e48d2eeca86bff8e8d" name="act26b311629cb914e48d2eeca86bff8e8d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9530">
                                                                                                        <label for="activity360ba9b29cb914e48d2eeca86bff8e8d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Renew:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity360ba9b29cb914e48d2eeca86bff8e8d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9531">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity360ba9b29cb914e48d2eeca86bff8e8d" name="act360ba9b29cb914e48d2eeca86bff8e8d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9537">
                                                                                                        <label for="activity2f483f6e9cb915e48d2eeca86bff8e9d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Export:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity2f483f6e9cb915e48d2eeca86bff8e9d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9538">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity2f483f6e9cb915e48d2eeca86bff8e9d" name="act2f483f6e9cb915e48d2eeca86bff8e9d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9544">
                                                                                                        <label for="activity0cf8r6b69cb913e48d2eeca86bff8e9d" style="width:250px; font-weight:bold;" class="x-form-item-label">Create Sales Contract:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity0cf8r6b69cb913e48d2eeca86bff8e9d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9545">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity0cf8r6b69cb913e48d2eeca86bff8e9d" name="act0cf8r6b69cb913e48d2eeca86bff8e9d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9551">
                                                                                                        <label for="activity177f2r309cb914e48d2eeca86bff8e9d" style="width:250px; font-weight:bold;" class="x-form-item-label">View Sales Contract :</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity177f2r309cb914e48d2eeca86bff8e9d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9552">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity177f2r309cb914e48d2eeca86bff8e9d" name="act177f2r309cb914e48d2eeca86bff8e9d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9558">
                                                                                                        <label for="activity1f488rc29cb914e48d2eeca86bff8e9d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Edit:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity1f488rc29cb914e48d2eeca86bff8e9d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9559">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity1f488rc29cb914e48d2eeca86bff8e9d" name="act1f488rc29cb914e48d2eeca86bff8e9d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9565">
                                                                                                        <label for="activity26b312629cb914e48d2eeca86bff8e9d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Terminate:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity26b312629cb914e48d2eeca86bff8e9d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9566">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity26b312629cb914e48d2eeca86bff8e9d" name="act26b312629cb914e48d2eeca86bff8e9d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9572">
                                                                                                        <label for="activity360ba9c29cb914e48d2eeca86bff8e9d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Renew:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity360ba9c29cb914e48d2eeca86bff8e9d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9573">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity360ba9c29cb914e48d2eeca86bff8e9d" name="act360ba9c29cb914e48d2eeca86bff8e9d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9579">
                                                                                                        <label for="activity2f483f7e9cb915e48d2eeca86bff8e9d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Export:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity2f483f7e9cb915e48d2eeca86bff8e9d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9580">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity2f483f7e9cb915e48d2eeca86bff8e9d" name="act2f483f7e9cb915e48d2eeca86bff8e9d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                        <fieldset id="feature25178b7fbdc144c3ad53fc476f7f8eb8" class=" x-fieldset x-panel-collapsed" style="margin: 10px;">
                                                                                            <legend class="x-fieldset-header x-unselectable" id="wtf-gen6001">
                                                                                                <div class="x-tool x-tool-toggle" id="wtf-gen6005">&nbsp;</div><span class="x-fieldset-header-text" id="wtf-gen6009">Consignment Request Approval</span></legend>
                                                                                            <div class="x-fieldset-bwrap" id="wtf-gen6002">
                                                                                                <div class="x-fieldset-body" id="wtf-gen6003">
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9586">
                                                                                                        <label for="activity2364d8939cb94d619ebd969b6a75cc1c" style="width:250px; font-weight:bold;" class="x-form-item-label">View:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity2364d8939cb94d619ebd969b6a75cc1c" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9587">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity2364d8939cb94d619ebd969b6a75cc1c" name="act2364d8939cb94d619ebd969b6a75cc1c" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9593">
                                                                                                        <label for="activityae67d4ec483f444bb3d18aad1ddcd4d0" style="padding-left:25px;width:225px;" class="x-form-item-label">...Approve / Reject:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityae67d4ec483f444bb3d18aad1ddcd4d0" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9594">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityae67d4ec483f444bb3d18aad1ddcd4d0" name="actae67d4ec483f444bb3d18aad1ddcd4d0" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                        <fieldset id="feature5f92f9615e374a50a7e1c8c6a51teg33" class=" x-fieldset x-panel-collapsed" style="margin: 10px;">
                                                                                            <legend class="x-fieldset-header x-unselectable" id="wtf-gen6010">
                                                                                                <div class="x-tool x-tool-toggle" id="wtf-gen6014">&nbsp;</div><span class="x-fieldset-header-text" id="wtf-gen6018">Miscellaneous</span></legend>
                                                                                            <div class="x-fieldset-bwrap" id="wtf-gen6011">
                                                                                                <div class="x-fieldset-body" id="wtf-gen6012">
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9600">
                                                                                                        <label for="activity67f013889bb711e4b5cbeca86bft8e9d" style="width:250px; font-weight:bold;" class="x-form-item-label">View Customize Template Logo:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity67f013889bb711e4b5cbeca86bft8e9d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9601">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity67f013889bb711e4b5cbeca86bft8e9d" name="act67f013889bb711e4b5cbeca86bft8e9d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9607">
                                                                                                        <label for="activity67f013889bb711e4b5cbeca86bft9e9d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Upload:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity67f013889bb711e4b5cbeca86bft9e9d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9608">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity67f013889bb711e4b5cbeca86bft9e9d" name="act67f013889bb711e4b5cbeca86bft9e9d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9614">
                                                                                                        <label for="activity67f013889bb711e4b5cbeca86bfu8e9d" style="width:250px; font-weight:bold;" class="x-form-item-label">View Customize PDF Template:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity67f013889bb711e4b5cbeca86bfu8e9d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9615">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity67f013889bb711e4b5cbeca86bfu8e9d" name="act67f013889bb711e4b5cbeca86bfu8e9d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9621">
                                                                                                        <label for="activity67f013889bb711e4b5cbeca86cfr9e9d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Modify:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity67f013889bb711e4b5cbeca86cfr9e9d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9622">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity67f013889bb711e4b5cbeca86cfr9e9d" name="act67f013889bb711e4b5cbeca86cfr9e9d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9628">
                                                                                                        <label for="activity67f013889bb711e4b5cbeda86bfu8e9d" style="width:250px; font-weight:bold;" class="x-form-item-label">View Sales Commission:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity67f013889bb711e4b5cbeda86bfu8e9d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9629">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity67f013889bb711e4b5cbeda86bfu8e9d" name="act67f013889bb711e4b5cbeda86bfu8e9d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9635">
                                                                                                        <label for="activity67f013889bb712e4b5cbeda86bfu8e9d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Modify:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity67f013889bb712e4b5cbeda86bfu8e9d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9636">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity67f013889bb712e4b5cbeda86bfu8e9d" name="act67f013889bb712e4b5cbeda86bfu8e9d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9642">
                                                                                                        <label for="activity67f013889bb713e4b5cbeda86bfu8e9d" style="width:250px; font-weight:bold;" class="x-form-item-label">View Document Templates:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity67f013889bb713e4b5cbeda86bfu8e9d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9643">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity67f013889bb713e4b5cbeda86bfu8e9d" name="act67f013889bb713e4b5cbeda86bfu8e9d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9649">
                                                                                                        <label for="activity67f013889bb714e4b5cbeda86bfu8e9d" style="width:250px; font-weight:bold;" class="x-form-item-label">View Account Revaluation:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity67f013889bb714e4b5cbeda86bfu8e9d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9650">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity67f013889bb714e4b5cbeda86bfu8e9d" name="act67f013889bb714e4b5cbeda86bfu8e9d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9656">
                                                                                                        <label for="activity67f013889bb715e4b5cbeda86bfu8e9d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Post:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity67f013889bb715e4b5cbeda86bfu8e9d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9657">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity67f013889bb715e4b5cbeda86bfu8e9d" name="act67f013889bb715e4b5cbeda86bfu8e9d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9663">
                                                                                                        <label for="activity67f013889bb716e4b5cbeda86bfu8e9d" style="width:250px; font-weight:bold;" class="x-form-item-label">View IBG:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity67f013889bb716e4b5cbeda86bfu8e9d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9664">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity67f013889bb716e4b5cbeda86bfu8e9d" name="act67f013889bb716e4b5cbeda86bfu8e9d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9670">
                                                                                                        <label for="activity67f013889bb717e4b5cbeda86bfu8e9d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Apply:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity67f013889bb717e4b5cbeda86bfu8e9d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9671">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity67f013889bb717e4b5cbeda86bfu8e9d" name="act67f013889bb717e4b5cbeda86bfu8e9d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9677">
                                                                                                        <label for="activity67f013889bb718e4b5cbeda86bfu8e9d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Generate:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity67f013889bb718e4b5cbeda86bfu8e9d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9678">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity67f013889bb718e4b5cbeda86bfu8e9d" name="act67f013889bb718e4b5cbeda86bfu8e9d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9684">
                                                                                                        <label for="activity77f013889bb719e4b5dbeda86bfu8e9d" style="width:250px; font-weight:bold;" class="x-form-item-label">View Check Layout Setup:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity77f013889bb719e4b5dbeda86bfu8e9d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9685">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity77f013889bb719e4b5dbeda86bfu8e9d" name="act77f013889bb719e4b5dbeda86bfu8e9d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9691">
                                                                                                        <label for="activity77f013889bb710f4b5dbeda86rbfu8e9d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Modify:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity77f013889bb710f4b5dbeda86rbfu8e9d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9692">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity77f013889bb710f4b5dbeda86rbfu8e9d" name="act77f013889bb710f4b5dbeda86rbfu8e9d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9698">
                                                                                                        <label for="activity77f013889bb711u4b5dbeda86bfu8e9d" style="width:250px; font-weight:bold;" class="x-form-item-label">Set WIP And CP Accounts Data:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity77f013889bb711u4b5dbeda86bfu8e9d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9699">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity77f013889bb711u4b5dbeda86bfu8e9d" name="act77f013889bb711u4b5dbeda86bfu8e9d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9705">
                                                                                                        <label for="activity77f013889bb712u4b5dbeda86rbfu8e9d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Modify:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity77f013889bb712u4b5dbeda86rbfu8e9d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9706">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity77f013889bb712u4b5dbeda86rbfu8e9d" name="act77f013889bb712u4b5dbeda86rbfu8e9d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9712">
                                                                                                        <label for="activity67f013889bb711e4b54beda86bfu8e9d" style="width:250px; font-weight:bold;" class="x-form-item-label">View UOM Schema:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity67f013889bb711e4b54beda86bfu8e9d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9713">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity67f013889bb711e4b54beda86bfu8e9d" name="act67f013889bb711e4b54beda86bfu8e9d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9719">
                                                                                                        <label for="activity67f013889bb713y4b5cbeda86bfu8e9d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Create:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity67f013889bb713y4b5cbeda86bfu8e9d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9720">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity67f013889bb713y4b5cbeda86bfu8e9d" name="act67f013889bb713y4b5cbeda86bfu8e9d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9726">
                                                                                                        <label for="activity67f013889bb714y4b5cbeda86bfu8e9d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Edit:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity67f013889bb714y4b5cbeda86bfu8e9d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9727">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity67f013889bb714y4b5cbeda86bfu8e9d" name="act67f013889bb714y4b5cbeda86bfu8e9d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9733">
                                                                                                        <label for="activity67f013889bb715y4b5cbeda86bfu8e9d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Delete:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity67f013889bb715y4b5cbeda86bfu8e9d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9734">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity67f013889bb715y4b5cbeda86bfu8e9d" name="act67f013889bb715y4b5cbeda86bfu8e9d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9740">
                                                                                                        <label for="activity67f013889bb716y4b5cbeda86bfu8e9d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Configure:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity67f013889bb716y4b5cbeda86bfu8e9d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9741">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity67f013889bb716y4b5cbeda86bfu8e9d" name="act67f013889bb716y4b5cbeda86bfu8e9d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9747">
                                                                                                        <label for="activity541cb4e9ca8911e797e56045cb6f9ae9" style="padding-left:25px;width:225px;" class="x-form-item-label">...Import:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity541cb4e9ca8911e797e56045cb6f9ae9" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9748">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity541cb4e9ca8911e797e56045cb6f9ae9" name="act541cb4e9ca8911e797e56045cb6f9ae9" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                        <fieldset id="featurea528df089bd711e4bbfeeca86hg8e7d" class=" x-fieldset x-panel-collapsed" style="margin: 10px;">
                                                                                            <legend class="x-fieldset-header x-unselectable" id="wtf-gen6019">
                                                                                                <div class="x-tool x-tool-toggle" id="wtf-gen6023">&nbsp;</div><span class="x-fieldset-header-text" id="wtf-gen6027">Asset Purchase Return</span></legend>
                                                                                            <div class="x-fieldset-bwrap" id="wtf-gen6020">
                                                                                                <div class="x-fieldset-body" id="wtf-gen6021">
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9754">
                                                                                                        <label for="activity0d17ec089bd811e4bbfeeca86bpre8e7d" style="width:250px; font-weight:bold;" class="x-form-item-label">Create Asset Purchase Return:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity0d17ec089bd811e4bbfeeca86bpre8e7d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9755">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity0d17ec089bd811e4bbfeeca86bpre8e7d" name="act0d17ec089bd811e4bbfeeca86bpre8e7d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9761">
                                                                                                        <label for="activity151e5ab89bd811e4bbfeeca89byt8e7d" style="width:250px; font-weight:bold;" class="x-form-item-label">View Asset Purchase Return:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity151e5ab89bd811e4bbfeeca89byt8e7d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9762">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity151e5ab89bd811e4bbfeeca89byt8e7d" name="act151e5ab89bd811e4bbfeeca89byt8e7d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9768">
                                                                                                        <label for="activity1c8a32ea9bd811e4bbfhjca86bff8e7d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Edit:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity1c8a32ea9bd811e4bbfhjca86bff8e7d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9769">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity1c8a32ea9bd811e4bbfhjca86bff8e7d" name="act1c8a32ea9bd811e4bbfhjca86bff8e7d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9775">
                                                                                                        <label for="activity26647c1c9bd811e4bbfsaca86bff8e7d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Delete:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity26647c1c9bd811e4bbfsaca86bff8e7d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9776">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity26647c1c9bd811e4bbfsaca86bff8e7d" name="act26647c1c9bd811e4bbfsaca86bff8e7d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9782">
                                                                                                        <label for="activity2deb44709bd811e4bbfqaca86bff8e7d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Export:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity2deb44709bd811e4bbfqaca86bff8e7d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9783">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity2deb44709bd811e4bbfqaca86bff8e7d" name="act2deb44709bd811e4bbfqaca86bff8e7d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9789">
                                                                                                        <label for="activity371d2db09bd811e4bbfsdca86bff8e7d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Print:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity371d2db09bd811e4bbfsdca86bff8e7d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9790">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity371d2db09bd811e4bbfsdca86bff8e7d" name="act371d2db09bd811e4bbfsdca86bff8e7d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                        <fieldset id="feature3a0cb967a6c14c78603391cce2512f05" class=" x-fieldset x-panel-collapsed" style="margin: 10px;">
                                                                                            <legend class="x-fieldset-header x-unselectable" id="wtf-gen6028">
                                                                                                <div class="x-tool x-tool-toggle" id="wtf-gen6032">&nbsp;</div><span class="x-fieldset-header-text" id="wtf-gen6036">Write Off and Recover Invoices</span></legend>
                                                                                            <div class="x-fieldset-bwrap" id="wtf-gen6029">
                                                                                                <div class="x-fieldset-body" id="wtf-gen6030">
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9796">
                                                                                                        <label for="activity936ce31231712bce96f5fc72e709e8eb" style="width:250px; font-weight:bold;" class="x-form-item-label">Write Off Invoices:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity936ce31231712bce96f5fc72e709e8eb" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9797">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity936ce31231712bce96f5fc72e709e8eb" name="act936ce31231712bce96f5fc72e709e8eb" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9803">
                                                                                                        <label for="activityc29da636c1715fcabda451e24aa31802" style="width:250px; font-weight:bold;" class="x-form-item-label">View Written Off Invoices:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityc29da636c1715fcabda451e24aa31802" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9804">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityc29da636c1715fcabda451e24aa31802" name="actc29da636c1715fcabda451e24aa31802" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9810">
                                                                                                        <label for="activityc29da636c1714fcabda451e24aa31802" style="padding-left:25px;width:225px;" class="x-form-item-label">...Recover Invoices:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityc29da636c1714fcabda451e24aa31802" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9811">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityc29da636c1714fcabda451e24aa31802" name="actc29da636c1714fcabda451e24aa31802" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                        <fieldset id="featurebf7d01fd440f11e6b39514dda97927d6" class=" x-fieldset x-panel-collapsed" style="margin: 10px;">
                                                                                            <legend class="x-fieldset-header x-unselectable" id="wtf-gen6037">
                                                                                                <div class="x-tool x-tool-toggle" id="wtf-gen6041">&nbsp;</div><span class="x-fieldset-header-text" id="wtf-gen6045">Loan Disbursement</span></legend>
                                                                                            <div class="x-fieldset-bwrap" id="wtf-gen6038">
                                                                                                <div class="x-fieldset-body" id="wtf-gen6039">
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9817">
                                                                                                        <label for="activity72521100442011e6b39514dda97927d6" style="width:250px; font-weight:bold;" class="x-form-item-label">Manage Eligibility Rules:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity72521100442011e6b39514dda97927d6" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9818">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity72521100442011e6b39514dda97927d6" name="act72521100442011e6b39514dda97927d6" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9824">
                                                                                                        <label for="activityd2784d8b442011e6b39514dda97927d6" style="padding-left:25px;width:225px;" class="x-form-item-label">...New:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityd2784d8b442011e6b39514dda97927d6" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9825">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityd2784d8b442011e6b39514dda97927d6" name="actd2784d8b442011e6b39514dda97927d6" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9831">
                                                                                                        <label for="activity923f07b2442d11e6b39514dda97927d6" style="padding-left:25px;width:225px;" class="x-form-item-label">...Delete:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity923f07b2442d11e6b39514dda97927d6" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9832">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity923f07b2442d11e6b39514dda97927d6" name="act923f07b2442d11e6b39514dda97927d6" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9838">
                                                                                                        <label for="activitya1f2c15b442d11e6b39514dda97927d6" style="padding-left:25px;width:225px;" class="x-form-item-label">...Submit:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activitya1f2c15b442d11e6b39514dda97927d6" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9839">
                                                                                                                <input type="checkbox" autocomplete="off" id="activitya1f2c15b442d11e6b39514dda97927d6" name="acta1f2c15b442d11e6b39514dda97927d6" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9845">
                                                                                                        <label for="activitya9f1e136442d11e6b39514dda97927d6" style="padding-left:25px;width:225px;" class="x-form-item-label">...Update:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activitya9f1e136442d11e6b39514dda97927d6" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9846">
                                                                                                                <input type="checkbox" autocomplete="off" id="activitya9f1e136442d11e6b39514dda97927d6" name="acta9f1e136442d11e6b39514dda97927d6" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9852">
                                                                                                        <label for="activityb5ed73e9442d11e6b39514dda97927d6" style="width:250px; font-weight:bold;" class="x-form-item-label">Disbursement:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityb5ed73e9442d11e6b39514dda97927d6" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9853">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityb5ed73e9442d11e6b39514dda97927d6" name="actb5ed73e9442d11e6b39514dda97927d6" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9859">
                                                                                                        <label for="activityc958273b442d11e6b39514dda97927d6" style="width:250px; font-weight:bold;" class="x-form-item-label">Disbursement and Repayment Report:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityc958273b442d11e6b39514dda97927d6" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9860">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityc958273b442d11e6b39514dda97927d6" name="actc958273b442d11e6b39514dda97927d6" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9866">
                                                                                                        <label for="activitye0035a77442d11e6b39514dda97927d6" style="padding-left:25px;width:225px;" class="x-form-item-label">...Edit:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activitye0035a77442d11e6b39514dda97927d6" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9867">
                                                                                                                <input type="checkbox" autocomplete="off" id="activitye0035a77442d11e6b39514dda97927d6" name="acte0035a77442d11e6b39514dda97927d6" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9873">
                                                                                                        <label for="activitye9ac94ac442d11e6b39514dda97927d6" style="padding-left:25px;width:225px;" class="x-form-item-label">...Delete:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activitye9ac94ac442d11e6b39514dda97927d6" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9874">
                                                                                                                <input type="checkbox" autocomplete="off" id="activitye9ac94ac442d11e6b39514dda97927d6" name="acte9ac94ac442d11e6b39514dda97927d6" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9880">
                                                                                                        <label for="activityf089197f442d11e6b39514dda97927d6" style="padding-left:25px;width:225px;" class="x-form-item-label">...Repayment Details:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityf089197f442d11e6b39514dda97927d6" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9881">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityf089197f442d11e6b39514dda97927d6" name="actf089197f442d11e6b39514dda97927d6" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                        <fieldset id="featureb66459ce4cce11e6beb89e71128cae77" class=" x-fieldset x-panel-collapsed" style="margin: 10px;">
                                                                                            <legend class="x-fieldset-header x-unselectable" id="wtf-gen6046">
                                                                                                <div class="x-tool x-tool-toggle" id="wtf-gen6050">&nbsp;</div><span class="x-fieldset-header-text" id="wtf-gen6054">Machine Master</span></legend>
                                                                                            <div class="x-fieldset-bwrap" id="wtf-gen6047">
                                                                                                <div class="x-fieldset-body" id="wtf-gen6048">
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9887">
                                                                                                        <label for="activityb6645cc64cce11e6beb89e71128cae77" style="width:250px; font-weight:bold;" class="x-form-item-label">Create :</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityb6645cc64cce11e6beb89e71128cae77" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9888">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityb6645cc64cce11e6beb89e71128cae77" name="actb6645cc64cce11e6beb89e71128cae77" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9894">
                                                                                                        <label for="activityb6645e064cce11e6beb89e71128cae77" style="width:250px; font-weight:bold;" class="x-form-item-label">View :</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityb6645e064cce11e6beb89e71128cae77" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9895">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityb6645e064cce11e6beb89e71128cae77" name="actb6645e064cce11e6beb89e71128cae77" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9901">
                                                                                                        <label for="activityb6645f1e4cce11e6beb89e71128cae77" style="padding-left:25px;width:225px;" class="x-form-item-label">...Modify :</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityb6645f1e4cce11e6beb89e71128cae77" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9902">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityb6645f1e4cce11e6beb89e71128cae77" name="actb6645f1e4cce11e6beb89e71128cae77" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9908">
                                                                                                        <label for="activityb66460224cce11e6beb89e71128cae77" style="padding-left:25px;width:225px;" class="x-form-item-label">...Delete:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityb66460224cce11e6beb89e71128cae77" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9909">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityb66460224cce11e6beb89e71128cae77" name="actb66460224cce11e6beb89e71128cae77" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9915">
                                                                                                        <label for="activityb66461584cce11e6beb89e71128cae77" style="padding-left:25px;width:225px;" class="x-form-item-label">...Export:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityb66461584cce11e6beb89e71128cae77" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9916">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityb66461584cce11e6beb89e71128cae77" name="actb66461584cce11e6beb89e71128cae77" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                        <fieldset id="feature721350624d6f11e6beb89e71128cae77" class=" x-fieldset x-panel-collapsed" style="margin: 10px;">
                                                                                            <legend class="x-fieldset-header x-unselectable" id="wtf-gen6055">
                                                                                                <div class="x-tool x-tool-toggle" id="wtf-gen6059">&nbsp;</div><span class="x-fieldset-header-text" id="wtf-gen6063">Routing Template</span></legend>
                                                                                            <div class="x-fieldset-bwrap" id="wtf-gen6056">
                                                                                                <div class="x-fieldset-body" id="wtf-gen6057">
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9922">
                                                                                                        <label for="activity721352ec4d6f11e6beb89e71128cae77" style="width:250px; font-weight:bold;" class="x-form-item-label">Create :</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity721352ec4d6f11e6beb89e71128cae77" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9923">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity721352ec4d6f11e6beb89e71128cae77" name="act721352ec4d6f11e6beb89e71128cae77" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9929">
                                                                                                        <label for="activity7213574c4d6f11e6beb89e71128cae77" style="width:250px; font-weight:bold;" class="x-form-item-label">View :</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity7213574c4d6f11e6beb89e71128cae77" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9930">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity7213574c4d6f11e6beb89e71128cae77" name="act7213574c4d6f11e6beb89e71128cae77" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9936">
                                                                                                        <label for="activity721358324d6f11e6beb89e71128cae77" style="padding-left:25px;width:225px;" class="x-form-item-label">...Modify :</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity721358324d6f11e6beb89e71128cae77" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9937">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity721358324d6f11e6beb89e71128cae77" name="act721358324d6f11e6beb89e71128cae77" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9943">
                                                                                                        <label for="activity721359cc4d6f11e6beb89e71128cae77" style="padding-left:25px;width:225px;" class="x-form-item-label">...Delete:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity721359cc4d6f11e6beb89e71128cae77" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9944">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity721359cc4d6f11e6beb89e71128cae77" name="act721359cc4d6f11e6beb89e71128cae77" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9950">
                                                                                                        <label for="activity72135a8a4d6f11e6beb89e71128cae77" style="padding-left:25px;width:225px;" class="x-form-item-label">...Export:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity72135a8a4d6f11e6beb89e71128cae77" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9951">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity72135a8a4d6f11e6beb89e71128cae77" name="act72135a8a4d6f11e6beb89e71128cae77" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                        <fieldset id="featureb6c966e0114a456da40d4fbffa3806ab" class=" x-fieldset x-panel-collapsed" style="margin: 10px;">
                                                                                            <legend class="x-fieldset-header x-unselectable" id="wtf-gen6064">
                                                                                                <div class="x-tool x-tool-toggle" id="wtf-gen6068">&nbsp;</div><span class="x-fieldset-header-text" id="wtf-gen6072">Work Order </span></legend>
                                                                                            <div class="x-fieldset-bwrap" id="wtf-gen6065">
                                                                                                <div class="x-fieldset-body" id="wtf-gen6066">
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9957">
                                                                                                        <label for="activity2e70f7a180c3439cb4f80902759eb636" style="width:250px; font-weight:bold;" class="x-form-item-label">Create :</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity2e70f7a180c3439cb4f80902759eb636" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9958">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity2e70f7a180c3439cb4f80902759eb636" name="act2e70f7a180c3439cb4f80902759eb636" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9964">
                                                                                                        <label for="activity3e16b7a164ac477fa2485a2bf5dc40b1" style="width:250px; font-weight:bold;" class="x-form-item-label">View :</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity3e16b7a164ac477fa2485a2bf5dc40b1" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9965">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity3e16b7a164ac477fa2485a2bf5dc40b1" name="act3e16b7a164ac477fa2485a2bf5dc40b1" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9971">
                                                                                                        <label for="activity289fceba477740199d266585a0a26031" style="padding-left:25px;width:225px;" class="x-form-item-label">...Modify :</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity289fceba477740199d266585a0a26031" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9972">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity289fceba477740199d266585a0a26031" name="act289fceba477740199d266585a0a26031" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9978">
                                                                                                        <label for="activityd1ab7d33ac3c4f5ea63fdf461c4f091d" style="padding-left:25px;width:225px;" class="x-form-item-label">...Start:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityd1ab7d33ac3c4f5ea63fdf461c4f091d" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9979">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityd1ab7d33ac3c4f5ea63fdf461c4f091d" name="actd1ab7d33ac3c4f5ea63fdf461c4f091d" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9985">
                                                                                                        <label for="activityaa48490e3722464a97bc3dbc776b23c5" style="padding-left:25px;width:225px;" class="x-form-item-label">...Close:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activityaa48490e3722464a97bc3dbc776b23c5" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9986">
                                                                                                                <input type="checkbox" autocomplete="off" id="activityaa48490e3722464a97bc3dbc776b23c5" name="actaa48490e3722464a97bc3dbc776b23c5" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9992">
                                                                                                        <label for="activity69b4497212c440a5895089fe3bdcc481" style="padding-left:25px;width:225px;" class="x-form-item-label">...Delete:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity69b4497212c440a5895089fe3bdcc481" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen9993">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity69b4497212c440a5895089fe3bdcc481" name="act69b4497212c440a5895089fe3bdcc481" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen9999">
                                                                                                        <label for="activity630676219e374b258634682facc0c844" style="padding-left:25px;width:225px;" class="x-form-item-label">...Export:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity630676219e374b258634682facc0c844" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen10000">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity630676219e374b258634682facc0c844" name="act630676219e374b258634682facc0c844" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                        <fieldset id="featureec85493ed63711e6acd414dda97926e5" class=" x-fieldset x-panel-collapsed" style="margin: 10px;">
                                                                                            <legend class="x-fieldset-header x-unselectable" id="wtf-gen6073">
                                                                                                <div class="x-tool x-tool-toggle" id="wtf-gen6077">&nbsp;</div><span class="x-fieldset-header-text" id="wtf-gen6081">Unit Price And Amount</span></legend>
                                                                                            <div class="x-fieldset-bwrap" id="wtf-gen6074">
                                                                                                <div class="x-fieldset-body" id="wtf-gen6075">
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen10006">
                                                                                                        <label for="activity4b2c775bd64a11e6acd414dda97926e5" style="width:250px; font-weight:bold;" class="x-form-item-label">Display Unit Price &amp; Amount in Purchase Document:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity4b2c775bd64a11e6acd414dda97926e5" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen10007">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity4b2c775bd64a11e6acd414dda97926e5" name="act4b2c775bd64a11e6acd414dda97926e5" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen10013">
                                                                                                        <label for="activity54c485bad64a11e6acd414dda97926e5" style="width:250px; font-weight:bold;" class="x-form-item-label">Display Unit Price &amp; Amount in Sales Document:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity54c485bad64a11e6acd414dda97926e5" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen10014">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity54c485bad64a11e6acd414dda97926e5" name="act54c485bad64a11e6acd414dda97926e5" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                        <fieldset id="feature69cef2f2519211e7a2b0708bcdaa138a" class=" x-fieldset x-panel-collapsed" style="margin: 10px;">
                                                                                            <legend class="x-fieldset-header x-unselectable" id="wtf-gen6082">
                                                                                                <div class="x-tool x-tool-toggle" id="wtf-gen6086">&nbsp;</div><span class="x-fieldset-header-text" id="wtf-gen6090">Discount Master</span></legend>
                                                                                            <div class="x-fieldset-bwrap" id="wtf-gen6083">
                                                                                                <div class="x-fieldset-body" id="wtf-gen6084">
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen10020">
                                                                                                        <label for="activity9b992658519211e7a2b0708bcdaa138a" style="width:250px; font-weight:bold;" class="x-form-item-label">Discount Master Menu:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activity9b992658519211e7a2b0708bcdaa138a" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen10021">
                                                                                                                <input type="checkbox" autocomplete="off" id="activity9b992658519211e7a2b0708bcdaa138a" name="act9b992658519211e7a2b0708bcdaa138a" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                    <div class="x-form-item " tabindex="-1" id="wtf-gen10027">
                                                                                                        <label for="activitybfd87f22519211e7a2b0708bcdaa138a" style="padding-left:25px;width:225px;" class="x-form-item-label">...Add Discount Master:</label>
                                                                                                        <div class="x-form-element" id="x-form-el-activitybfd87f22519211e7a2b0708bcdaa138a" style="">
                                                                                                            <div class="x-form-check-wrap" id="wtf-gen10028">
                                                                                                                <input type="checkbox" autocomplete="off" id="activitybfd87f22519211e7a2b0708bcdaa138a" name="actbfd87f22519211e7a2b0708bcdaa138a" class=" x-form-checkbox x-form-field">
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="x-form-clear-left"></div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </fieldset>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div class="x-clear" id="wtf-gen935"></div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="x-window-bl">
        <div class="x-window-br">
            <div class="x-window-bc">
                <div class="x-window-footer" id="wtf-gen847">
                    <div class="x-panel-btns-ct">
                        <div class="x-panel-btns x-panel-btns-right">
                            <table cellspacing="0">
                                <tbody>
                                    <tr>
                                        <td class="x-panel-btn-td" id="wtf-gen850">
                                            <table border="0" cellpadding="0" cellspacing="0" class="x-btn-wrap x-btn" id="wtf-comp-1106" style="width: 75px;">
                                                <tbody>
                                                    <tr>
                                                        <td class="x-btn-left"><i>&nbsp;</i></td>
                                                        <td class="x-btn-center"><em unselectable="on"><button class="x-btn-text" type="button" id="wtf-gen852">Reset</button></em></td>
                                                        <td class="x-btn-right"><i>&nbsp;</i></td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </td>
                                        <td class="x-panel-btn-td" id="wtf-gen858">
                                            <table border="0" cellpadding="0" cellspacing="0" class="x-btn-wrap x-btn" id="wtf-comp-1107" style="width: 75px;">
                                                <tbody>
                                                    <tr>
                                                        <td class="x-btn-left"><i>&nbsp;</i></td>
                                                        <td class="x-btn-center"><em unselectable="on"><button class="x-btn-text" type="button" id="wtf-gen860">Apply</button></em></td>
                                                        <td class="x-btn-right"><i>&nbsp;</i></td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </td>
                                        <td class="x-panel-btn-td" id="wtf-gen866">
                                            <table border="0" cellpadding="0" cellspacing="0" class="x-btn-wrap x-btn" id="wtf-comp-1108" style="width: 75px;">
                                                <tbody>
                                                    <tr>
                                                        <td class="x-btn-left"><i>&nbsp;</i></td>
                                                        <td class="x-btn-center"><em unselectable="on"><button class="x-btn-text" type="button" id="wtf-gen868">Close</button></em></td>
                                                        <td class="x-btn-right"><i>&nbsp;</i></td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                            <div class="x-clear"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>