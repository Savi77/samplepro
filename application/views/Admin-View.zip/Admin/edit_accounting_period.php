<script type="text/javascript" src="<?= base_url() ?>assets/admin/assets/js/pages/form_layouts.js"></script>
<script type="text/javascript" src="<?= base_url() ?>assets/admin/assets/js/plugins/forms/styling/uniform.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/js/bootstrap-datetimepicker.min.js"></script>
<script type="text/javascript" src="<?= base_url() ?>assets/admin/assets/js/plugins/pickers/daterangepicker.js"></script>

<?php foreach ($editAccountingPeriod->result() as $value) {

    if ($value->start_date != '') {
        $start_date = date("d F, Y", strtotime($value->start_date));
    } else {
        $start_date = '';
    }

    if ($value->end_date != '') {
        $end_date = date("d F, Y", strtotime($value->end_date));
    } else {
        $end_date = '';
    }
?>
    <form class="form-horizontal" id="EditGroup" >
        <fieldset>
            <div class="row">
                <input type="hidden" name="edit_id" id="edit_id" value="<?= $value->period_id; ?>">
                <div class="col-md-6" style="padding: 0px 20px;">
                    <div class="form-group">
                        <label>Period Name :</label>
                        <input type="text" name="period_name_edit" id="period_name_edit" placeholder="Period Name" class="form-control" value="<?= $value->period_name?>" required>
                    </div>
                </div>
                <div class="col-md-6" style="padding: 0px 20px;">
                    <div class="form-group">
                        <label>Short Year :</label>
                        <input type="text" name="short_year" placeholder="Short Year" class="form-control" value="<?= $value->short_year?>">
                    </div>
                </div>
                <div class="col-md-6" style="padding: 0px 20px;">
                    <div class="form-group">
                        <label>Start Date :</label>
                        <input type="text" class="form-control" name="start_date_edit" id="start_date_edit" placeholder="Please select start date" autocomplete="off" value="<?= $start_date?>" required>
                    </div>
                </div>
                <div class="col-md-6" style="padding: 0px 20px;">
                    <div class="form-group">
                        <label>End Date :</label>
                        <input type="text" class="form-control" name="end_date_edit" id="end_date_edit" placeholder="Please select end date" autocomplete="off" value="<?= $end_date?>" required> 
                    </div>
                </div>
            </div>
            <br />
            <div class="row mr-1" style="float: right;">
                <div class="text-right">
                    <button type="submit" class="btn btn-primary">Update Details <i class="icon-arrow-right14 position-right"></i></button>
                </div>
            </div>
        </fieldset>
    </form>

<?php } ?>


<script type="text/javascript">
	// $(function() {
		$('#start_date_edit').datetimepicker({
			format: 'DD MMMM, YYYY',
			// useCurrent: true
		});
		$('#end_date_edit').datetimepicker({
			format: 'DD MMMM, YYYY',
			// useCurrent: true
		});
	// });
</script>

<script type="text/javascript">
    $("#EditGroup").on('submit', (function(e) {
        //e.preventDefault();
        if (e.isDefaultPrevented()) {
            //alert('invalid');
            return false;
        } else {
            // alert('test');  
            $.ajax({
                url: "<?php echo site_url('admin/dashboard/EditAccountingPeriod'); ?>",
                type: "POST",
                data: new FormData(this),
                contentType: false,
                cache: false,
                processData: false,
                success: function(data) {
                    PNotify.removeAll()
                    // alert(data);

                    // $(function() {
                        new PNotify({
                            title: 'Edit Form',
                            text: 'Updated  Successfully',
                            type: 'success'
                        });
                    // });

                    setTimeout(function() {
                        window.location = "<?php echo site_url('admin/dashboard/CompanySetting'); ?>";
                    }, 300);


                },
                error: function() {
                    alert('fail');
                }
            });
        }
        return false;

    }));
</script>

<script type="text/javascript">
    /* $(document).ready(function() {
        $('#EditGroup').bootstrapValidator({
            message: 'This value is not valid',
            fields: {
                period_name_edit: {
                    validators: {
                        notEmpty: {
                            message: 'Please Enter Period Name'
                        }
                    }
                },
                start_date_edit: {
                    validators: {
                        notEmpty: {
                            message: 'Please Enter Start Date'
                        }
                    }
                },
                end_date_edit: {
                    validators: {
                        notEmpty: {
                            message: 'Please Enter End Date'
                        }
                    }
                },
            }
        });
    }); */
</script>