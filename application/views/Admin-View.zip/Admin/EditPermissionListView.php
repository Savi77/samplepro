
<link href="<?= base_url() ?>assets/admin/assets/css/components.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="<?= base_url() ?>assets/admin/assets/js/pages/form_layouts.js"></script>
<script type="text/javascript" src="<?= base_url() ?>assets/admin/assets/js/plugins/forms/styling/uniform.min.js"></script>
<form method="post" id="EditRoelPermissionForm" action="<?php echo site_url('admin/UserPermission/EditRolePermission'); ?>">
    <input type="hidden" name="role_id" id="role_id" value="<?= $role_data->role_id; ?>">
    <fieldset>
        <div class="col-md-6">
            <div class="form-group">
                <label>Role : <sup style="color: red">*</sup></label>
                <div class="">
                    <input type="text" name="role" id="role" class="form-control" placeholder="Role" value="<?= $role_data->role_name; ?>">
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="form-group">
                <label>Role Description : <sup style="color: red">*</sup></label>
                <div class="">
                    <textarea name="role_description" id="role_description" class="form-control" rows="3" placeholder="Role Description"><?= $role_data->role_description; ?></textarea>
                </div>
            </div>
        </div>
    </fieldset>
    <div class="table-responsive" style="border: 2px solid #bb9c9c8c;">
        <table class="table">
        <tbody>
            <?php
                $i=1;
                foreach ($feature_list as $row)
                    {
                    $collapse="demo".$i;
                    $privilege=$row['privilege'];
                    $component_id=$row['component_id'];
                ?>
                        <tr>
                        <td style="width: 25%;background-color: #f3f3f3;border-right: 2px solid #ded4d4 !important;"><b><?= $row['component_title']; ?></b></td>
                        <td style="width: 75%;">   
                            <div class="form-group">
                                <div class="row">
                                <?php
                                    $checkbox=1;
                                    foreach ($privilege as  $row) 
                                    {
                                    $custom_id=$component_id.'/'.$row['privilege_id'];
                                    $checkbox=$row['checkbox'];
                                    ?>
                                    <div class="col-md-2">                                   
                                            <div class="checkbox">
                                                <label>
                                                    <input type="checkbox" name="feature_ids[]" class="styled" value="<?=$custom_id; ?>"  <?= $checkbox; ?>>
                                                    <?= $row['privilege'];  ?>                                           
                                                </label>
                                            </div>
                                    </div>  
                                    <?php
                                    $checkbox++;
                                    }
                                    ?>
                                </div>
                            </div>


                        </td>
                        </tr>
                <?php 
                $i++;} ?>

            </tbody>
        </table>
    </div>
    <div class="text-right">
        <br/>
        <button type="submit" class="btn btn-primary">Update <i class="icon-arrow-right14 position-right"></i></button>
        <span id="preview44"></span>
    </div>  
</form>

<script>
$(document).ready(function(e) {
    $("#EditRoelPermissionForm").on('submit', (function(e) {
        //e.preventDefault();
        if (e.isDefaultPrevented()) {
            //alert('invalid');
        } else {
            $("#preview44").show();
            $("#preview44").html('<img src="<?= base_url() ?>assets/images/default.gif" style="height:30px;width:30px;" />');
            $('#submitBtn').prop('disabled', true);
            $.ajax({
                url: "<?php echo site_url('admin/UserPermission/EditRolePermission'); ?>",
                type: "POST",
                data: new FormData(this),
                contentType: false,
                cache: false,
                processData: false,
                success: function(data) {
                    $("#preview44").hide();
                    $('#submitBtn').removeAttr('disabled');
                    $(function() {
                        new PNotify({
                            title: 'Assign Module Permission',
                            text: 'Permission Set Successfully',
                            type: 'success'
                        });
                    });

                    setTimeout(function() {
                        window.location = "<?php echo site_url('admin/UserPermission/PermissionRole'); ?>";
                    }, 2000);
                },
                error: function() {
                    alert('fail');
                }
            });

        }
        return false;
    }));
});
</script>

