

  <?php 

  foreach ($edit_data as $row) 
  {

  ?>
        <form  id="editform" method="post">
          <input type="hidden" name="term_id" value="<?= $row->term_id;?>">
          <div class="panel panel-flat">
            <div class="panel-body">
                <fieldset>
                  <div class="row">
                      <div class="col-md-12"> 
                        <div class="form-group">
                           <label>Term For : <sup style="color: red">*</sup></label>
                          <input type="text" name="term_for" class="form-control" placeholder="E.g. Tally" value="<?= $row->term_for ?>">
                        </div>
                      </div>          
                  </div>
                </fieldset>
                <fieldset>
               <div class="row">
                 <legend class="text-semibold">Terms | Conditions : <sup style="color: red">*</sup>
                    <button class="btn btn-success  position-right"  style="float: right;    margin-top: -7px;" type="button"  onclick="edit_education_fields();" > <span class="glyphicon glyphicon-plus" aria-hidden="true"></span> </button>
                 </legend>


                 <div class="col-md-12"> 
                     <?php
                        $cc=43;
                        $terms=explode("$^", $row->term_condition);
                        for($i=1;$i<count($terms);$i++)
                        {
                      ?>
                       <div class="row removeclass2<?=$cc;?>"> 
                          <div class="col-md-12 nopadding">
                            <div class="form-group">
                              <div class="input-group">
                               <textarea rows="1" name="terms[]"  class="form-control" ><?= $terms[$i];?></textarea>
                                <div class="input-group-btn">
                                  <button class="btn btn-danger" type="button"  onclick="edit_remove_education_fields(this.id);" id="<?=$cc?>"> <span class="glyphicon glyphicon-minus" aria-hidden="true"></span> </button>
                                </div>
                              </div>
                            </div>
                          </div>
                          <div class="clear"></div>
                       </div>     
                     <?php $cc++; } ?>   
                  </div>
                  <div class="col-md-12"> 
                      <div id="edit_education_fields"></div>  
                  </div>
                </div>

                </fieldset>                                                
             <br/>
            <div class="text-right">
            <button type="submit" class="btn btn-primary">Update<i class="icon-arrow-right14 position-right"></i></button>
            <span id="preview_edit"></span>
          </div>  
        </div>
      </div>
    </form>

<?php } ?>



    <script type="text/javascript">
      var edit_room = 512;
      function edit_education_fields() 
      {
          edit_room++;
          var objTo = document.getElementById('edit_education_fields')
          var divtest = document.createElement("div");
          divtest.setAttribute("class", "form-group removeclass2"+edit_room);
          var rdiv = 'removeclass2'+edit_room;
          divtest.innerHTML = '<div class="row"> <div class="col-md-12 nopadding"><div class="form-group"><div class="input-group"> <textarea class="form-control" name="terms[]" rows="1"></textarea> <div class="input-group-btn"> <button class="btn btn-danger" type="button" onclick="edit_remove_education_fields('+ edit_room +');"> <span class="glyphicon glyphicon-minus" aria-hidden="true"></span> </button></div></div></div></div><div class="clear"></div></div>';        
          objTo.appendChild(divtest)
           
           $('#editform').bootstrapValidator('addField', 'terms[]');
        }

         function edit_remove_education_fields(rid) 
         {
          alert(rid);
           $('.removeclass2'+rid).remove();
         }
    </script>




    <script>
    $(document).ready(function() {
            termsvalidator = {
                row: '.col-md-12',
                validators: {
                              notEmpty: {
                                  message: 'Term | Condition is required'
                              }
                }
            },
           $('#editform')
            .bootstrapValidator({
                framework: 'bootstrap',
                icon: {
                    valid: 'glyphicon glyphicon-ok',
                    invalid: 'glyphicon glyphicon-remove',
                    validating: 'glyphicon glyphicon-refresh'
                },

                fields: {
                    'terms[]': termsvalidator,
                    term_for:{
                        validators: {
                            notEmpty: {
                                        message: 'Terms for is required'
                                    }
                              }
                       },  
                }
            })
            // Add button click handler
            .on('click', '.addButton', function()
             {
              })
            // Remove button click handler
            .on('click', '.removeButton', function() 
            {
            });
    });
    </script>
    

<script type="text/javascript">
  $(document).ready(function (e)
     {

       $("#editform").on('submit',(function(e)
           {  
             //e.preventDefault();
             if (e.isDefaultPrevented())
              {
                //alert('invalid');
              }
              else
              {
                $("#preview_edit").html('<img src="<?= base_url() ?>assets/images/default.gif" style="height:30px;width:30px;" alt="sending data...."/>');
                $("#preview_edit").show();      

                  $.ajax({
                    url: "<?php echo site_url('admin/TermConditions/Update'); ?>",
                    type: "POST",
                    data:  new FormData(this),
                    contentType: false,
                    cache: false,
                    processData:false,
                    success: function(data)
                      {
                          $("#preview_edit").hide(); 
                          $(function(){
                           new PNotify({
                                        title: 'Update  Term | Condition',
                                        text: 'Updated Successfully !!',
                                        type: 'success'
                                       });
                          });
                           setTimeout(function()
                             {
                                 window.location="<?php echo site_url('admin/TermConditions');?>";
                             }, 1000);
                      },
                      error: function() 
                      {
                        alert('fail');
                      }           
                   });
              }
              return false;
          
          }));
      });
</script>


