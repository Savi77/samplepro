<script type="text/javascript" src="<?= base_url() ?>assets/admin/assets/js/plugins/forms/selects/select2.min.js"></script>
<style>
    .select2-container .select2-search--inline .select2-search__field {
        background: #0000;
        border: none;
        outline: 0;
        box-shadow: none;
        -webkit-appearance: textfield;
        width: 100% !important;
    }
</style>
<div class="panel-flat">
    <div class="row">
        <div class="col-md-12">
            <form class="form-horizontal" id="addReminderContact" method="POST"> 
                <input type="hidden" name="recd_id" id="recd_id" value="<?= $customerId ?>">
                <input type="hidden" name="module_name" id="module_name" value="Contact">
                <div class="row">
                    <div class="form-group">
                        <label class="control-label col-sm-4" for="email">Reminder Title <span style="color: red;">*</span></label>
                        <div class="col-sm-8">
                            <input type="text" class="form-control" id="reminder_title" name="reminder_title" placeholder="Enter Reminder Title" maxlength="50" >
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="control-label col-sm-4" for="email">Reminder Date<span style="color: red;">*</span></label>
                        <div class="col-sm-8">
                            <div class="input-group date">
                                <span class="input-group-addon"><i class="icon-calendar"></i></span>
                                <input type="text" class="form-control schedule_date_select" id="edit_reminder_date" name="reminder_date" value="<?= date('d M Y') ?>" placeholder="Enter Reminder Date" autocomplete="off">
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-sm-4" for="email">Reminder Time <span style="color: red;">*</span></label>
                        <div class="col-sm-8 clockpicker" data-placement="left" data-align="top" data-autoclose="true">
                            <div class="input-group date">
                                <span class="input-group-addon"><i class="icon-watch2"></i></span>
                                <input type="text" class="form-control" id="reminder_time" name="reminder_time" placeholder="Please select Reminder Time" autocomplete="off" >
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="control-label col-sm-4" for="email">User </label>
                        <div class="col-sm-8">
                            <select class="form-control" name="user_id[]" id="edit_rmd_user_id" multiple>
                                <option value="">Select Company</option>
                                <?php   foreach ($getUserSysyemList as $value1) {   ?>
                                    <option value="<?= $value1->id ?>"><?= $value1->name ?></option>
                                <?php   }    ?>
                            </select>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-sm-4" for="email">Reminder Before Time <span style="color: red;">*</span></label>
                        <div class="col-sm-8">
                            <select class="form-control" name="reminder_before_time" id="reminder_before_time">
                                <option value="">Select Company</option>
                                <?php foreach ($getTimeSlot as $value) { ?>
                                    <option value="<?= $value->time_slot ?>"><?= $value->time_slot ?></option>
                                <?php  } ?>
                            </select>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="control-label col-sm-4" for="email">Notes <span style="color: red;">*</span></label>
                        <div class="col-sm-8">
                            <textarea class="form-control" rows="2" id="reminder_note" name="reminder_note" placeholder="Enter Comments" maxlength="500"></textarea>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-sm-4" for="email">Recurring <span style="color: red;">*</span></label>
                        <div class="col-sm-8">
                            <select class="form-control" name="recurring_set" id="recurring_set" onchange="showDataRecurring(this.value)">
                                <option value="">Select Recurring</option>
                                <option value="0">No</option>
                                <option value="1">Yes</option>
                            </select>
                        </div>
                    </div>
                    <div id="recuuringData" style="display: none;clear:both">
                        <div class="form-group">
                            <label class="control-label col-sm-4" for="email">Recurring Interval </label>
                            <div class="col-sm-8">
                                <select class="form-control" name="interval_type" id="interval_type">
                                    <option value="">Select Recurring Interval</option>
                                    <option value="day">Day</option>
                                    <option value="week">Week</option>
                                    <option value="fortnightly">Fortnightly</option>
                                    <option value="monthly">Monthly</option>
                                    <option value="quaterly">Quaterly</option>
                                    <option value="half-quarterly">Half Quarterly</option>
                                    <option value="year">Year</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-sm-4" for="email">Recurring EOD</label>
                            <div class="col-sm-8">
                                <input type="text" class="form-control" id="add_recurring_eod" name="recurring_eod" placeholder="Enter Recurring EOD" autocomplete="off">
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-md-offset-2 col-md-10">
                            <button type="submit" class="btn btn-primary  pull-right">Submit&nbsp;<i class="icon-arrow-right14 position-right"></i> </button>
                            <span id="preview"></span>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<script type="text/javascript">
    $(document).ready(function(){
        $('#add_recurring_eod').datetimepicker({
            format: 'DD MMMM, YYYY',
            useCurrent: true,
        });
    }); 
    function showDataRecurring(id){
        if(id == 1){
            $('#recuuringData').show();
        }else{
            $('#recuuringData').hide();
        }
    }
    $(document).ready(function() {
        $("#edit_rmd_user_id").select2({
            dropdownParent: $("#reminder_model")
        });
    });

    $('#add_recurring_eod').change(function() {
        $('#addReminderContact').bootstrapValidator('revalidateField', 'add_recurring_eod');
    });

    $('#edit_reminder_date').change(function() {
        $('#addReminderContact').bootstrapValidator('revalidateField', 'edit_reminder_date');
    });

    $('#reminder_time').change(function() {
        $('#addReminderContact').bootstrapValidator('revalidateField', 'reminder_time');
    });

    $(document).ready(function() {
        $('#edit_reminder_date').datetimepicker({
            format: 'DD MMMM, YYYY',
            useCurrent: true,
        });
        $('.clockpicker').clockpicker({
            placement: 'left',
            align: 'left',
            donetext: 'Done',
            minTime: '12:00'
        });
    });

    $(document).ready(function() {
        $('#addReminderContact').bootstrapValidator({
            message: 'This value is not valid',
            fields: {
                reminder_date: {
                    validators: {
                        notEmpty: {
                            message: 'Please Enter Reminder Date'
                        }
                    }
                },
                reminder_time: {
                    validators: {
                        notEmpty: {
                            message: 'Please Enter Reminder Time'
                        }
                    }
                },
                reminder_title: {
                    validators: {
                        notEmpty: {
                            message: 'Please Enter Reminder Title'
                        }
                    }
                }
            }
        });
    });
</script>

<script type="text/javascript">
    $(document).ready(function(e) {
        $("#addReminderContact").on('submit', (function(e) {
            //e.preventDefault();
            if (e.isDefaultPrevented()) {
                // alert('invalids');
            } else {
                $("#preview").show();
                $("#preview").html('<img src="<?= base_url() ?>assets/images/default.gif" style="height:30px;width:30px;" />');

                $.ajax({
                    url: "<?php echo site_url('admin/Customer/addCustomerReminder'); ?>",
                    type: "POST",
                    data: new FormData(this),
                    contentType: false,
                    cache: false,
                    processData: false,
                    success: function(data) {
                        $("#preview").hide();
                        
                        $(function() {
                            new PNotify({
                                title: 'Reminder Form',
                                text: 'Added Successfully',
                                type: 'success'
                            });
                        });

                        setTimeout(function() {
                            window.location = "<?php echo site_url('admin/Reminder'); ?>";
                        }, 1000);


                    },
                    error: function() {
                        alert('fail');
                    }
                });
            }
            return false;

        }));
    });
</script>