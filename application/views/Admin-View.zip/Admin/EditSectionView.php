<!-- include summernote css/js -->
<link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.js"></script>

<?php   foreach ($getData as $row) {    ?>
    <form id="editform" method="post">
        <input type="hidden" name="section_id" id="section_id" value="<?= $row['section_id']; ?>">
        <div class="panel panel-flat">
            <div class="panel-body">
                <fieldset>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group">
                                <label>Section For : <sup style="color: red">*</sup></label>
                                <input type="text" name="section_name" id="section_name" class="form-control" placeholder="E.g. Section 1" value="<?= $row['section_name']; ?>">
                                <span id="error_section_name" style="color: red;font-size:13px"></span>
                            </div>
                        </div>
                    </div>
                </fieldset>
                <fieldset>
                    <label>Section : <sup style="color: red">*</sup></label>
                    <div class="row">
                        <div class="col-md-12">
                            <textarea rows="1" name="section_content" id="section_content_edit" class="form-control"><?= $row['section_content']; ?></textarea>
                            <span id="error_section" style="color: red;font-size:13px"></span>
                        </div>
                    </div>
                </fieldset>
                <br />
                <div class="row float-right">
                    <button type="submit" class="btn btn-primary  pull-right">Submit&nbsp;<i class="icon-arrow-right14 position-right"></i><span id="preview"></span></button>
                    <span id="preview_upload"></span>
                </div>
            </div>
        </div>
    </form>
<?php } ?>

<script type="text/javascript">
    $(document).ready(function(){
        $('#section_content_edit').summernote();
    });

    $(document).ready(function(e) {

        $("#editform").on('submit', (function(e) {
            //e.preventDefault();
            if (e.isDefaultPrevented()) {
                //alert('invalid');
            } else {
                $("#preview_edit").html('<img src="<?= base_url() ?>assets/images/default.gif" style="height:30px;width:30px;" alt="sending data...."/>');
                $("#preview_edit").show();

                $.ajax({
                    url: "<?php echo site_url('admin/Settings/Update'); ?>",
                    type: "POST",
                    data: new FormData(this),
                    contentType: false,
                    cache: false,
                    processData: false,
                    success: function(data) {
                        $("#preview_edit").hide();
                        $(function() {
                            new PNotify({
                                title: 'Update  Section',
                                text: 'Updated Successfully !!',
                                type: 'success'
                            });
                        });
                        setTimeout(function() {
                            window.location = "<?php echo site_url('admin/dashboard/CompanySetting'); ?>";
                        }, 1000);
                    },
                    error: function() {
                        alert('fail');
                    }
                });
            }
            return false;

        }));
    });
</script>
