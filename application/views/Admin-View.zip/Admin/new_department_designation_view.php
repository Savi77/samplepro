<!DOCTYPE html>
<html lang="en">

<?php $this->load->view('Admin/includes/n-header') ?>
<style>
    .btn-group, .btn-group-vertical {
        width: 100% !important;
    }
</style>
<body>
    <!-- BEGIN LOADER -->
    <div id="load_screen">
        <div class="loader">
            <div class="loader-content">
                <div class="spinner-grow align-self-center"></div>
            </div>
        </div>
    </div>
    <!--  END LOADER -->

    <!--  BEGIN NAVBAR  -->
    <?php $this->load->view('Admin/includes/n-web-sidebar') ?>
    <!--  END NAVBAR  -->

    <!--  BEGIN MAIN CONTAINER  -->
    <div class="main-container" id="container">

        <div class="overlay"></div>
        <div class="search-overlay"></div>

        <!--  BEGIN Mobile SIDEBAR  -->
        <?php $this->load->view('Admin/includes/n-mobile-sidebar') ?>
        <!--  END Mobile SIDEBAR  -->

        <!--  BEGIN CONTENT AREA  -->
        <div id="content" class="main-content">
            <div class="layout-px-spacing">
                <div class="row">
                    <?php $this->load->view('Admin/includes/n-panel') ?>
                </div>
                <div class="row mt-3">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 layout-spacing company-management pl-0 pr-0 pt-3">
                        <figure>
                            <a href="#" data-toggle="modal" data-target="#interest_model" style="display: grid;">
                                <img class="contact-img" src="<?= base_url() ?>assets/assets/img/add.png">
                            </a>
                        </figure>
                    </div>
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 layout-spacing pl-0 pr-0">
                        <div class="widget-two">
                            <div class="widget-content blue">
                                <div class="w-numeric-value cs1">
                                    <div class="w-content contact blue">
                                        <span class="w-value cs2"><?= strtoupper ('Department / Designation')?></span>
                                    </div>
                                </div>
                            </div>
                            <div class="row row mt-3 ml-2 mr-2">
                                <div class="table-responsive">
                                    <table class="table table-striped" id="DepDesTable">
                                        <thead>
                                            <tr>
												<th>#</th>
												<th>Department</th>
												<th>Designation</th>
												<th class="text-center" >Action</th>
											</tr>
                                        </thead>
                                        <tbody>
											<?php
												$count = 1;
												foreach ($get_data as $row) { 
											?>
												<tr>
													<td><?php echo $count ?></td>
													<td><?= $row->department_name ?></td>
													<td><?= $row->designation_name ?></td>
													<td class="text-center">
														<ul class="icons-list ml-5" style="display: flex;">
                                                            <li>
                                                                <a class="ml-2" data-toggle="modal" onclick="edit_client(<?= $row->dep_id; ?>,<?= $row->deg_id; ?>)")" >
                                                                    <span class="label bg-success" style="line-height: 20px;border-radius: 4px;cursor: pointer;">
                                                                        <i class="fa fa-edit text-white" style="font-size: 12px;" data-toggle="tooltip" title="Edit" data-placement="top"></i>
                                                                    </span>
                                                                </a>
                                                            </li>
                                                            <li>
                                                                <a class="ml-2" data-toggle="modal" onclick="del_client(<?= $row->dep_id; ?>,<?= $row->deg_id; ?>)")" >
                                                                    <span class="label bg-danger" style="line-height: 20px;border-radius: 4px;cursor: pointer;">
                                                                        <i class="fa fa-trash text-white" style="font-size: 12px;" data-toggle="tooltip" title="Delete" data-placement="top"></i>
                                                                    </span>
                                                                </a>
                                                            </li>
                                                        </ul>
													</td>
												</tr>
											<?php $count++; } ?>
										</tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div id="interest_model" class="modal fade" data-keyboard="false" data-backdrop="static">
			<div class="modal-dialog modal-lg">
				<div class="modal-content">
					<div class="modal-header bg-info" style="background-color:#009FDF;">
						<h6 class="modal-title text-white"><i class="icon-office position-left"></i>&nbsp;&nbsp; Add Department / Designation</h6>
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
					</div>

					<div class="modal-body">
						<form class="form-horizontal" id="TypeForm">
                            <div class="form-group row">
                                <label class="control-label lable-center col-sm-3 lable-center" for="email">Department <span style="color: red;">*</span></label>
                                <div class="col-sm-9">
                                    <input type="text" class="form-control" id="department" name="department" placeholder="Enter department name" maxlength="50" autocomplete="off">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="control-label lable-center col-sm-3 lable-center" for="email">Designation <span style="color: red;">*</span></label>
                                <div class="col-sm-8">
                                    <input type="text" class="form-control" id="designation" name="designation[]" placeholder="Enter designation name" maxlength="50">
                                </div>
                                <div class="col-sm-1 mt-2 pl-0">
                                    <button type="button" class="btn btn-success addButton" id="attachSupport" style="height:43px"><i class="icon-add"></i></button>
                                </div>
                            </div>
                            <div id="moreSupportUpload"></div>
							<div class="row mt-4">
								<div class="col-sm-12">
									<button type="submit" class="btn btn-primary pull-right">Submit<i class="icon-arrow-right14 position-right"></i></button>
								</div>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>

		<div id="modal_default1" class="modal fade" data-backdrop="static" tabindex="-1" role="dialog">
			<div class="modal-dialog modal-lg">
				<div class="modal-content">
					<div class="modal-header bg-info" style="background-color:#009FDF;">
						<h6 class="modal-title text-white"><i class="icon-insert-template" style="zoom:1.1; "></i>
						&nbsp; &nbsp;Edit Department / Designation</h6>
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
					</div>

					<div class="modal-body">
						<div id="complaint_model_data1">

						</div>
					</div>

				</div>
			</div>
		</div>
        <!-- END MAIN CONTAINER -->

        <!-- BEGIN FOOTER -->
        <?php $this->load->view('Admin/includes/n-footer') ?>
        <!-- END FOOTER -->
        <script>
            $('#DepDesTable').DataTable();

            var cheque_number = 1;
            $('#attachSupport').click(function() {
                //add more file
                var moreUploadTag = '';
                moreUploadTag +=
                    '<div class="form-group row"><label class="control-label lable-center col-sm-3 lable-center" for="email">Designation <span style="color: red;">*</span></label><div class="col-sm-8"><input type="text" class="form-control" id="designation' +
                    cheque_number +
                    '" name="designation[]" placeholder="Enter designation name" maxlength="50"></div><div class="col-sm-1 mt-2 pl-0" ><button type="button" class="btn btn-danger removeButton" style="height:43px" onclick="del_file(' +
                    cheque_number + ')"><i class=" icon-trash"></i></button></div></div>';
                $('<dl id="delete_file' + cheque_number + '">' + moreUploadTag + '</dl>').appendTo('#moreSupportUpload');
                cheque_number++;
            });

            function del_file(eleId) {
                var ele = document.getElementById("delete_file" + eleId);
                ele.parentNode.removeChild(ele);
            }
            $(document).ready(function() {
                $('#TypeForm').bootstrapValidator({
                    message: 'This value is not valid',
                    fields: {
                        department: {
                            validators: {
                                notEmpty: {
                                    message: 'Please Enter Department'
                                }
                            }
                        },
                    }
                });
            });


            $(document).ready(function(e) {
                $("#TypeForm").on('submit', (function(e) {
                    //e.preventDefault();
                    if (e.isDefaultPrevented()) {
                        //alert('invalid');
                    } else {

                        $.ajax({
                            url: "<?= base_url(); ?>admin/Master/add_department_designation",
                            type: "POST",
                            data: new FormData(this),
                            contentType: false,
                            cache: false,
                            processData: false,
                            success: function(data) {

                                $(function() {
                                    new PNotify({
                                        title: 'Department / Designation',
                                        text: 'Added  Successfully',
                                        type: 'success'
                                    });
                                });

                                setTimeout(function() {
                                    window.location =
                                        "<?php echo site_url('admin/Master/department_designation'); ?>";
                                }, 1000);


                            },
                            error: function() {
                                alert('fail');
                            }
                        });
                    }
                    return false;

                }));
            });

            function edit_client(dep_id, deg_id) {
				var datastring = 'dep_id=' + dep_id + '&deg_id=' + deg_id;
				// alert(datastring);return false;
				$.ajax({
					type: "post",
					url: "<?php echo site_url('admin/Master/edit_department_designation'); ?>",
					cache: false,
					data: datastring,
					success: function (data) {
						// alert(data);
						$('#modal_default1').modal('show');
						$('#complaint_model_data1').html(data);

					},
					error: function () {
						alert('Error while request..');
					}
				});

			}

            function del_client(dep_id, deg_id) {
                var notice = new PNotify({
                    title: 'Confirmation',
                    text: '<p>Are you sure you want to delete this Department / Designation?</p>',
                    hide: false,
                    type: 'warning',
                    confirm: {
                        confirm: true,
                        buttons: [{
                                text: 'Yes',
                                addClass: 'btn-sm'
                            },
                            {
                                text: 'No',
                                addClass: 'btn-sm'
                            }
                        ]
                    },
                    buttons: {
                        closer: false,
                        sticker: false
                    },
                    history: {
                        history: false
                    }
                })

                // On confirm
                notice.get().on('pnotify.confirm', function () {

                    var datastring = 'dep_id=' + dep_id + '&deg_id=' + deg_id;
                    // alert(datastring);return false;
                    $.ajax({
                        type: "post",
                        url: "<?php echo site_url('admin/Master/deleteDepartmentDesignation'); ?>",
                        cache: false,
                        data: datastring,
                        success: function (data) {
                            //alert(data);
                            $(function () {
                                new PNotify({
                                    title: 'Delete Form',
                                    text: 'Deleted successfully',
                                    type: 'success'
                                });
                            });

                            setTimeout(function () {
                                window.location =
                                    "<?php echo site_url('admin/Master/department_designation'); ?>";
                            }, 1000);


                        },
                        error: function () {
                            alert('Error while request..');
                        }
                    });
                })
                // On cancel
                notice.get().on('pnotify.cancel', function () {
                    // alert('Oh ok. Chicken, I see.');
                });
            }

            function deactivate(id) {

                var notice = new PNotify({
                    title: 'Confirmation',
                    text: '<p>Are you sure you want to Inactive this Department / Designation?</p>',
                    hide: false,
                    type: 'warning',
                    confirm: {
                        confirm: true,
                        buttons: [{
                                text: 'Yes',
                                addClass: 'btn-sm'
                            },
                            {
                                text: 'No',
                                addClass: 'btn-sm'
                            }
                        ]
                    },
                    buttons: {
                        closer: false,
                        sticker: false
                    },
                    history: {
                        history: false
                    }
                })

                // On confirm
                notice.get().on('pnotify.confirm', function () {

                    var datastring = 'typeid=' + id;
                    // alert(datastring);
                    $.ajax({
                        type: "post",
                        url: "<?php echo site_url('admin/Master/deactivate3'); ?>",
                        cache: false,
                        data: datastring,
                        success: function (data) {
                            // alert(data);
                            $(function () {
                                new PNotify({
                                    title: 'Confirmation Form',
                                    text: 'Inactive successfully',
                                    type: 'success'
                                });
                            });

                            setTimeout(function () {
                                window.location =
                                    "<?php echo site_url('admin/Master/department_designation'); ?>";
                            }, 800);


                        },
                        error: function () {
                            alert('Error while request..');
                        }
                    });
                })
                // On cancel
                notice.get().on('pnotify.cancel', function () {
                    // alert('Oh ok. Chicken, I see.');
                });

            }

            function activate(id) {

                var notice = new PNotify({
                    title: 'Confirmation',
                    text: '<p>Are you sure you want to activate this Type?</p>',
                    hide: false,
                    type: 'warning',
                    confirm: {
                        confirm: true,
                        buttons: [{
                                text: 'Yes',
                                addClass: 'btn-sm'
                            },
                            {
                                text: 'No',
                                addClass: 'btn-sm'
                            }
                        ]
                    },
                    buttons: {
                        closer: false,
                        sticker: false
                    },
                    history: {
                        history: false
                    }
                })

                // On confirm
                notice.get().on('pnotify.confirm', function () {

                    var datastring = 'typeid=' + id;
                    // alert(datastring);
                    $.ajax({
                        type: "post",
                        url: "<?php echo site_url('admin/Master/activate3'); ?>",
                        cache: false,
                        data: datastring,
                        success: function (data) {
                            //alert(data);
                            $(function () {
                                new PNotify({
                                    title: 'Confirmation Form',
                                    text: 'Activated successfully',
                                    type: 'success'
                                });
                            });

                            setTimeout(function () {
                                window.location =
                                    "<?php echo site_url('admin/Master/department_designation'); ?>";
                            }, 800);


                        },
                        error: function () {
                            alert('Error while request..');
                        }
                    });
                })
                // On cancel
                notice.get().on('pnotify.cancel', function () {
                    // alert('Oh ok. Chicken, I see.');
                });

            }
        </script>
</body>

</html>