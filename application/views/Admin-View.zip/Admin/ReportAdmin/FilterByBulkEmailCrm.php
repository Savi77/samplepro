<script type="text/javascript" src="<?= base_url() ?>assets/admin/assets/js/plugins/tables/datatables/datatables.min.js"></script>
<script type="text/javascript" src="<?= base_url() ?>assets/admin/assets/js/plugins/tables/datatables/extensions/buttons.min.js"></script>
<script type="text/javascript" src="<?= base_url() ?>assets/admin/assets/js/pages/datatables_extension_colvis.js"></script>
<form action="<?= base_url(); ?>admin/ReportAdmin/Reports/mail_write" method="post">
  <table class="table datatable-colvis-state">
    <thead>
      <tr>
        <th>Select User <br> <input type="checkbox" id="selectAll" /> </th>
        <th>ID No.</th>
        <th>Owner</th>
        <th>Type</th>
        <th>Tag</th>
        <th>Company Name</th>
        <th>Contact Person</th>
        <th>Contact No.</th>
        <th>Email</th>
        <th>Interested In</th>
        <th>Source</th>
        <th>Stage</th>
        <th>Remarks</th>
      </tr>
    </thead>
    <tbody>

      <?php
      $count = 1; 
      foreach ($leads_opportunity as $row) {
      ?>
        <tr>
          <td>
              <div class="form-check">
                <label class="form-check-label">
                  <input type="checkbox" class="form-check-input-styled-primary" name="crmEmail[]"  value="<?= $row['email'] ?>">
                </label>
              </div>
          </td>
          <td>
            <?= $row['lead_generate_id'] ?>
          </td>
          <td><?= $row['emp_name'] ?></td>
          <td><?= $row['customer_type'] ?></td>
          <td><?= $row['tag'] ?></td>
          <td><?= $row['company_name'] ?></td>
          <td><?= $row['contact_person_name1'] ?></td>
          <td><?= $row['phone_no'] ?></td>
          <td><?= $row['email'] ?></td>
          <td><?= $row['prdsrv_name'] ?></td>
          <td><?= $row['source_title'] ?></td>
          <td><?= $row['stage_title'] ?></td>
          <td><?= $row['remarks'] ?></td>
        </tr>
      <?php $count++;
      } ?>

    </tbody>
  </table>
  <div class="col-md-12" style="text-align: right;margin-bottom: 10px;">
    <button class="btn btn-primary" type="submit">Submit</button>
    <span id="loader_gif"></span>
  </div>
</form>
<script>
  $('#selectAll').click(function (e) {
    $(this).closest('table').find('td input:checkbox').prop('checked', this.checked);
});

$(document).ready(function() {
    $('#example').DataTable( {
        "lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
		iDisplayLength: -1
    } );

	
} );
</script>