<script type="text/javascript" src="<?= base_url() ?>assets/admin/assets/js/plugins/tables/datatables/datatables.min.js"></script>
<script type="text/javascript" src="<?= base_url() ?>assets/admin/assets/js/plugins/tables/datatables/extensions/buttons.min.js"></script>
<script type="text/javascript" src="<?= base_url() ?>assets/admin/assets/js/pages/datatables_extension_colvis.js"></script>
<form action="<?= base_url(); ?>admin/ReportAdmin/Reports/mail_write" method="post">
  <table class="table datatable-colvis-state">
        <thead>
          <tr>
            <th>Select All <br> <input type="checkbox" id="selectAll" /> </th>
            <th>Customer Name</th>
            <th>Contact Person</th>
            <th>Contact Number</th>
            <th>Email</th>
            <th>Address</th>
            <th>Type</th>
          </tr>
        </thead>
        <tbody>

          <?php 
          $count = 1; 
          foreach ($leads_opportunity as $row) {
              if ($row->cust_type == 'primary') {
                $bgcolor = "#efefef";
              } else {
                $bgcolor = "white";
              }
          ?>

            <tr>
              <td class="text-center">
                  <div class="form-check">
                    <label class="form-check-label">
                      <input type="checkbox" class="form-check-input-styled-primary" name="crmEmail[]"  value="<?= $row['email'] ?>">
                    </label>
                  </div>
              </td>
              <td>
                <div class="media">
                  <div class="media-body align-self-center">
                    <a href="#" class="font-weight-semibold"> <?= ucwords($row['company_name']) ?></a>
                    <div class="text-muted font-size-sm">
                      Created On : <?= date("d M, Y", strtotime($row['created_date'])) ?>
                    </div>
                  </div>
                </div>
              </td>
              <td><?= $row['contact_person_name1'] ?></td>
              <td><?= $row['phone_no'] ?></td>
              <td><?= $row['email'] ?></td>
              <td><?= $row['address'] ?></td>
              <?php if ($row['cust_type'] == 'primary') { ?>
                <td><span class="label bg-primary">Primary</span></td>
              <?php  } else { ?>
                <td><span class="label bg-info">Secondary</span></td>
              <?php } ?>

            </tr>

          <?php $count++;
          } ?>

        </tbody>
      </table>
      <div class="col-md-12" style="text-align: right;margin-bottom: 10px;">
        <button class="btn btn-primary" type="submit">Submit</button>
        <span id="loader_gif"></span>
    </div>
</form>
<script>
  $('#selectAll').click(function (e) {
      $(this).closest('table').find('td input:checkbox').prop('checked', this.checked);
  });
</script>