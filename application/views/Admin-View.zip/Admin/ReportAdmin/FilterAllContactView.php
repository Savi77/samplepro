<div class="row">
    <div class="col-md-12" style="padding: 0px;">
        <div class="panel panel-flat">
            <table class="table datatable-basic" id="all_activity_filter_table">
                <thead>
                    <tr>
                        <th>Type</th>
                        <th>
                            <div style="width: 250px;">Customer Name</div>
                        </th>
                        <th>Contact Person</th>
                        <th>Contact Number</th>
                        <th>Alternate Number</th>
                        <th>Landline Number</th>
                        <th>Email</th>
                        <th>Alternate Email</th>
                        <th>Country </th>
                        <th>State </th>
                        <th>City </th>
                        <th>Address</th>
                        <th>Google Address</th>
                        <th>Picode</th>
                        <th>GST No.</th>
                        <th>Pan No.</th>
                        <th>Tan No.</th>
                        <th>Date of Birth</th>
                        <th>Company Anniversary</th>
                        <th>Marriage Anniversary</th>
                        <th>Type</th>
                        <th>Group</th>
                        <th>Location</th>
                        <th>Credit Term </th>
                        <th>Account Manager </th>
                        <th>Notes</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    foreach ($SegmentWiseContact as $row) {
                        if ($row->cust_type == 'primary') {
                            $cust_type = '<span class="label bg-primary">Primary</span>';
                        } else {
                            $cust_type = '<span class="label bg-info">Secondary</span>';
                        }

                        if ($row->dob == '') {
                            $dob = '';
                        } else {
                            $dob = date('d F, Y', strtotime($row->dob));
                        }

                        if ($row->company_anniversary == '') {
                            $CompanyAnniversary = '';
                        } else {
                            $CompanyAnniversary = date('d F, Y', strtotime($row->company_anniversary));
                        }

                        if ($row->marriage_anniversary == '') {
                            $MarriageAnniversary = '';
                        } else {
                            $MarriageAnniversary = date('d F, Y', strtotime($row->marriage_anniversary));
                        }

                    ?>
                        <tr>
                            <td><?= $cust_type; ?></td>
                            <td>
                                <div class="media" style="width: 150px;">
                                    <div class="media-body align-self-center">
                                        <div style="width: 250px;"><a href="#" class="font-weight-semibold"><?= ucwords($row->company_name); ?></a></div>
                                        <div class="text-muted font-size-sm">
                                            Created On : <?= date("d M, Y", strtotime($row->created_date)) ?>
                                        </div>
                                    </div>
                                </div>
                            </td>
                            <td><?= $row->contact_person_name1; ?></td>
                            <td><?= $row->phone_no; ?></td>
                            <td><?= $row->alternate_number; ?></td>
                            <td><?= $row->landline_number; ?></td>
                            <td><?= $row->email; ?></td>
                            <td><?= $row->alternate_email; ?></td>
                            <td><?= $row->c_name; ?></td>
                            <td>
                                <div style="width: 200px;"><?= $row->s_name; ?></div>
                            </td>
                            <td><?= $row->city; ?></td>
                            <td>
                                <div style="width: 500px;"><?= $row->address; ?></div>
                            </td>
                            <td>
                                <div style="width: 500px;"><?= $row->address2; ?></div>
                            </td>
                            <td><?= $row->pincode; ?></td>
                            <th><?= $gstin; ?></th>
                            <th><?= $pan_no; ?></th>
                            <th><?= $tan_no; ?></th>
                            <th>
                                <div style="width: 100px;"><?= $dob; ?></div>
                            </th>
                            <th>
                                <div style="width: 100px;"><?= $CompanyAnniversary; ?></div>
                            </th>
                            <th>
                                <div style="width: 100px;"><?= $MarriageAnniversary; ?></div>
                            </th>
                            <td>
                                <div style="width: 100px;"><?= $row->title; ?></div>
                            </td>
                            <td>
                                <div style="width: 100px;"><?= $row->group_name; ?></div>
                            </td>
                            <td>
                                <div style="width: 100px;"><?= $row->location; ?></div>
                            </td>
                            <td>
                                <div style="width: 100px;"><?= $row->credit_name; ?></div>
                            </td>
                            <td>
                                <div style="width: 100px;"><?= $row->a_name; ?></div>
                            </td>
                            <td>
                                <div style="width: 500px;"><?= $row->notes; ?></div>
                            </td>
                        </tr>

                    <?php   }   ?>
                </tbody>
            </table>
        </div>
    </div>
</div>