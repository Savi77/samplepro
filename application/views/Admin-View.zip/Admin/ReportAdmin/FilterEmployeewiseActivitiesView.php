

        <table  class="table datatable-basic" id="all_activity_filter_table">     
          <thead>
            <tr>
                <th>#</th>
                <th>Employee</th>
                <?php
                foreach ($ActivityArray as  $row) 
                {
                 ?>
                <th><?=  $row->type_name; ?></th>
              <?php } ?>
            </tr>
          </thead>
          <tbody>
              <?php
               $cnt=1;
               foreach ($EmployeewiseActivities as  $row2) 
               {
                 $NewActivityArray=$row2['ActivityArray'];
               ?>
                <tr>
                 <td><?=  $cnt; ?></td>
                 <td><?=  $row2['name']; ?></td>
                   <?php 
                   for($i=0;$i<count($NewActivityArray);$i++)
                   {$ids=$NewActivityArray[$i]['id'].'|'.$row2['emp_id'];
                   ?>
                  <td><a  title="View Details"  onclick="ViewDetails(id)" id="<?= $ids ?>"><b><?=  $NewActivityArray[$i]['type_count']; ?></b></td>
                <?php } ?>





                 </tr>
             <?php  $cnt++; } ?>
          </tbody>
        </table>



        