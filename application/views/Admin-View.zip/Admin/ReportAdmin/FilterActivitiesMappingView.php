
                                                      

        <table  class="table datatable-basic" id="all_activity_filter_table">     
            <thead>
              <tr>
                  <th>#</th>
                  <th>Employee</th>
                  <th>Ticket (Issues)</th>
                  <th>Task</th>
                  <th>Own</th>
              </tr>
            </thead>
            <tbody>
                <?php
                 $cnt=1;
                 foreach ($EmployeewiseActivitiesMapping as  $row2) 
                 {
                 ?>
                  <tr>
                      <td><?=  $cnt; ?></td>
                      <td><?=  $row2['name']; ?></td>
                      <td><?=  $row2['total_issue']; ?></td>
                      <td><?=  $row2['task_issue']; ?></td>
                      <td><?=  $row2['own_issue']; ?></td>
                   </tr>
               <?php  $cnt++; } ?>
            </tbody>

        </table>