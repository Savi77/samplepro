

        <table  class="table datatable-basic" id="all_activity_filter_table">     
          <thead>
            <tr>
                  <th>#</th>
                  <th>Particulars</th>
                  <th>Count</th>
            </tr>
          </thead>
          <tbody>
              <?php
                  $count = 1;
                  foreach($ContactSummary as $row) 
                  {                   
                ?>
                <tr>
                    <td><?= $count; ?></td>
                    <td><?= $row['cust_type'] ?></td>
                    <td><a  title="Contacts Summary"  onclick="ViewDetails(id)" id="<?= $row['cust_type'] ?>"><b><?= $row['count'] ?></b></a></td> 
               </tr>
               <?php $count++;  } ?> 
          </tbody>
        </table>