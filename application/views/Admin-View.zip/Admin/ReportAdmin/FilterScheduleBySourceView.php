

        <table  class="table datatable-basic" id="all_activity_filter_table">     
          <thead>
            <tr>
                <th>#</th>
                <th>Particulars</th>
                <th>Total</th>
                <?php
                 foreach ($StageArray as $row2) 
                 {
                ?>
                 <th><?= $row2->stage_title; ?></th>
               <?php } ?>
            </tr>
          </thead>
          <tbody>
              <?php
                  $count = 1;
                  foreach($Lead_Opportunity_by_Source as $row) 
                  {     
                     $stage_cnt_array=$row['stage_cnt_array'];  
                     $stage_id_array=$row['stage_id_array'];                  
                ?>
                <tr>
                    <td style="width:10%;"><?= $count; ?></td>
                    <td><?= $row['source'] ?></td>
                     <td><a title="Lead | Opportunity by Source"  onclick="ViewTotalDetails(id)" id="<?= $row['source_id'] ?>">
                      <b><?= $row['total'] ?></b></a>
                    </td>

                    <?php
                     for($c=0;$c<count($stage_cnt_array);$c++) 
                     {
                        $stage_id=$stage_id_array[$c].'|'.$row['source_id'];
                    ?>
                     <td><a title="Lead | Opportunity by Stage"  onclick="ViewStageDetails(id)" id="<?= $stage_id; ?>">
                      <b><?= $stage_cnt_array[$c]; ?></b></a>
                    </td>
                   <?php } ?>

                </tr>
               <?php $count++;  } ?> 
          </tbody>
        </table>