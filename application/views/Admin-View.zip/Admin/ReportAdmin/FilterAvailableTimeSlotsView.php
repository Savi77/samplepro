

        <table  class="table datatable-basic" id="all_activity_filter_table">     
              <thead>
                <tr>
                    <th>#</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Mobile No.</th>
                </tr>
              </thead>
              <tbody>
                  <?php
                      $count = 1;
                      foreach($AvailableTimeSlots as $row) 
                      {                       
                    ?>
                    <tr>
                        <td style="width:10%;"><?= $count; ?></td>
                        <td>
                          <a title="<?= $row['name'] ?>" onclick="ViewDetails(id)" id="<?= $row['emp_id'] ?>"><b><?= $row['name'] ?></b></a>
                        </td> 
                        <td><?= $row['email'] ?></td>
                        <td><?= $row['mobile_no'] ?></td>
                    </tr>
                   <?php $count++;  } ?> 
            </tbody>
        </table>