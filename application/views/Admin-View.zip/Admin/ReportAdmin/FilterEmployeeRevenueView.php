

        <table  class="table datatable-basic" id="all_activity_filter_table">     
              <thead>
                <tr>
                    <th>#</th>
                    <th>Employee</th>
                    <th>Revenue</th>
                </tr>
              </thead>
              <tbody>
                  <?php
                   $cnt=1;
                   foreach ($EmployeeRevenue as  $row2) 
                   {
                   ?>
                    <tr>
                        <td><?=  $cnt; ?></td>
                        <td><?=  $row2['name']; ?></td>
                        <td><?=  $row2['revenue']; ?></td>
                     </tr>
                 <?php  $cnt++; } ?>
              </tbody>
        </table>