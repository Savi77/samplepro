

        <table  class="table datatable-basic" id="all_activity_filter_table">     
          <thead>
            <tr>
                <th>#</th>
                <th>Employee</th>
                <th>Nos. of Accounts</th>
                <th class="hidden">Sucess</th>
                <th class="hidden">Total</th>
                <th class="hidden">Average</th>
            </tr>
          </thead>
          <tbody>
              <?php
                  $count = 1;
                  foreach($AccountOwners as $row) 
                  {                   
                ?>
                <tr>
                    <td><?= $count; ?></td>
                    <td><?= $row['emp_name'] ?></td>
                    <td><a  title="Account Owners"  onclick="ViewDetails(id)" id="<?= $row['emp_id'] ?>"><b><?= $row['total'] ?></b></a></td> 
                    <td class="hidden"><?= $count; ?></td>
                    <td class="hidden"><?= $count; ?></td>
                    <td class="hidden"><?= $count; ?></td>
               </tr>
               <?php $count++;  } ?> 
          </tbody>
        </table>



        