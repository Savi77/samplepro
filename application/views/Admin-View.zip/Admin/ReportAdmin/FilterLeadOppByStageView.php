

        <table  class="table datatable-basic" id="all_activity_filter_table">     
          <thead>
            <tr>
                <th>#</th>
                <th>Stage</th>
                <th>Total</th>
                <th class="hidden">Sucess</th>
                <th class="hidden">Total</th>
                <th class="hidden">Average</th>
            </tr>
          </thead>
          <tbody>
              <?php
                  $count = 1;
                  foreach($LeadOppByStage as $row) 
                  {                   
                ?>
                <tr>
                    <td><?= $count; ?></td>
                    <td><?= $row['stage_title'] ?></td>
                    <td>
                      <a title="<?= $row['stage_id'] ?>" onclick="ViewDetails(id)" id="<?= $row['stage_id'] ?>"><b><?= $row['total'] ?></b></a>
                    </td> 
                    <td class="hidden"><?= $count; ?></td>
                    <td class="hidden"><?= $count; ?></td>
                    <td class="hidden"><?= $count; ?></td>
               </tr>
               <?php $count++;  } ?> 
          </tbody>
        </table>