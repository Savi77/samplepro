

        <table  class="table datatable-basic" id="all_activity_filter_table">     
          <thead>
            <tr>
                  <th>#</th>
                  <th>Particulars</th>
                  <th>Count</th>
            </tr>
          </thead>
          <tbody>
              <?php
                  $count = 1;
                  foreach($Lead_Opportunity_by_Product as $row) 
                  {                   
                ?>
                <tr>
                    <td><?= $count; ?></td>
                    <td><?= $row['product_name'] ?></td>
                   <td><a title="Lead | Opportunity by Product"  onclick="ViewDetails(id)" id="<?= $row['product_id'] ?>">
                    <b><?= $row['total'] ?></b></a>
                  </td>
               </tr>
               <?php $count++;  } ?> 
          </tbody>
        </table>