

        <table  class="table" id="all_activity_filter_table">     
          <thead>
            <tr>
                <th>#</th>
                <th>Employee Name</th>
                <th>Total</th>
            </tr>
          </thead>
          <tbody>
              <?php
                  $count = 1;
                  foreach($Lead_Opportunity_by_Product as $row) 
                  {                   
                ?>
                <tr>
                    <td><?= $count; ?></td>
                    <td><?= $row['emp_name'] ?></td>
                     <td><a title="Lead | Opportunity by Sales Person"  onclick="ViewDetails(id)" id="<?= $row['emp_id'] ?>"><b><?= $row['total'] ?></b></a></td>
               </tr>
               <?php $count++;  } ?> 
          </tbody>
        </table>