

        <table  class="table datatable-basic" id="all_activity_filter_table">     
          <thead>
            <tr>
                  <th>#</th>
                  <th>Particulars</th>
                  <th>Revenue</th>
            </tr>
          </thead>
          <tbody>
              <?php
                  $count = 1;
                  foreach($AccountRevenue as $row) 
                  {                   
                ?>
                <tr>
                    <td><?= $count; ?></td>
                    <td><?= $row['company_name'] ?></td>
                    <td><a  title="Contacts Summary"  onclick="ViewDetails(id)" id="<?= $row['company_id'] ?>"><b><?= $row['revenue'] ?></b></a></td> 
               </tr>
               <?php $count++;  } ?> 
          </tbody>
        </table>