

        <table  class="table" id="all_activity_filter_table">     
          <thead>
            <tr>
                <th>#</th>
                <th>Company Name</th>
                <th>Last Activity Before</th>
                <th>Activity</th>
                <th>Employee</th>
                <th>Status </th>
            </tr>
          </thead>
          <tbody>
              <?php
                  $count = 1;
                  foreach($ContactsActivities as $row) 
                  {                       
                ?>
                <tr>
                    <td><?= $count; ?></td>
                    <td><a  title="Location wise Contact"  onclick="ViewDetails(id)" id="<?= $row['customer_id'] ?>"><b><?= $row['company_name'] ?></b></a></td>
                    <td><?= $row['last_activity_before'] ?> Days</td>
                    <td><?= $row['last_activity'] ?></td>
                    <td><?= $row['employee'] ?></td> 
                    <td><?= ucwords($row['status']) ?></td>                     
                </tr>
               <?php $count++;  } ?> 
          </tbody>
        </table>