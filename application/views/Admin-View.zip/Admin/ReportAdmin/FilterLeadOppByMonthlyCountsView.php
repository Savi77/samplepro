

        <table  class="table datatable-basic" id="all_activity_filter_table">     
              <thead>
                    <tr>
                        <th>Type</th>
                        <?php   
                            for($i=0;$i<count($LeadOppByMonthlyCounts);$i++)
                            {
                              $array=$LeadOppByMonthlyCounts[$i];
                              for($j=0;$j<count($array);$j++)
                               {
                          ?> 
                          <th><?= $array[$j]['month_name'].' '.$array[$j]['year'] ?></th>
                        <?php  }  break;} ?>
                    </tr>
              </thead>
              <tbody>
                    <?php   
                        for($a=0;$a<count($LeadOppByMonthlyCounts);$a++)
                        { ?>
                        <tr>
                            <td>
                               <?= $LeadOppByMonthlyCounts[$a][$a]['customer_type']; ?>
                            </td>
                        <?php  
                          $array=$LeadOppByMonthlyCounts[$a];
                          for($b=0;$b<count($array);$b++)
                           {
                      ?> 
                          <td>
                            <a  onclick="ViewDetails(id)" id="<?= $array[$b]['month'].'|'.$array[$b]['year'].'|'.$array[$b]['customer_type'];?>"><b><?= $array[$b]['total'] ?></b></a>
                          </td>
                    <?php  } ?>  </tr> <?php } ?>                                                           
                    
              </tbody>
        </table>