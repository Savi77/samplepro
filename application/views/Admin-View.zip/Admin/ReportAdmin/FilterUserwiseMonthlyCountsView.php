                                                    


        <table  class="table datatable-basic" id="all_activity_filter_table"> 
              <thead>
                <tr>
                    <th>Employee</th>
                    <?php   
                      for($i1=0;$i1<count($MonthArray);$i1++)
                      {                                                                  
                      ?> 
                      <th><?= $MonthArray[$i1]['month_name'].' '.$MonthArray[$i1]['year'] ?></th>
                    <?php } ?>
                </tr>
              </thead>
              <tbody>
                      <?php
                        for($c=0;$c<count($LeadOppByUserwiseMonthlyCounts_new);$c++)
                         {
                        ?>
                    <tr>
                        <td> <?= $LeadOppByUserwiseMonthlyCounts_new[$c]['emp_name'];?> </td>                                                        
                       <?php
                          $montharray=$LeadOppByUserwiseMonthlyCounts_new[$c]['montharray'];
                          for($b1=0;$b1<count($montharray);$b1++)
                          {
                       ?>

                            <td>
                              <a  onclick="ViewDetails(id)" id="<?= $montharray[$b1]['month'].'|'.$montharray[$b1]['year'].'|'.$LeadOppByUserwiseMonthlyCounts_new[$c]['emp_id'];?>"><b><?= $montharray[$b1]['total'] ?></b></a>
                            </td>



                     <?php }  ?>
                   </tr>
                 <?php } ?>
              </tbody>
         </table>     