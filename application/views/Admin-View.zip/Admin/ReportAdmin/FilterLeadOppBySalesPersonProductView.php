

        <table  class="table" id="all_activity_filter_table">     
            <thead>
              <tr>
                  <th>#</th>
                  <th>Sales Person</th>
                  <th>Particulars</th>
                  <th>Total</th>
              </tr>
            </thead>
            <tbody>
                <?php
                    $count = 1;
                    foreach($LeadOppBySalesPersonSegment as $row) 
                    {                       
                  ?>
                      <tr>
                          <td style="width:10%;"><?= $count; ?></td>
                          <td><?= $row['emp_name'] ?></td>
                          <td><?= $row['prdsrv_name'] ?></td>
                          <td><a title="Lead|Opportunity by Sales Person - product wise"  onclick="ViewTotalDetails(id)" id="<?= $row['product_id'].'|'.$row['emp_id'] ?>">
                          <b><?= $row['total'] ?></b></a>
                          </td>
                      </tr>
                 <?php $count++;  } ?> 
            </tbody>
        </table>