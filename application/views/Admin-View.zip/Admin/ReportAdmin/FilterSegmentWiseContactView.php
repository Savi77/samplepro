

        <table  class="table datatable-basic" id="all_activity_filter_table">     
          <thead>
            <tr>
                <th>#</th>
                <th>Particulars</th>
                <th>Count</th>
                <th class="hidden">Sucess</th>
                <th class="hidden">Total</th>
                <th class="hidden">Average</th>
            </tr>
          </thead>
          <tbody>
              <?php
                  $count = 1;
                  foreach($SegmentWiseContact as $row) 
                  {                   
                ?>
                <tr>
                    <td><?= $count; ?></td>
                    <td><?= $row['business_name'] ?></td>
                    <td><a  title="Segments wise Contacts"  onclick="ViewDetails(id)" id="<?= $row['business_id'] ?>"><b><?= $row['total'] ?></b></a></td> 
                    <td class="hidden"><?= $count; ?></td>
                    <td class="hidden"><?= $count; ?></td>
                    <td class="hidden"><?= $count; ?></td>
               </tr>
               <?php $count++;  } ?> 
          </tbody>
        </table>