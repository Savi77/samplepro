

        <table  class="table datatable-basic" id="all_activity_filter_table">     
            <thead>
              <tr>
                  <th>#</th>
                  <th>Name</th>
                  <th>Target</th>
                  <th>Target Periodicity</th>
                  <th>Amount</th>
                  <th>Balance</th>
                  <th>Achieved</th>
              </tr>
            </thead>
            <tbody>
                <?php
                    $count = 1;
                    foreach($EmployeeTarget as $row) 
                    {                       
                  ?>
                  <tr>
                      <td style="width:10%;"><?= $count; ?></td>
                      <td>
                        <a title="<?= $row['emp_name'] ?>" onclick="ViewDetails(id)" id="<?= $row['emp_name'] ?>"><b><?= $row['emp_name'] ?></b></a>
                      </td> 
                      <td><?= $row['TargetName'] ?></td>
                      <td><?= $row['target_period'] ?></td>
                      <td><?= $row['TargetAmount'] ?></td>
                      <td><?= $row['TargetBalance'] ?></td>
                      <td><?= $row['TargetAchieved'] ?></td>
                  </tr>
                 <?php $count++;  } ?> 
            </tbody>
        </table>