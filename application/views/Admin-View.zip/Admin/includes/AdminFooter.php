<div class="navbar navbar-default navbar-sm navbar-fixed-bottom">
  <ul class="nav navbar-nav no-border visible-xs-block">
    <li><a class="text-center collapsed" data-toggle="collapse" data-target="#navbar-second"><i class="icon-circle-up2"></i></a></li>
  </ul>
  <div class="navbar-collapse collapse" id="navbar-second">
    <div class="navbar-text">
      &copy; <?= date('Y'); ?> <a href="https://www.buroforce.com">Buroforce</a>
    </div>
    <div class="navbar-right">
      <ul class="nav navbar-nav">
        <li class="nav-item">
          <a href="<?= base_url(); ?>admin/Feedback" class="navbar-nav-link" target="_blank"><i class="icon-comment-discussion mr-2" style="margin-right: 5px;"></i> Feedback</a>
        </li>
      </ul>
    </div>
  </div>
</div>