<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no">
    <title>Buro Force </title>
    <link rel="icon" type="image/x-icon" href="<?= base_url() ?>assets/assets/img/fevicon icon.png" />
    <link href="<?= base_url() ?>assets/assets/css/loader.css" rel="stylesheet" type="text/css" />
    <link href="<?= base_url() ?>assets/assets/css/style.css" rel="stylesheet" type="text/css" />
    <link href="<?= base_url() ?>assets/assets/css/custom.css" rel="stylesheet" type="text/css" />
    
    <script src="<?= base_url() ?>assets/assets/js/loader.js"></script>
    <!-- BEGIN GLOBAL MANDATORY STYLES -->
    <link href="https://fonts.googleapis.com/css?family=Nunito:400,600,700" rel="stylesheet">
    <link href="<?= base_url() ?>assets/assets/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />

    <link href="<?= base_url() ?>assets/assets/css/plugins.css" rel="stylesheet" type="text/css" />
    <!-- END GLOBAL MANDATORY STYLES -->

    <!-- BEGIN PAGE LEVEL PLUGINS/CUSTOM STYLES -->
    <link href="<?= base_url() ?>assets/assets/plugins/apex/apexcharts.css" rel="stylesheet" type="text/css">
    <link href="<?= base_url() ?>assets/assets/css/dashboard/dash_1.css" rel="stylesheet" type="text/css" />

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css" type="text/css">
    <link rel="stylesheet" type="text/css" href="<?= base_url() ?>assets/assets/css/forms/switches.css">
    <link href="<?= base_url() ?>assets/assets/plugins/pricing-table/css/component.css" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" type="text/css" href="<?= base_url() ?>assets/assets/css/forms/theme-checkbox-radio.css">
    <link rel="stylesheet" type="text/css" href="<?= base_url() ?>assets/assets/css/forms/switches.css">
    <link href="<?= base_url() ?>assets/assets/css/authentication/form-2.css" rel="stylesheet" type="text/css" />
    <!-- profile page -->
    <link href="<?= base_url() ?>assets/assets/css/components/tabs-accordian/custom-tabs.css" rel="stylesheet" type="text/css" />
    
    <!-- BEGIN GLOBAL MANDATORY SCRIPTS -->
    <script src="<?= base_url() ?>assets/assets/js/libs/jquery-3.1.1.min.js"></script>
    <script src="<?= base_url() ?>assets/js/bootstrapValidator.min.js"></script>
    <script src="<?= base_url() ?>assets/assets/bootstrap/js/popper.min.js"></script>
    <script src="<?= base_url() ?>assets/assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="<?= base_url() ?>assets/assets/plugins/perfect-scrollbar/perfect-scrollbar.min.js"></script>
    <script src="<?= base_url() ?>assets/assets/js/app.js"></script>
    <script>
        $(document).ready(function() {
            App.init();
        });
    </script>
    <script src="<?= base_url() ?>assets/assets/js/custom.js"></script>
    <!-- END GLOBAL MANDATORY SCRIPTS -->

    <!-- BEGIN PAGE LEVEL PLUGINS/CUSTOM SCRIPTS -->
    <script src="<?= base_url() ?>assets/assets/plugins/apex/apexcharts.min.js"></script>
    <script src="<?= base_url() ?>assets/assets/js/dashboard/dash_1.js"></script>
    <!-- END PAGE LEVEL PLUGINS/CUSTOM SCRIPTS -->

    <!-- Added By Buroforce Links -->

    <link href="<?= base_url() ?>assets/admin/assets/css/icons/icomoon/styles.css" rel="stylesheet" type="text/css">
    <link href="<?= base_url() ?>assets/css/bootstrapValidator.min.css" rel="stylesheet" type="text/css">
    <link href="<?= base_url() ?>assets/notify/pnotify.custom.min.css" rel="stylesheet" type="text/css">

    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.4/css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-multiselect/0.9.13/css/bootstrap-multiselect.css" />
    <link rel="stylesheet" type="text/css" href="<?= base_url() ?>assets/dist1/bootstrap-clockpicker.min.css">
    <link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.css" rel="stylesheet">
    

    <!-- Added By Buroforce Links -->
</head>