   
        <?php //print_r($GetDirData);



         ?>
        <div class="modal-header bg-info" style="background-color:#009FDF;">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h6 class="modal-title">Upload Attachment</h6>
        </div>
          <div class="modal-body">
            <div class="row">
               <div class="panel panel-flat" style="margin-bottom: 20px;border-color: #ddd;color: #333333;">
                  <div class="panel-body" style="padding: 0px;">
                    <form class="form-horizontal" id="addattachform"  enctype='multipart/form-data'>
                        <input type="hidden" name="db_dir_id" id="db_dir_id" >
                          <div class="">  
                               <div class="page-header page-header-default">
                                  <div class="page-header-content">
                                    <div class="page-title" style="padding: 10px 30px 5px 5px;">
                                      <h5>
                                        <i class=" icon-folder2 position-left"></i>
                                        <span class="text-semibold">Directory</span> 
                                      </h5>
                                    </div>
                                  </div>

                                  <div class="breadcrumb-line">
                                    <ul class="breadcrumb">
                                      <?php
                                        $string='';
                                        for($dd=0;$dd<count($GetDirData);$dd++)
                                        {
                                          $string=$string.'/'.$GetDirData[$dd];
                                        ?>
                                      <li><a href="#"><b><?= $GetDirData[$dd] ?></b></a></li>
                                    <?php } ?>
                                    </ul>
                                  </div>
                                </div>

                                <?php  $path=substr($string, 1); ?>

                                <input type="hidden" name="path" id="path" value="<?= $path ?>" >


                             <div class="col-md-12">
                               <div class="form-group ">
                                  <div class="">  
                                   <div class="col-md-12">
                                        <div class="col-xs-1">
                                            <button type="button" class="btn btn-success addButton" style="margin-top:20px;">
                                              <i class="icon-add"></i>
                                            </button>
                                        </div>
                                        <div class="col-xs-6">
                                            Choose File :<input type="file" class="form-control" name="uploadfile[]" >
                                        </div>
                                        <div class="col-xs-5">
                                            Remark :<textarea class="form-control" name="fileremark[]"  maxlength="150" rows="1"></textarea> 
                                        </div>
                                      </div> 
                                 </div>  
                              </div>
                            </div>
                            <div class="col-md-12"> 
                              <div class="form-group hide" id="bookTemplate" >
                                   <div class="col-md-12">
                                        <div class="col-xs-1">
                                           <button type="button" class="btn btn-danger removeButton" style="margin-top:20px">
                                            <i class=" icon-trash"></i>
                                          </button>
                                        </div>
                                        <div class="col-xs-6">
                                            Choose File :<input type="file" class="form-control" name="uploadfile[]" >
                                        </div>
                                        <div class="col-xs-5">
                                            Remark :<textarea class="form-control" name="fileremark[]" maxlength="150"  rows="1"></textarea> 
                                        </div>
                                  </div>
                              </div>  
                           </div>
                            <div class="col-md-12" align="right">
                               <br/>
                               <button type="submit" class="btn btn-primary btn-lg" style="margin-bottom:1%;"><i class="icon-upload position-left"></i> Upload Document</button>
                               <span id="preview222"></span>
                                <br/>
                              </div>
                             
                            </div> 
                        </form>  
                    </div>                     
                   </div>
                </div> 
            </div>

<script>
$(document).ready(function() 
{
        brandvalidator = {
            row: '.col-xs-6',
            validators: {
               notEmpty: 
                      {
                        message: 'Attachment is required'
                      },
                    file: {
                              extension: 'pdf,doc,docx,jpg,jpeg,png,bmp,xsl,xlsx',
                              // type: 'application/pdf,application/msword',
                              maxSize: 2048 * 1024,
                              message: 'Supported format - pdf, doc, docx, jpg, jpeg, png, bmp, xls, xlsx'
                          }

                  }
              },
        remarkValidator = {
            row: '.col-xs-5',
            validators: {
               notEmpty: 
                      {
                        message: 'Remark is required'
                      }
                  }
              },
     bookIndex = 0;

    $('#addattachform')
        .bootstrapValidator({
            framework: 'bootstrap',
            icon: {
                valid: 'glyphicon glyphicon-ok',
                invalid: 'glyphicon glyphicon-remove',
                validating: 'glyphicon glyphicon-refresh'
            },
            fields: {
                      'uploadfile[]': brandvalidator,
                      'fileremark[]': remarkValidator,                
                  }
        })
        // Add button click handler
        .on('click', '.addButton', function()
         {
            bookIndex++;
            var $template = $('#bookTemplate'),
                $clone    = $template
                                .clone()
                                .removeClass('hide')
                                .removeAttr('id')
                                .attr('data-book-index', bookIndex)
                                .insertBefore($template);

            // Update the name attributes
            $clone
                .find('[name="uploadfile[]"]').attr('name', 'uploadfile[' + bookIndex + ']').end()
                .find('[name="fileremark[]"]').attr('name', 'fileremark[' + bookIndex + ']').end()
                ;

              $('#addattachform')
                      .bootstrapValidator('addField', 'uploadfile[' + bookIndex + ']', brandvalidator)
                      .bootstrapValidator('addField', 'fileremark[' + bookIndex + ']', remarkValidator)
                      ;
              })
              // Remove button click handler
              .on('click', '.removeButton', function() 
              {
                  var $row  = $(this).parents('.form-group'),
                      index = $row.attr('data-book-index');
                  // Remove element containing the fields
                  $row.remove();
              });
      });
</script>

 <script type="text/javascript">
  $(document).ready(function (e)
     {
       $("#addattachform").on('submit',(function(e)
           {
             //e.preventDefault();
             if (e.isDefaultPrevented())
              {
                  //alert('invalid');
              }
              else
              {
                  $("#preview222").show();
                  $("#preview222").html('<img src="<?= base_url() ?>assets/images/default.gif" style="height:30px;width:30px;" />');
                   $.ajax({
                                type: "POST",
                                url: "<?php echo site_url('admin/DocumentUpload/UploadDocument'); ?>",
                                data:  new FormData(this),
                                contentType: false,
                                cache: false,
                                processData:false,
                                success: function(data)
                                  {
                                    // alert(data);
                                     $("#preview222").hide();
                                     new PNotify({
                                                   title: 'Upload Document',
                                                   text: 'Document Uploaded Successfully',
                                                   type: 'success'
                                          });
                                        setTimeout(function()
                                         {
                                            window.location="";

                                             window.location="<?php echo site_url('admin/DocumentUpload/CreateDirectory');?>";
                                         }, 500);

                                  },
                          error: function()
                          {
                            alert('fail');
                           }
                       });
              }
          return false;
          }));
      });
</script>

